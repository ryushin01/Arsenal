package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_CUST_MASTER", schema = "nicekos")
public class TbCustMaster extends BaseTimeEntity {
    @Id
    @Size(max = 12)
    @Column(name = "MEMB_NO", nullable = false, length = 12)
    private String membNo;

    @Size(max = 150)
    @NotNull
    @Column(name = "MEMB_NM", nullable = false, length = 150)
    private String membNm;

    @Size(max = 8)
    @NotNull
    @Column(name = "JUMIN_NO", nullable = false, length = 8)
    private String juminNo;

    @NotNull
    @Column(name = "SEX_GB", nullable = false)
    private Integer sexGb;

    @Size(max = 2)
    @NotNull
    @Column(name = "STAT_CD", nullable = false, length = 2)
    private String statCd;

    @Size(max = 2)
    @NotNull
    @Column(name = "PERM_CD", nullable = false, length = 2)
    private String permCd;

    @Size(max = 1)
    @NotNull
    @Column(name = "REPT_YN", nullable = false, length = 1)
    private String reptYn;

    @Size(max = 10)
    @Column(name = "ENTR_DT", length = 10)
    private String entrDt;

    @Size(max = 10)
    @Column(name = "BIZ_NO", length = 10)
    private String bizNo;

    @Size(max = 100)
    @NotNull
    @Column(name = "PIN_PWD", nullable = false, length = 100)
    private String pinPwd;

    @Size(max = 100)
    @Column(name = "PATN_PWD", length = 100)
    private String patnPwd;

    @Size(max = 250)
    @Column(name = "FCM_ID", length = 250)
    private String fcmId;

    @Size(max = 1)
    @NotNull
    @Column(name = "DVCE_KND", nullable = false, length = 1)
    private String dvceKnd;

    @Size(max = 150)
    @NotNull
    @Column(name = "CPHN_NO", nullable = false, length = 150)
    private String cphnNo;

    @Size(max = 100)
    @NotNull
    @Column(name = "DI_KEY", nullable = false, length = 100)
    private String diKey;

    @Size(max = 100)
    @NotNull
    @Column(name = "CI_KEY", nullable = false, length = 100)
    private String ciKey;

    @NotNull
    @Column(name = "LOGN_FAIL_CNT", nullable = false)
    private Integer lognFailCnt;

    @Column(name = "IMG_SEQ")
    private Long imgSeq;

    @Size(max = 1)
    @NotNull
    @Column(name = "TRREG_PSSB_YN", nullable = false, length = 1)
    private String trregPssbYn;

    @Size(max = 20)
    @NotNull
    @Column(name = "KOS_APP_VR", nullable = false, length = 20)
    private String kosAppVr;

    @Size(max = 12)
    @NotNull
    @Column(name = "DVCE_UNQ_NUM", nullable = false, length = 12)
    private String dvceUnqNum;

    @Column(name = "MYCASE_PG_DTM")
    private LocalDateTime mycasePgDtm;

    @Size(max = 1)
    @Column(name = "STAFF_APRV_STBY_ALM_YN", length = 1)
    private String staffAprvStbyAlmYn;
}