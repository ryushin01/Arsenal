package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbAdminMaster}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbAdminMasterDto implements Serializable {
    @Size(max = 12)
    String membNo;
    @Size(max = 40)
    String lognId;
    @NotNull
    @Size(max = 150)
    String adminNm;
    @NotNull
    @Size(max = 2)
    String permCd;
    @NotNull
    @Size(max = 100)
    String pwd;
    @Size(max = 150)
    String cphnNum;
    @Size(max = 2)
    String deptCd;
    @Size(max = 2)
    String pstnCd;
    @NotNull
    @Size(max = 2)
    String statCd;
    @NotNull
    Integer lognFailCnt;
    @Size(max = 6)
    String verifyCd;
    LocalDateTime verifyExpireDtm;
    @NotNull
    LocalDateTime crtDtm;
    @NotNull
    @Size(max = 12)
    String crtMembNo;
    @NotNull
    LocalDateTime chgDtm;
    @NotNull
    @Size(max = 12)
    String chgMembNo;
}