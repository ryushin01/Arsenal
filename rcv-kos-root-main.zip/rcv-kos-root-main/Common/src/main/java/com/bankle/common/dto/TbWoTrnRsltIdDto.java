package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnRsltId}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnRsltIdDto implements Serializable {
    @NotNull
    @Size(max = 20)
    String loanNo;
    @NotNull
    @Size(max = 4)
    String tgDsc;
}