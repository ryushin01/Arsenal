package com.bankle.common.wooriApi.socket.ins.sendSvc.vo;

import com.bankle.common.wooriApi.socket.ins.socketData.T6300F3;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Send6300F3Svo {
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class sendInVo {
        private String loanNo;
        private LocalDateTime chgDtm;
        private BigDecimal tgLen;
        private String tgDsc;
        private BigDecimal bnkTgNo;
        private BigDecimal faTgNo;
        private String kosTgSndNo;
        private LocalDateTime tgSndDtm;
        private LocalDateTime tgRcvDtm;
        private String resCd;
        private String rsrvItmH;
        private String bnkTtlReqNo;
        private String lndPrgsStc;
        private String prgsDt;
        private String sbmtDocLst;
        private BigDecimal mvhrHshldrRno;
        private String mvhrTrgtThngAddr;
        private String mvhrHshldrNmMvinDt;
        private String mvhrdtm;
        private String rsrvItmB;
        private LocalDateTime regDtm;
        private String lnAprvNo2;
    }

    @Data
    public static class Rec6300F3InVo {

        private String loanNo;

        private T6300F3 t6300F3;
    }
}
