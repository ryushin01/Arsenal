package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoSequenceDto;
import com.bankle.common.entity.TbWoSequence;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoSequenceMapper extends DefaultMapper<TbWoSequenceDto, TbWoSequence> {
    TbWoSequenceMapper INSTANCE = Mappers.getMapper(TbWoSequenceMapper.class);
}