package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnDb6200W2}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnDb6200W2Dto implements Serializable {
    TbWoTrnDb6200W2IdDto id;
    BigDecimal tgLen;
    @Size(max = 5)
    String tgDsc;
    @Size(max = 3)
    String resCd;
    @Size(max = 5)
    String lndAgncCd;
    @Size(max = 14)
    String bnkTgTrnsDtm;
    @Size(max = 14)
    String dbTgTrnsDtm;
    @Size(max = 8)
    String bnkTgNo;
    BigDecimal dbTgNo;
    @Size(max = 39)
    String rsrvItmH;
    @Size(max = 20)
    String bnkAskNo;
    @Size(max = 20)
    String dbMngNo;
    @Size(max = 20)
    String kosMngNo;
    @Size(max = 14)
    String kosTgTrnsDtm;
    @Size(max = 14)
    String kosTgNo;
    @Size(max = 2)
    String lndKcd;
    @Size(max = 1)
    String fndYn;
    @Size(max = 1)
    String cnfmtnDsc;
    @Size(max = 2)
    String srvDsc;
    @Size(max = 30)
    String ojtAns;
    @Size(max = 200)
    String sjtAns1;
    @Size(max = 200)
    String sjtAns2;
    @Size(max = 200)
    String sjtAns3;
    @Size(max = 200)
    String sjtAns4;
    @Size(max = 200)
    String sjtAns5;
    @Size(max = 14)
    String slfCtfcAgnc;
    @Size(max = 14)
    String slfCtfcTm;
    @Size(max = 1)
    String resYn;
    @Size(max = 1)
    String optmYn;
    @Size(max = 1)
    String cnfmRsltBnkTrnsYn;
    @Size(max = 14)
    String bnkResDtm;
    @Size(max = 1)
    String lndAmtJstPmntYn;
    @Size(max = 1)
    String rcptJstChrgyn;
    @Size(max = 1)
    String rgstracptThdyYn;
    @Size(max = 50)
    String rgstrErsrAcptNo;
    @Size(max = 1)
    String fxcltEstbsYn;
    @Size(max = 1)
    String fxcltEstbsRnkJstYn;
    @Size(max = 1)
    String fxcltEstbsAmtJstYn;
    @Size(max = 1)
    String acptnoJstYn;
    @Size(max = 1)
    String odprtJstYn;
    @Size(max = 14)
    String rschDtm;
    @Size(max = 20)
    String srchrNm;
    @Size(max = 15)
    String srchrPhno;
    @Size(max = 300)
    String stndRmk;
    @Size(max = 1)
    String lssrMvinhshldYn;
    @Size(max = 1)
    String lssrLssrHvttyn;
    @Size(max = 20)
    String lssrNm;
    @Size(max = 20)
    String lssrRltsp;
    @Size(max = 8)
    String lssrMvinDt;
    @Size(max = 1)
    String lshdrMvinHshldEane;
    @Size(max = 1)
    String lshdrHvttYn;
    @Size(max = 30)
    String lshdrNm;
    @Size(max = 20)
    String lshdrRltsp;
    @Size(max = 8)
    String lshdrMvinDt;
    @Size(max = 1)
    String dbtrSlfMvinYn;
    @Size(max = 1)
    String mvinAddrOptmYn;
    @Size(max = 1)
    String mvinDtOptmYn;
    @Size(max = 1)
    String spusMvinyn;
    @Size(max = 1)
    String dbtrOtsdMvinOptmYn;
    @Size(max = 14)
    String ttlStrdDtm;
    @Size(max = 8)
    String ttlRschDt;
    @Size(max = 40)
    String ttlSrchrNm;
    @Size(max = 8)
    String ttlDrwupDt;
    @Size(max = 296)
    String ttlRmk;
    @Size(max = 15)
    String isrnScrtNo;
    @Size(max = 15)
    String isrnEntrAmt;
    @Size(max = 15)
    String rthisrnPrmm;
    @Size(max = 1)
    String unuslFctExstYn;
    @Size(max = 1)
    String unuslThngYn;
    @Size(max = 1)
    String cndtlExecYn;
    @Size(max = 1)
    String rthRschFnYn;
    @Size(max = 784)
    String rsrvItmB;
    LocalDateTime regDtm;
    @Size(max = 20)
    String lnAprvNo2;
}