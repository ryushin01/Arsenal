package com.bankle.common.wooriApi.socket.ins.sendSvc;

import com.bankle.common.exception.DefaultException;
import com.bankle.common.repo.TbWoTrnFa6500F5Repository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.DateUtil;
import com.bankle.common.utils.StringUtil;
import com.bankle.common.wooriApi.socket.ins.commonSvc.GetSetData;
import com.bankle.common.wooriApi.socket.ins.commonSvc.InsCmnSvc;
import com.bankle.common.wooriApi.socket.ins.commonSvc.vo.InsCmnSvo;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6100F1Svo;
import com.bankle.common.wooriApi.socket.ins.socketData.T6100F1;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springdoc.core.configuration.SpringDocSecurityConfiguration;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;

@Slf4j
@Component
@RequiredArgsConstructor
public class Send6100F1Svc {
    private final TbWoTrnFa6500F5Repository tbWoTrnFa6500F5Repository;

    private final InsCmnSvc insCmnSvc;

    private final BizUtil bizUtil;

    private final String BNK_TG_DSC = "6100";
    private final String TG_DSC = "F1000";
    private final String BNK_CD = "020";
    private final String TR_DSC = "100";
    ////Todo SR 반영시 주석 해제
    private final String TG_LEN = "2700";
    //private final String TG_LEN = "3700";
    private final String BNK_TG_NO = "";
    private final String FA_TG_NO = "";
    private final String RES_CD = "";
    private final String RSRV_ITM_H = "";
    private final String REQ_TG_FN_YN = "Y";
    private final String RES_TG_FN_YN = "N";
    private final GetSetData getSetData;
    private final SpringDocSecurityConfiguration springDocSecurityConfiguration;


    @Transactional
    public CheckResponseSvo sendAndResponse(@Valid Send6100F1Svo.sendInVo invo) throws Exception {
        log.debug("Send6200F2Svc.sendAndResponse().invo : " + invo);
        log.debug("Send6200F2Svc.sendAndResponse().invo : " + invo.getLoanNo());
        String seq = this.send(invo);
        return insCmnSvc.checkResponse(seq);
    }

    @org.springframework.transaction.annotation.Transactional(propagation = Propagation.REQUIRES_NEW)
    public String send(Send6100F1Svo.sendInVo sendInVo) throws Exception {

        try {
            log.debug("Send6100F1Svo.send > sendInVo : " + sendInVo);
            String seq = sendInVo.getKosTgSndNo();
            T6100F1 sendData = new T6100F1();
            sendData.setTG_LEN(TG_LEN);                            // 1. 전문 길이
            sendData.setTG_DSC(BNK_TG_DSC);             // 2. 전문 구분 코드
            sendData.setBNK_TG_NO(sendInVo.getBnkTgNo());           // 3. 우리 은행 전문 번호
            sendData.setFA_TG_NO(sendInVo.getFaTgNo());                        // 4. 보험사 전문 번호
            sendData.setKOS_TG_SND_NO(seq);                        // 5. KOS 관리 번호
            sendData.setTG_SND_DTM(DateUtil.getCurrentDateTime()); // 6. 전문 전송 일시
            sendData.setRES_CD(RES_CD);                            // 7. 응답 코드
            sendData.setRSRV_ITM_H(RSRV_ITM_H);                    // 8. 예약 정보 필드
            sendData.setBNK_TTL_REQ_NO(sendInVo.getBnkTtlReqNo());
            sendData.setLN_APRV_NO(StringUtil.rpad(sendInVo.getLoanNo(), 14, "0"));
            sendData.setTTL_ARD_ENTR_EANE(sendInVo.getTtlArdEntrEane());
            sendData.setTTL_ENTRCMPY(sendInVo.getTtlEntrCmpy());
            sendData.setTTL_SCRT_NO(sendInVo.getTtlScrtNo());
            sendData.setLND_DSC(sendInVo.getLndDsc());             // 9. 대출 구분 코드
            sendData.setLND_KND_CD(sendInVo.getLndKndCd());
            sendData.setFND_USE_CD(sendInVo.getFndUseCd());
            sendData.setBNK_LND_PRDT_CD(sendInVo.getBnkLndPrdtCd());
            sendData.setBNK_LND_PRDT_NM(sendInVo.getBnkLndPrdtNm());
            sendData.setSTND_APL_YN(sendInVo.getStndAplYn());
            sendData.setRRCP_CNFM_YN(sendInVo.getRrcpCnfmYn());
            sendData.setMVHR_CNFM_REQ_YN(sendInVo.getMvhrCnfmReqYn());
            sendData.setBF_SRVTRGT_REQ_YN(sendInVo.getBfSrvtrgtReqYn());
            sendData.setAF_SRVTRGT_REQ_YN(sendInVo.getAfSrvtrgtReqYn());
            sendData.setRGSTR_UNQ_NO_1(sendInVo.getRgstrUnqNo1());
            sendData.setRGSTR_UNQ_NO_2(sendInVo.getRgstrUnqNo2());
            sendData.setRGSTR_UNQ_NO_3(sendInVo.getRgstrUnqNo3());
            sendData.setRGSTR_UNQ_NO_4(sendInVo.getRgstrUnqNo4());
            sendData.setRGSTR_UNQ_NO_5(sendInVo.getRgstrUnqNo5());
            sendData.setRLES_DSC(sendInVo.getRlesDsc());
            sendData.setTRGT_RLES_DSC(sendInVo.getTrgtRlesDsc());
            sendData.setTRGT_RLES_ADDR(sendInVo.getTrgtRlesAddr());
            sendData.setSSCPT_ASK_DT(sendInVo.getSscptAskDt());
            sendData.setLND_PLN_DT(sendInVo.getLndPlnDt());
            sendData.setLND_EXPRD_DT(sendInVo.getLndExprdDt());
            sendData.setSL_PRC(String.valueOf(sendInVo.getSlPrc()));
            sendData.setISRN_ENTR_AMT(String.valueOf(sendInVo.getIsrnEntrAmt()));
            sendData.setLND_AMT(sendInVo.getLndAmt().toString());
            sendData.setBNK_FXCLT_RGSTR_RNK(sendInVo.getBnkFxcltRgstrRnk().toString());
            sendData.setBNK_FXCLT_BND_MAX_AMT(sendInVo.getBnkFxcltBndMaxAmt().toString());
            sendData.setDBTR_NM(sendInVo.getDbtrNm());
            sendData.setDBTR_BIRTH_DT(sendInVo.getDbtrBirthDt());
            sendData.setDBTR_ADDR(sendInVo.getDbtrAddr());
            sendData.setDBTR_PHNO(sendInVo.getDbtrPhno());
            sendData.setDBTR_HPNO(sendInVo.getDbtrHpno());
            sendData.setPWPS_NM(sendInVo.getPwpsNm());
            sendData.setPWPS_BIRTH_DT(sendInVo.getPwpsBirthDt());
            sendData.setPWPS_ADDR(sendInVo.getPwpsAddr());
            sendData.setPWPS_PHNO(sendInVo.getPwpsPhno());
            sendData.setPWPS_HPNO(sendInVo.getPwpsHpno());
            sendData.setRMK_FCT(sendInVo.getRmkFct());
            sendData.setLND_HNDG_SLF_DSC(sendInVo.getLndHndgSlfDsc());
            sendData.setBNK_BRNCH_NM(sendInVo.getBnkBrnchNm());
            sendData.setBNK_DRCTR_NM(sendInVo.getBnkDrctrNm());
            sendData.setBNK_BRNCH_PHNO(sendInVo.getBnkBrnchPhno());
            sendData.setBNK_DRCTR_HP(sendInVo.getBnkDrctrHp());
            sendData.setBNK_BRNCH_FAX(sendInVo.getBnkBrnchFax());
            sendData.setBNK_BRNCH_ADDR(sendInVo.getBnkBrnchAddr());
            sendData.setSLMN_CMPY_NM(sendInVo.getSlmnCmpyNm());
            sendData.setSLMN_NM(sendInVo.getSlmnNm());
            sendData.setSLMN_PHNO(sendInVo.getSlmnPhno());
            sendData.setLWFM_NM(sendInVo.getLwfmNm());
            sendData.setLWFM_BIZNO(sendInVo.getLwfmBizNo());
            sendData.setDBTR_WDNG_PLN_YN(sendInVo.getDbtrWdngPlnYn());
            sendData.setRRCP_CNFM_YN(sendInVo.getRrcpCnfmYn());
            sendData.setRRCP_CNFM_REQ_YN(sendInVo.getRrcpCnfmReqYn());
            sendData.setSPUS_NM(sendInVo.getSpusNm());
            sendData.setWDNG_PLN_DT(sendInVo.getWdngPlnDt());
            sendData.setRSCH_WK_DDLN_REQ_DT(sendInVo.getRschWkDdlnReqDt());
            sendData.setISRN_PRMM(sendInVo.getIsrnPrmm());
            sendData.setRFR_LN_APRV_NO(sendInVo.getRfrLnAprvNo());
            sendData.setRGSTR_MTD_DSC(sendInVo.getRgstrMtdDsc());
            sendData.setRGSTR_REQ_NO(sendInVo.getRgstrReqNo());
            sendData.setODPRT_RPY_EANE(sendInVo.getOdprtaRpyEane());
            sendData.setELTN_ESTBS_LWYR_NM(sendInVo.getEltnEstbsLwyrNm());
            sendData.setELTN_ESTBS_LWYR_BIZNO(sendInVo.getEltnEstbsLwyrBizNo());
            sendData.setELTN_RPY_LOA_APL_YN(sendInVo.getEltnRpyLoaAplYn());
            sendData.setELTN_RPY_LOA_SQN(sendInVo.getEltnRpyLoaSqn());
            sendData.setELTN_RPY_LOA_CTFC_NO(sendInVo.getEltnRpyLoaCtfcNo());
            sendData.setWHL_RPY_CNT(String.valueOf(sendInVo.getWhlRpyCnt()));
            sendData.setWHL_RPY_AMT(String.valueOf(sendInVo.getWhlRpyAmt()));
            sendData.setRPY_TRGT_RNK_NO_1(sendInVo.getRpyTrgtRnkNo1());
            sendData.setRPY_TRGT_ACPT_DT_1(sendInVo.getRpyTrgtAcptDt1());
            sendData.setRPY_TRGT_ACPT_NO_1(sendInVo.getRpyTrgtAcptNo1());
            sendData.setRPY_TRGT_BND_AMT_1(String.valueOf(sendInVo.getRpyTrgtBndAmt1()));
            sendData.setRPY_TRGT_RNK_NO_2(sendInVo.getRpyTrgtRnkNo2());
            sendData.setRPY_TRGT_ACPT_DT_2(sendInVo.getRpyTrgtAcptDt2());
            sendData.setRPY_TRGT_ACPT_NO_2(sendInVo.getRpyTrgtAcptNo2());
            sendData.setRPY_TRGT_BND_AMT_2(String.valueOf(sendInVo.getRpyTrgtBndAmt2()));
            sendData.setRPY_TRGT_RNK_NO_3(sendInVo.getRpyTrgtRnkNo3());
            sendData.setRPY_TRGT_ACPT_DT_3(sendInVo.getRpyTrgtAcptDt3());
            sendData.setRPY_TRGT_ACPT_NO_3(sendInVo.getRpyTrgtAcptNo3());
            sendData.setRPY_TRGT_BND_AMT_3(String.valueOf(sendInVo.getRpyTrgtBndAmt3()));
            sendData.setRPY_TRGT_RNK_NO_4(sendInVo.getRpyTrgtRnkNo4());
            sendData.setRPY_TRGT_ACPT_DT_4(sendInVo.getRpyTrgtAcptDt4());
            sendData.setRPY_TRGT_ACPT_NO_4(sendInVo.getRpyTrgtAcptNo4());
            sendData.setRPY_TRGT_BND_AMT_4(String.valueOf(sendInVo.getRpyTrgtBndAmt4()));
            sendData.setRPY_TRGT_RNK_NO_5(sendInVo.getRpyTrgtRnkNo5());
            sendData.setRPY_TRGT_ACPT_DT_5(sendInVo.getRpyTrgtAcptDt5());
            sendData.setRPY_TRGT_ACPT_NO_5(sendInVo.getRpyTrgtAcptNo5());
            sendData.setRPY_TRGT_BND_AMT_5(String.valueOf(sendInVo.getRpyTrgtBndAmt5()));
            sendData.setAFRGSTR_SCRT_YN(sendInVo.getAfrgstrScrtYn());
            sendData.setRSRV_ITM_B(sendInVo.getRsrvItmB());
            //Todo SR 반영시 주석 해제 line 163 ~ 181
            //sendData.setSLMN_LND_PROC(sendInVo.getSlmnLndProc());
            //sendData.setSR_MEMB_NO(sendInVo.getSrMembNo());
            //sendData.setTR_AMT(String.valueOf(sendInVo.getTrAmt()));
            //sendData.setSLL_NM_1(sendInVo.getSllNm1());
            //sendData.setSLL_BR_DAY_1(sendInVo.getSllBrDay1());
            //sendData.setSLL_NM_2(sendInVo.getSllNm2());
            //sendData.setSLL_BR_DAY_2(sendInVo.getSllBrDay2());
            //sendData.setOWN_LOAN_MAX_AMT(String.valueOf(sendInVo.getOwnLoanMaxAmt()));
            //sendData.setOWN_LOAN_PLN_AMT(String.valueOf(sendInVo.getOwnLoanPlnAmt()));
            //sendData.setOWN_LOAN_BNK_NM_1(sendInVo.getOwnLoanBankNm1());
            //sendData.setOWN_LOAN_BNK_NM_2(sendInVo.getOwnLoanBankNm2());
            //sendData.setOWN_LOAN_BNK_NM_3(sendInVo.getOwnLoanBankNm3());
            //sendData.setOWN_LOAN_BNK_NM_4(sendInVo.getOwnLoanBankNm4());
            //sendData.setOWN_LOAN_BNK_NM_5(sendInVo.getOwnLoanBankNm5());
            //sendData.setCNSGN_NM(sendInVo.getCnsgnNm());
            //sendData.setTRST_NM(sendInVo.getTrstNm());
            //sendData.setBNFR_NM(sendInVo.getBnfrNm());
            //sendData.setNOW_LESS_NM(sendInVo.getNowLessNm());
            log.debug(sendData.toString());
            insCmnSvc.insSend(InsCmnSvo.insCmnInVo.builder()
                    .tgSqn(seq)
                    .bnkTgNo(sendInVo.getBnkTgNo())
                    .bnkCd(BNK_CD)
                    .tgDsc(TG_DSC)
                    .trDsc(TR_DSC)
                    .reqTgCnts(sendData.dataToString())
                    .reqTgLog(sendData.print())
                    .reqTgFnYn(REQ_TG_FN_YN)
                    .resTgFnYn(RES_TG_FN_YN)
                    .loanNo(sendInVo.getLoanNo())
                    .membNo("SYSTEM")
                    .build());

            return seq;
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException("전문 전송 테이블 적재시 오류가 발생했습니다! -> " + e.getMessage());
        }
    }
}
