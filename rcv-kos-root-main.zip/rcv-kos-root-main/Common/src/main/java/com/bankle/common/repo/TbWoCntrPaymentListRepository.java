package com.bankle.common.repo;

import com.bankle.common.entity.TbWoCntrPaymentList;
import com.bankle.common.entity.TbWoCntrPaymentListId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbWoCntrPaymentListRepository extends JpaRepository<TbWoCntrPaymentList, TbWoCntrPaymentListId> {
    List<TbWoCntrPaymentList> findAllById_LoanNoAndDelYn(String loanNo, String delYn);

    Optional<TbWoCntrPaymentList> findById_LoanNoAndPayCd(String loanNo, String payCd);

    Optional<TbWoCntrPaymentList> findById_LoanNoAndPayCdAndBankCd(String loanNo, String payCd, String bankCd);
}