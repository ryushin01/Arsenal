package com.bankle.common.repo;

import com.bankle.common.entity.TbCustMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TbCustMasterRepository extends JpaRepository<TbCustMaster, String> {

    Optional<TbCustMaster> findByMembNo(String membNo);
}