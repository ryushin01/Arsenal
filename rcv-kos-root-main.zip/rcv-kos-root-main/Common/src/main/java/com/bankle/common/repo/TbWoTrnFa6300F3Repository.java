package com.bankle.common.repo;

import com.bankle.common.entity.TbWoTrnFa6300F3;
import com.bankle.common.entity.TbWoTrnFa6300F3Id;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TbWoTrnFa6300F3Repository extends JpaRepository<TbWoTrnFa6300F3, TbWoTrnFa6300F3Id> {
    List<TbWoTrnFa6300F3> findByIdLoanNoOrderByIdChgDtm(String loanNo);
}