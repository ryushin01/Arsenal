package com.bankle.common.dto;

import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbCommCodeDto implements Serializable {
    private String grpCd;
    private String code;
    private String codeNm;
    private String grpNm;
    private String grpDesc;
    private BigDecimal num;
    private String etc1;
    private String etc2;
    private String etc3;
    private String useYn;
    private LocalDateTime crtDtm;
    private String crtMembNo;
    private LocalDateTime chgDtm;
    private String chgMembNo;
}