package com.bankle.common.wooriApi.socket.ins.recSvc.vo;

import com.bankle.common.wooriApi.socket.ins.socketData.T6200F2;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

public class Rec6200F2Svo {

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class recInVo {

        @Schema(name = "여신번호")
        private String loanNo;

        @Schema(name = "FA 마감 처리 구분코드")
        private String procDsc;

        private String tgSqn;

        private String membNo;

        private String membNm;

        private String reqTgCnts;

        private String reqTgLog;

        private LocalDateTime chgDtm;

        private T6200F2 t6200F2;

    }
}
