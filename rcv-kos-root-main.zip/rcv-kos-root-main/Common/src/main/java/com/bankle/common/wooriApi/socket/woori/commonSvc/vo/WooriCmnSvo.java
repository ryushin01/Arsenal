package com.bankle.common.wooriApi.socket.woori.commonSvc.vo;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

public class WooriCmnSvo {

    @Setter
    @Getter
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class sendVo {

        @NotNull(message = "Send : S , Response : R")
        @Size(min = 1, max = 1)
        String jobType;

        @NotNull(message = "seq 는 필수 입력값입니다.")
        @Size(min = 14, max = 14)
        String seq;

        @NotNull(message = "trnName 는 필수 입력값입니다.")
        @Size(max = 50)
        String trnName;

        @NotNull(message = "A100, A200, A300, A400, A500 등등 전문 번호")
        @Size(max = 14)
        String trnKnd;

        @NotNull(message = "TR_TP 코드 - A300에서 사용 70,71,72,73 등등")
        @Size(min = 2, max = 2)
        String trTp;

        @Size(max = 11)
        String loanNo;

        @NotNull
        @Size(max = 3000)
        String reqData;

        @Size(max = 4000)
        String reqDataLog;

        @NotNull
        @Size(max = 1)
        String reqYn;

        @Size(max = 3000)
        String resData;

        @Size(max = 4000)
        String resDataLog;

        @NotNull
        @Size(max = 1)
        String resYn;

        @Size(max = 4)
        String resCode;

        @Size(max = 11)
        String approvalNum;

        @Size(max = 13)
        String membNo;

        @Size(max = 13)
        String reptMembNo;

        @Size(max = 3)
        String bankCode;

        @Size(max = 4)
        String bankResCode;

        @Size(max = 1000)
        String gubun;
        LocalDateTime reqDttm;
        LocalDateTime resDttm;
        @Size(max = 27)
        String imgKey;
        @Size(max = 1000)
        String userAgent;
        @NotNull
        LocalDateTime chgDttm;
        @NotNull
        @Size(max = 13)
        String chgMembNo;
        @NotNull
        LocalDateTime crtDttm;
        @NotNull
        @Size(max = 13)
        String crtMembNo;

        @Size(max = 10)
        String tgDsc;

        @Size(max = 1)
        String trnsStc;
        @Size(max = 500)
        String flPth;
        Integer resendCt;
        @Size(max = 1)
        String dataGbn;
        @Size(max = 2)
        String insGbn;
        @Size(max = 2)
        String insStc;
        @Size(max=14)
        String trSeq;

        @Size(max=13)
        String loNo;
    }

    @Setter
    @Getter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class receiveVo {

        @NotNull(message = "Send : S , Response : R")
        @Size(min = 1, max = 1)
        String jobType;

        @NotNull(message = "seq 는 필수 입력값입니다.")
        @Size(min = 14, max = 14)
        String seq;

        @NotNull(message = "trnName 는 필수 입력값입니다.")
        @Size(max = 50)
        String trnName;

        @NotNull(message = "A100, A200, A300, A400, A500 등등 전문 번호")
        @Size(max = 14)
        String trnKnd;

        @NotNull(message = "TR_TP 코드 - A300에서 사용 70,71,72,73 등등")
        @Size(min = 2, max = 2)
        String trTp;

        @Size(max = 11)
        String loanNo;

        @NotNull
        @Size(max = 3000)
        String reqData;

        @Size(max = 4000)
        String reqDataLog;

        @NotNull
        @Size(max = 1)
        String reqYn;

        @Size(max = 3000)
        String resData;

        @Size(max = 4000)
        String resDataLog;

        @NotNull
        @Size(max = 1)
        String resYn;

        @Size(max = 4)
        String resCode;

        @Size(max = 11)
        String approvalNum;

        @Size(max = 13)
        String membNo;

        @Size(max = 13)
        String reptMembNo;

        @Size(max = 3)
        String bankCode;

        @Size(max = 4)
        String bankResCode;

        @Size(max = 1000)
        String gubun;
        LocalDateTime reqDttm;
        LocalDateTime resDttm;
        @Size(max = 27)
        String imgKey;
        @Size(max = 1000)
        String userAgent;
        @NotNull
        LocalDateTime chgDttm;
        @NotNull
        @Size(max = 13)
        String chgMembNo;
        @NotNull
        LocalDateTime crtDttm;
        @NotNull
        @Size(max = 13)
        String crtMembNo;

        @Size(max = 10)
        String tgDsc;

        @Size(max = 1)
        String trnsStc;
        @Size(max = 500)
        String flPth;
        Integer resendCt;
        @Size(max = 1)
        String dataGbn;
        @Size(max = 2)
        String insGbn;
        @Size(max = 2)
        String insStc;
        @Size(max=14)
        String trSeq;

        @Size(max=13)
        String loNo;
    }
}
