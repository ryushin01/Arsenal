package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnFa6200F2}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnFa6200F2Dto implements Serializable {
    TbWoTrnFa6200F2IdDto id;
    BigDecimal tgLen;
    @Size(max = 4)
    String tgDsc;
    @Size(max = 8)
    String bnkTgNo;
    @Size(max = 8)
    String faTgNo;
    @Size(max = 14)
    String kosTgSndNo;
    @Size(max = 14)
    String tgSndDtm;
    @Size(max = 14)
    String tgRcvDtm;
    @Size(max = 3)
    String resCd;
    @Size(max = 35)
    String rsrvItmH;
    @Size(max = 20)
    String bnkTtlReqNo;
    @Size(max = 2)
    String procDsc;
    @Size(max = 2)
    String lndKndCd;
    @Size(max = 2)
    String fndUseCd;
    @Size(max = 1)
    String lndPmntCnfmSlfCd;
    @Size(max = 1)
    String rcptInfoCnfmSlfCd;
    @Size(max = 1)
    String thdyRgstrAcptNoInptYn;
    @Size(max = 9)
    String estbsRgstrAcptNo1;
    @Size(max = 9)
    String estbsRgstrAcptNo2;
    @Size(max = 9)
    String estbsRgstrAcptNo3;
    @Size(max = 9)
    String ersrAcptNo1;
    @Size(max = 9)
    String ersrAcptNo2;
    @Size(max = 9)
    String ersrAcptNo3;
    @Size(max = 100)
    String rmkB1;
    @Size(max = 1)
    String bnkFxcltEstbsFnYn;
    @Size(max = 1)
    String bnkFxcltRnkMthYn;
    @Size(max = 1)
    String bnkFxcltEstbsNoMthYn;
    @Size(max = 300)
    String rgstAtcpThngAddr;
    @Size(max = 14)
    String rgstrUnqNo1;
    @Size(max = 14)
    String rgstrUnqNo2;
    @Size(max = 14)
    String rgstrUnqNo3;
    @Size(max = 14)
    String rgstrUnqNo4;
    @Size(max = 14)
    String rgstrUnqNo5;
    @Size(max = 8)
    String bnkFxcltRgstrAcptDt;
    @Size(max = 8)
    String ownOwnshMvRgstrAcptDt;
    @Size(max = 50)
    String ownNm1;
    @Size(max = 50)
    String ownNm2;
    @Size(max = 50)
    String ownNm3;
    @Size(max = 13)
    String ownBirthDt1;
    @Size(max = 13)
    String ownBirthDt2;
    @Size(max = 13)
    String ownBirthDt3;
    @Size(max = 150)
    String rmkB2;
    @Size(max = 1)
    String dbtrRrcpSbmtYn;
    @Size(max = 1)
    String dbtrFrcSbmtYn;
    @Size(max = 1)
    String rrcpDbtrSlfRgstYn;
    @Size(max = 1)
    String rrcpSpusRgstYn;
    @Size(max = 1)
    String frcSpusCnfmYn;
    @Size(max = 150)
    String rmkB3;
    @Size(max = 1)
    String dbtrTgrcSbmtYn;
    @Size(max = 1)
    String tgrcDbtrSlfMvinYn;
    @Size(max = 1)
    String tgrcDbtrOtsdSprtHshldEane;
    @Size(max = 1)
    String exedtMvMvinEane;
    @Size(max = 1)
    String bnkDbtrTgrcMthYn;
    @Size(max = 1)
    String nowRenterEvctYn;
    @Size(max = 14)
    String mvinHshldRdDtm;
    @Size(max = 255)
    String rmkB4;
    @Size(max = 30)
    String rschAgncNm;
    @Size(max = 50)
    String srchrNm;
    @Size(max = 20)
    String srchrPhno;
    @Size(max = 14)
    String rschDtm;
    @Size(max = 1)
    String srvRschDsc;
    @Size(max = 50)
    String ojtAns;
    @Size(max = 200)
    String sjtAns1;
    @Size(max = 200)
    String sjtAns2;
    @Size(max = 200)
    String sjtAns3;
    @Size(max = 200)
    String sjtAns4;
    @Size(max = 200)
    String sjtAns5;
    @Size(max = 50)
    String slfCtfcAgnc;
    @Size(max = 12)
    String slfCtfcTm;
    @Size(max = 1)
    String resyn;
    @Size(max = 1)
    String pslCnfmStrdOptmYn;
    @Size(max = 1)
    String pslCnfmRsltBnkTrnsYn;
    @Size(max = 12)
    String pslCnfmRsltBnkRcvTm;
    @Size(max = 1)
    String fstExmnRslt;
    @Size(max = 1)
    String scdExmnRslt;
    @Size(max = 353)
    String rsrvItmB;
    LocalDateTime regDtm;
    @Size(max = 20)
    String lnAprvNo2;
}