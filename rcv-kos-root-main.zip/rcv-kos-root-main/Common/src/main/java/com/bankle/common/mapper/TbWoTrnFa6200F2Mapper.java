package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoTrnFa6200F2Dto;
import com.bankle.common.entity.TbWoTrnFa6200F2;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoTrnFa6200F2Mapper extends DefaultMapper<TbWoTrnFa6200F2Dto, TbWoTrnFa6200F2> {
    TbWoTrnFa6200F2Mapper INSTANCE = Mappers.getMapper(TbWoTrnFa6200F2Mapper.class);
}