package com.bankle.common.wooriApi.socket.ins.socketData;

import java.io.InputStream;

public class T6100W1 extends GetSetData {

    private final String DATE_FORMAT = "yyyyMMddHHmmss";

    private int cntColumn = 0;
    String[] arrName = null;   // Layout Column Name

    byte[] TG_LEN = new byte[8];
    byte[] TG_DSC = new byte[5];
    byte[] RES_CD = new byte[3];
    byte[] LND_AGNC_CD = new byte[5];
    byte[] BNK_TG_TRNS_DTM = new byte[14];
    byte[] DB_TG_TRNS_DTM = new byte[14];
    byte[] BNK_TG_NO = new byte[8];
    byte[] DB_TG_NO = new byte[8];
    byte[] RSRV_ITM_H = new byte[39];
    byte[] BNK_ASK_NO = new byte[20];
    byte[] LN_APRV_NO = new byte[14];
    byte[] DB_MNG_NO = new byte[20];
    byte[] KOS_TG_TRNS_DTM = new byte[14];
    byte[] KOS_TG_NO = new byte[14];
    byte[] PROC_DVSN_CD = new byte[1];
    byte[] RTH_ISRN_ENTR_YN = new byte[1];
    byte[] RTH_ISRN_ENTR_CMPY = new byte[1];
    byte[] RTH_ISRN_SCRT_NO = new byte[30];
    byte[] PST_NO = new byte[6];
    byte[] CRTDN_CD = new byte[10];
    byte[] TRGT_ADDR = new byte[122];
    byte[] TRGT_DTL_ADDR = new byte[122];
    byte[] RGSTR_UNQ_NO_1 = new byte[14];
    byte[] RGSTR_UNQ_NO_2 = new byte[14];
    byte[] RGSTR_UNQ_NO_3 = new byte[14];
    byte[] LND_KND_CD = new byte[2];
    byte[] FND_YN = new byte[1];
    byte[] PRDT_NM = new byte[200];
    byte[] PRDT_CD = new byte[20];
    byte[] GRNT_AGNC_CD = new byte[2];
    byte[] SRV_TRGT_YN = new byte[1];
    byte[] STND_TRGT_YN = new byte[1];
    byte[] RRCP_CHRG_TRGT_YN = new byte[1];
    byte[] RVSN_CNTRCT_CHRG_TRGT_YN = new byte[1];
    byte[] SSCPT_ASK_DT = new byte[8];
    byte[] LND_PLN_DT = new byte[8];
    byte[] RNTL_PRD_END_DT = new byte[8];
    byte[] LND_EXPRD_DT = new byte[8];
    byte[] LND_PRD = new byte[3];
    byte[] LND_AMT = new byte[15];
    byte[] ISRN_ENTR_AMT = new byte[15];
    byte[] OBJT_EBNK_RGSTR_RNK = new byte[20];
    byte[] OBJT_EBNK_BND_MAX_AMT = new byte[50];
    byte[] MGG_FNL_ODPRT_AMT = new byte[20];
    byte[] TROL_FNL_ODPRT_AMT = new byte[20];
    byte[] SRVC_END_DT = new byte[8];
    byte[] DBTR_NM = new byte[52];
    byte[] DBTR_RRNO = new byte[13];
    byte[] DBTR_PST_NO = new byte[5];
    byte[] DBTR_ADDR = new byte[244];
    byte[] DBTR_PHNO = new byte[20];
    byte[] DBTR_HPNO = new byte[20];
    byte[] WDNG_PLN_YN = new byte[1];
    byte[] WDNG_PLN_DT = new byte[8];
    byte[] HSHLDR_CNDDT_YN = new byte[1];
    byte[] UNMRD_HSHLDR_25AG_LSTN_YN = new byte[1];
    byte[] ACPT_DSC = new byte[1];
    byte[] LWFM_NM = new byte[42];
    byte[] LWFM_BIZNO = new byte[20];
    byte[] ASK_BRNCH_CD = new byte[20];
    byte[] ASK_BRNCH_NM = new byte[42];
    byte[] ASK_BRNCH_DRCTR_NM = new byte[42];
    byte[] ASK_BRNCH_PHNO = new byte[20];
    byte[] BNK_LES_DSC = new byte[2];
    byte[] FND_LES_DSC = new byte[2];
    byte[] CNDTL_CNTS = new byte[100];
    byte[] ISRN_PRMM = new byte[15];
    byte[] RSRV_ITM_B = new byte[900];

    public T6100W1() {
        setData(this.TG_LEN, "");
        setData(this.TG_DSC, "");
        setData(this.RES_CD, "");
        setData(this.LND_AGNC_CD, "");
        setData(this.BNK_TG_TRNS_DTM, "");
        setData(this.DB_TG_TRNS_DTM, "");
        setData(this.BNK_TG_NO, "");
        setData(this.DB_TG_NO, "");
        setData(this.RSRV_ITM_H, "");
        setData(this.BNK_ASK_NO, "");
        setData(this.LN_APRV_NO, "");
        setData(this.DB_MNG_NO, "");
        setData(this.KOS_TG_TRNS_DTM, "");
        setData(this.KOS_TG_NO, "");
        setData(this.PROC_DVSN_CD, "");
        setData(this.RTH_ISRN_ENTR_YN, "");
        setData(this.RTH_ISRN_ENTR_CMPY, "");
        setData(this.RTH_ISRN_SCRT_NO, "");
        setData(this.PST_NO, "");
        setData(this.CRTDN_CD, "");
        setData(this.TRGT_ADDR, "");
        setData(this.TRGT_DTL_ADDR, "");
        setData(this.RGSTR_UNQ_NO_1, "");
        setData(this.RGSTR_UNQ_NO_2, "");
        setData(this.RGSTR_UNQ_NO_3, "");
        setData(this.LND_KND_CD, "");
        setData(this.FND_YN, "");
        setData(this.PRDT_NM, "");
        setData(this.PRDT_CD, "");
        setData(this.GRNT_AGNC_CD, "");
        setData(this.SRV_TRGT_YN, "");
        setData(this.STND_TRGT_YN, "");
        setData(this.RRCP_CHRG_TRGT_YN, "");
        setData(this.RVSN_CNTRCT_CHRG_TRGT_YN, "");
        setData(this.SSCPT_ASK_DT, "");
        setData(this.LND_PLN_DT, "");
        setData(this.RNTL_PRD_END_DT, "");
        setData(this.LND_EXPRD_DT, "");
        setData(this.LND_PRD, "");
        setData(this.LND_AMT, "");
        setData(this.ISRN_ENTR_AMT, "");
        setData(this.OBJT_EBNK_RGSTR_RNK, "");
        setData(this.OBJT_EBNK_BND_MAX_AMT, "");
        setData(this.MGG_FNL_ODPRT_AMT, "");
        setData(this.TROL_FNL_ODPRT_AMT, "");
        setData(this.SRVC_END_DT, "");
        setData(this.DBTR_NM, "");
        setData(this.DBTR_RRNO, "");
        setData(this.DBTR_PST_NO, "");
        setData(this.DBTR_ADDR, "");
        setData(this.DBTR_PHNO, "");
        setData(this.DBTR_HPNO, "");
        setData(this.WDNG_PLN_YN, "");
        setData(this.WDNG_PLN_DT, "");
        setData(this.HSHLDR_CNDDT_YN, "");
        setData(this.UNMRD_HSHLDR_25AG_LSTN_YN, "");
        setData(this.ACPT_DSC, "");
        setData(this.LWFM_NM, "");
        setData(this.LWFM_BIZNO, "");
        setData(this.ASK_BRNCH_CD, "");
        setData(this.ASK_BRNCH_NM, "");
        setData(this.ASK_BRNCH_DRCTR_NM, "");
        setData(this.ASK_BRNCH_PHNO, "");
        setData(this.BNK_LES_DSC, "");
        setData(this.FND_LES_DSC, "");
        setData(this.CNDTL_CNTS, "");
        setData(this.ISRN_PRMM, "");
        setData(this.RSRV_ITM_B, "");
    }


    public String getTG_LEN() {
        return getData(TG_LEN);
    }

    public String getTG_DSC() {
        return getData(TG_DSC);
    }

    public String getRES_CD() {
        return getData(RES_CD);
    }

    public String getLND_AGNC_CD() {
        return getData(LND_AGNC_CD);
    }

    public String getBNK_TG_NO() {
        return getData(BNK_TG_NO);
    }

    public String getBNK_TG_TRNS_DTM() {
        return getData(BNK_TG_TRNS_DTM);
    }

    public String getDB_TG_NO() {
        return getData(DB_TG_NO);
    }

    public String getRSRV_ITM_H() {
        return getData(RSRV_ITM_H);
    }

    public String getBNK_ASK_NO() {
        return getData(BNK_ASK_NO);
    }

    public String getLN_APRV_NO() {
        return getData(LN_APRV_NO);
    }

    public String getDB_MNG_NO() {
        return getData(DB_MNG_NO);
    }

    public String getKOS_TG_TRNS_DTM() {
        return getData(KOS_TG_TRNS_DTM);
    }

    public String getKOS_TG_NO() {
        return getData(KOS_TG_NO);
    }

    public String getPROC_DVSN_CD() {
        return getData(PROC_DVSN_CD);
    }

    public String getRTH_ISRN_ENTR_YN() {
        return getData(RTH_ISRN_ENTR_YN);
    }

    public String getRTH_ISRN_ENTR_CMPY() {
        return getData(RTH_ISRN_ENTR_CMPY);
    }

    public String getRTH_ISRN_SCRT_NO() {
        return getData(RTH_ISRN_SCRT_NO);
    }

    public String getPST_NO() {
        return getData(PST_NO);
    }

    public String getCRTDN_CD() {
        return getData(CRTDN_CD);
    }

    public String getTRGT_ADDR() {
        return getData(TRGT_ADDR);
    }

    public String getTRGT_DTL_ADDR() {
        return getData(TRGT_DTL_ADDR);
    }

    public String getRGSTR_UNQ_NO_1() {
        return getData(RGSTR_UNQ_NO_1);
    }

    public String getRGSTR_UNQ_NO_2() {
        return getData(RGSTR_UNQ_NO_2);
    }

    public String getRGSTR_UNQ_NO_3() {
        return getData(RGSTR_UNQ_NO_3);
    }

    public String getLND_KND_CD() {
        return getData(LND_KND_CD);
    }

    public String getFND_YN() {
        return getData(FND_YN);
    }

    public String getPRDT_NM() {
        return getData(PRDT_NM);
    }

    public String getPRDT_CD() {
        return getData(PRDT_CD);
    }

    public String getGRNT_AGNC_CD() {
        return getData(GRNT_AGNC_CD);
    }

    public String getSRV_TRGT_YN() {
        return getData(SRV_TRGT_YN);
    }

    public String getSTND_TRGT_YN() {
        return getData(STND_TRGT_YN);
    }

    public String getRRCP_CHRG_TRGT_YN() {
        return getData(RRCP_CHRG_TRGT_YN);
    }

    public String getRVSN_CNTRCT_CHRG_TRGT_YN() {
        return getData(RVSN_CNTRCT_CHRG_TRGT_YN);
    }

    public String getSSCPT_ASK_DT() {
        return getData(SSCPT_ASK_DT);
    }

    public String getLND_PLN_DT() {
        return getData(LND_PLN_DT);
    }

    public String getRNTL_PRD_END_DT() {
        return getData(RNTL_PRD_END_DT);
    }

    public String getLND_EXPRD_DT() {
        return getData(LND_EXPRD_DT);
    }

    public String getLND_PRD() {
        return getData(LND_PRD);
    }

    public String getLND_AMT() {
        return getData(LND_AMT);
    }

    public String getISRN_ENTR_AMT() {
        return getData(ISRN_ENTR_AMT);
    }

    public String getOBJT_EBNK_RGSTR_RNK() {
        return getData(OBJT_EBNK_RGSTR_RNK);
    }

    public String getOBJT_EBNK_BND_MAX_AMT() {
        return getData(OBJT_EBNK_BND_MAX_AMT);
    }

    public String getMGG_FNL_ODPRT_AMT() {
        return getData(MGG_FNL_ODPRT_AMT);
    }

    public String getTROL_FNL_ODPRT_AMT() {

        return getData(TROL_FNL_ODPRT_AMT);
    }

    public String getSRVC_END_DT() {
        return getData(SRVC_END_DT);
    }

    public String getDBTR_NM() {
        return getData(DBTR_NM);
    }

    public String getDBTR_RRNO() {
        return getData(DBTR_RRNO);
    }

    public String getDBTR_PST_NO() {
        return getData(DBTR_PST_NO);
    }

    public String getDBTR_ADDR() {
        return getData(DBTR_ADDR);
    }

    public String getDBTR_PHNO() {
        return getData(DBTR_PHNO);
    }

    public String getDBTR_HPNO() {
        return getData(DBTR_HPNO);
    }

    public String getWDNG_PLN_YN() {
        return getData(WDNG_PLN_YN);
    }

    public String getWDNG_PLN_DT() {
        return getData(WDNG_PLN_DT);
    }

    public String getHSHLDR_CNDDT_YN() {
        return getData(HSHLDR_CNDDT_YN);
    }

    public String getUNMRD_HSHLDR_25AG_LSTN_YN() {
        return getData(UNMRD_HSHLDR_25AG_LSTN_YN);
    }

    public String getACPT_DSC() {
        return getData(ACPT_DSC);
    }

    public String getLWFM_NM() {
        return getData(LWFM_NM);
    }

    public String getLWFM_BIZNO() {
        return getData(LWFM_BIZNO);
    }

    public String getASK_BRNCH_CD() {
        return getData(ASK_BRNCH_CD);
    }

    public String getASK_BRNCH_NM() {
        return getData(ASK_BRNCH_NM);
    }

    public String getASK_BRNCH_DRCTR_NM() {
        return getData(ASK_BRNCH_DRCTR_NM);
    }

    public String getASK_BRNCH_PHNO() {
        return getData(ASK_BRNCH_PHNO);
    }

    public String getBNK_LES_DSC() {
        return getData(BNK_LES_DSC);
    }

    public String getFND_LES_DSC() {
        return getData(FND_LES_DSC);
    }

    public String getCNDTL_CNTS() {
        return getData(CNDTL_CNTS);
    }

    public String getISRN_PRMM() {
        return getData(ISRN_PRMM);
    }

    public String getRSRV_ITM_B() {
        return getData(RSRV_ITM_B);
    }

    public void setTG_LEN(String TG_LEN) {
        setData(this.TG_LEN, TG_LEN, "N");
    }

    public void setTG_DSC(String TG_DSC) {
        setData(this.TG_DSC, TG_DSC, "S");
    }

    public void setRES_CD(String RES_CD) {
        setData(this.RES_CD, RES_CD, "S");
    }

    public void setLND_AGNC_CD(String LND_AGNC_CD) {
        setData(this.LND_AGNC_CD, LND_AGNC_CD, "S");
    }

    public void setBNK_TG_TRNS_DTM(String BNK_TG_TRNS_DTM) {
        setData(this.BNK_TG_TRNS_DTM, BNK_TG_TRNS_DTM, "S");
    }

    public void setBNK_TG_NO(String BNK_TG_NO) {
        setData(this.BNK_TG_NO, BNK_TG_NO, "S");
    }

    public void setDB_TG_NO(String DB_TG_NO) {
        setData(this.DB_TG_NO, DB_TG_NO, "N");
    }

    public void setRSRV_ITM_H(String RSRV_ITM_H) {
        setData(this.RSRV_ITM_H, RSRV_ITM_H, "K");
    }

    public void setBNK_ASK_NO(String BNK_ASK_NO) {
        setData(this.BNK_ASK_NO, BNK_ASK_NO, "S");
    }

    public void setLN_APRV_NO(String LN_APRV_NO) {
        setData(this.LN_APRV_NO, LN_APRV_NO, "S");
    }

    public void setDB_MNG_NO(String DB_MNG_NO) {
        setData(this.DB_MNG_NO, DB_MNG_NO, "S");
    }

    public void setKOS_TG_TRNS_DTM(String KOS_TG_TRNS_DTM) {
        setData(this.KOS_TG_TRNS_DTM, KOS_TG_TRNS_DTM, "S");
    }

    public void setKOS_TG_NO(String KOS_TG_NO) {
        setData(this.KOS_TG_NO, KOS_TG_NO, "S");
    }

    public void setPROC_DVSN_CD(String PROC_DVSN_CD) {
        setData(this.PROC_DVSN_CD, PROC_DVSN_CD, "S");
    }

    public void setRTH_ISRN_ENTR_YN(String RTH_ISRN_ENTR_YN) {
        setData(this.RTH_ISRN_ENTR_YN, RTH_ISRN_ENTR_YN, "S");
    }

    public void setRTH_ISRN_ENTR_CMPY(String RTH_ISRN_ENTR_CMPY) {
        setData(this.RTH_ISRN_ENTR_CMPY, RTH_ISRN_ENTR_CMPY, "S");
    }

    public void setRTH_ISRN_SCRT_NO(String RTH_ISRN_SCRT_NO) {
        setData(this.RTH_ISRN_SCRT_NO, RTH_ISRN_SCRT_NO, "K");
    }

    public void setPST_NO(String PST_NO) {
        setData(this.PST_NO, PST_NO, "S");
    }

    public void setCRTDN_CD(String CRTDN_CD) {
        setData(this.CRTDN_CD, CRTDN_CD, "S");
    }

    public void setTRGT_ADDR(String TRGT_ADDR) {

        setData(this.TRGT_ADDR, TRGT_ADDR, "K");
    }

    public void setTRGT_DTL_ADDR(String TRGT_DTL_ADDR) {
        setData(this.TRGT_DTL_ADDR, TRGT_DTL_ADDR, "K");
    }

    public void setRGSTR_UNQ_NO_1(String RGSTR_UNQ_NO_1) {
        setData(this.RGSTR_UNQ_NO_1, RGSTR_UNQ_NO_1, "N");
    }

    public void setRGSTR_UNQ_NO_2(String RGSTR_UNQ_NO_2) {
        setData(this.RGSTR_UNQ_NO_2, RGSTR_UNQ_NO_2, "N");
    }

    public void setRGSTR_UNQ_NO_3(String RGSTR_UNQ_NO_3) {
        setData(this.RGSTR_UNQ_NO_3, RGSTR_UNQ_NO_3, "N");
    }

    public void setLND_KND_CD(String LND_KND_CD) {
        setData(this.LND_KND_CD, LND_KND_CD, "S");
    }

    public void setFND_YN(String FND_YN) {
        setData(this.FND_YN, FND_YN, "S");
    }

    public void setPRDT_NM(String PRDT_NM) {
        setData(this.PRDT_NM, PRDT_NM, "K");
    }

    public void setPRDT_CD(String PRDT_CD) {
        setData(this.PRDT_CD, PRDT_CD, "K");
    }

    public void setGRNT_AGNC_CD(String GNNT_AGNC_CD) {
        setData(this.GRNT_AGNC_CD, GNNT_AGNC_CD, "S");
    }

    public void setSRV_TRGT_YN(String SRV_TRGT_YN) {
        setData(this.SRV_TRGT_YN, SRV_TRGT_YN, "S");
    }

    public void setSTND_TRGT_YN(String STND_TRGT_YN) {
        setData(this.STND_TRGT_YN, STND_TRGT_YN, "S");
    }

    public void setRRCP_CHRG_TRGT_YN(String RRCP_CHRG_TRGT_YN) {
        setData(this.RRCP_CHRG_TRGT_YN, RRCP_CHRG_TRGT_YN, "S");
    }

    public void setRVSN_CNTRCT_CHRG_TRGT_YN(String RVSN_CNTRCT_CHRG_TRGT_YN) {

        setData(this.RVSN_CNTRCT_CHRG_TRGT_YN, RVSN_CNTRCT_CHRG_TRGT_YN, "S");
    }

    public void setSSCPT_ASK_DT(String SSCPT_ASK_DT) {
        setData(this.SSCPT_ASK_DT, SSCPT_ASK_DT, "S");
    }

    public void setLND_PLN_DT(String LND_PLN_DT) {
        setData(this.LND_PLN_DT, LND_PLN_DT, "S");
    }

    public void setRNTL_PRD_END_DT(String RNTL_PRD_END_DT) {
        setData(this.RNTL_PRD_END_DT, RNTL_PRD_END_DT, "S");
    }

    public void setLND_EXPRD_DT(String LND_EXPRD_DT) {
        setData(this.LND_EXPRD_DT, LND_EXPRD_DT, "S");
    }

    public void setLND_PRD(String LND_PRD) {
        setData(this.LND_PRD, LND_PRD, "N");
    }

    public void setLND_AMT(String LND_AMT) {
        setData(this.LND_AMT, LND_AMT, "N");
    }

    public void setISRN_ENTR_AMT(String ISRN_ENTR_AMT) {
        setData(this.ISRN_ENTR_AMT, ISRN_ENTR_AMT, "N");
    }

    public void setOBJT_EBNK_RGSTR_RNK(String OBJT_EBNK_RGSTR_RNK) {
        setData(this.OBJT_EBNK_RGSTR_RNK, OBJT_EBNK_RGSTR_RNK, "N");
    }

    public void setOBJT_EBNK_BND_MAX_AMT(String OBJT_EBNK_BND_MAX_AMT) {
        setData(this.OBJT_EBNK_BND_MAX_AMT, OBJT_EBNK_BND_MAX_AMT, "N");
    }

    public void setMGG_FNL_ODPRT_AMT(String MGG_FNL_ODPRT_AMT) {
        setData(this.MGG_FNL_ODPRT_AMT, MGG_FNL_ODPRT_AMT, "N");
    }

    public void setTROL_FNL_ODPRT_AMT(String TROL_FNL_ODPRT_AMT) {
        setData(this.TROL_FNL_ODPRT_AMT, TROL_FNL_ODPRT_AMT, "N");
    }

    public void setSRVC_END_DT(String SRVC_END_DT) {
        setData(this.SRVC_END_DT, SRVC_END_DT, "S");
    }

    public void setDBTR_NM(String DBTR_NM) {
        setData(this.DBTR_NM, DBTR_NM, "K");
    }

    public void setDBTR_RRNO(String DBTR_RRNO) {
        setData(this.DBTR_RRNO, DBTR_RRNO, "S");
    }

    public void setDBTR_PST_NO(String DBTR_PST_NO) {
        setData(this.DBTR_PST_NO, DBTR_PST_NO, "S");
    }

    public void setDBTR_ADDR(String DBTR_ADDR) {
        setData(this.DBTR_ADDR, DBTR_ADDR, "K");
    }

    public void setDBTR_PHNO(String DBTR_PHNO) {
        setData(this.DBTR_PHNO, DBTR_PHNO, "S");
    }

    public void setDBTR_HPNO(String DBTR_HPNO) {
        setData(this.DBTR_HPNO, DBTR_HPNO, "S");
    }

    public void setWDNG_PLN_YN(String WDNG_PLN_YN) {
        setData(this.WDNG_PLN_YN, WDNG_PLN_YN, "S");
    }

    public void setWDNG_PLN_DT(String WDNG_PLN_DT) {
        setData(this.WDNG_PLN_DT, WDNG_PLN_DT, "S");
    }

    public void setHSHLDR_CNDDT_YN(String HSHLDR_CNDDT_YN) {
        setData(this.HSHLDR_CNDDT_YN, HSHLDR_CNDDT_YN, "K");
    }

    public void setUNMRD_HSHLDR_25AG_LSTN_YN(String UNMRD_HSHLDR_25AG_LSTN_YN) {

        setData(this.UNMRD_HSHLDR_25AG_LSTN_YN, UNMRD_HSHLDR_25AG_LSTN_YN, "K");
    }

    public void setACPT_DSC(String ACPT_DSC) {
        setData(this.ACPT_DSC, ACPT_DSC, "S");
    }

    public void setLWFM_NM(String LWFM_NM) {
        setData(this.LWFM_NM, LWFM_NM, "K");
    }

    public void setLWFM_BIZNO(String LWFM_BIZNO) {
        setData(this.LWFM_BIZNO, LWFM_BIZNO, "S");
    }

    public void setASK_BRNCH_CD(String ASK_BRNCH_CD) {
        setData(this.ASK_BRNCH_CD, ASK_BRNCH_CD, "K");
    }

    public void setASK_BRNCH_NM(String ASK_BRNCH_NM) {
        setData(this.ASK_BRNCH_NM, ASK_BRNCH_NM, "K");
    }

    public void setASK_BRNCH_DRCTR_NM(String ASK_BRNCH_DRCTR_NM) {
        setData(this.ASK_BRNCH_DRCTR_NM, ASK_BRNCH_DRCTR_NM, "K");
    }

    public void setASK_BRNCH_PHNO(String ASK_BRNCH_PHNO) {
        setData(this.ASK_BRNCH_PHNO, ASK_BRNCH_PHNO, "S");
    }

    public void setBNK_LES_DSC(String BNK_LES_DSC) {
        setData(this.BNK_LES_DSC, BNK_LES_DSC, "S");
    }

    public void setFND_LES_DSC(String FND_LES_DSC) {
        setData(this.FND_LES_DSC, FND_LES_DSC, "S");
    }

    public void setCNDTL_CNTS(String CNDTL_CNTS) {
        setData(this.CNDTL_CNTS, CNDTL_CNTS, "K");
    }

    public void setISRN_PRMM(String ISRN_PRMM) {
        setData(this.ISRN_PRMM, ISRN_PRMM, "S");
    }

    public void setRSRV_ITM_B(String RSRV_ITM_B) {
        setData(this.RSRV_ITM_B, RSRV_ITM_B, "K");
    }

    public String dataToString() {
        return getData(TG_LEN) + getData(TG_DSC) + getData(RES_CD) + getData(LND_AGNC_CD) + getData(BNK_TG_TRNS_DTM) +
                getData(DB_TG_TRNS_DTM) + getData(BNK_TG_NO) + getData(DB_TG_NO) + getData(RSRV_ITM_H) + getData(BNK_ASK_NO) +
                getData(LN_APRV_NO) + getData(DB_MNG_NO) + getData(KOS_TG_TRNS_DTM) + getData(KOS_TG_NO) + getData(PROC_DVSN_CD) +
                getData(RTH_ISRN_ENTR_YN) + getData(RTH_ISRN_ENTR_CMPY) + getData(RTH_ISRN_SCRT_NO) + getData(PST_NO) + getData(CRTDN_CD) +
                getData(TRGT_ADDR) + getData(TRGT_DTL_ADDR) + getData(RGSTR_UNQ_NO_1) + getData(RGSTR_UNQ_NO_2) + getData(RGSTR_UNQ_NO_3) +
                getData(LND_KND_CD) + getData(FND_YN) + getData(PRDT_NM) + getData(PRDT_CD) + getData(GRNT_AGNC_CD) +
                getData(SRV_TRGT_YN) + getData(STND_TRGT_YN) + getData(RRCP_CHRG_TRGT_YN) + getData(RVSN_CNTRCT_CHRG_TRGT_YN) + getData(SSCPT_ASK_DT) +
                getData(LND_PLN_DT) + getData(RNTL_PRD_END_DT) + getData(LND_EXPRD_DT) + getData(LND_PRD) + getData(LND_AMT) +
                getData(ISRN_ENTR_AMT) + getData(OBJT_EBNK_RGSTR_RNK) + getData(OBJT_EBNK_BND_MAX_AMT) + getData(MGG_FNL_ODPRT_AMT) +
                getData(TROL_FNL_ODPRT_AMT) + getData(SRVC_END_DT) + getData(DBTR_NM) + getData(DBTR_RRNO) + getData(DBTR_PST_NO) +
                getData(DBTR_ADDR) + getData(DBTR_PHNO) + getData(DBTR_HPNO) + getData(WDNG_PLN_YN) + getData(WDNG_PLN_DT) +
                getData(HSHLDR_CNDDT_YN) + getData(UNMRD_HSHLDR_25AG_LSTN_YN) + getData(ACPT_DSC) + getData(LWFM_NM) + getData(LWFM_BIZNO) +
                getData(ASK_BRNCH_CD) + getData(ASK_BRNCH_NM) + getData(ASK_BRNCH_DRCTR_NM) + getData(ASK_BRNCH_PHNO) + getData(BNK_LES_DSC) +
                getData(FND_LES_DSC) + getData(CNDTL_CNTS) + getData(ISRN_PRMM) + getData(RSRV_ITM_B); //To change body of generated methods, choose Tools | Templates.
    }

    public String print() {

        StringBuffer sb = new StringBuffer();
        sb.append("TG_LEN        	 	        : " + "\tSize " + TG_LEN.length + " : " + getData(TG_LEN) + "\n");
        sb.append("TG_DSC                       : " + "\tSize " + TG_DSC.length + " : " + getData(TG_DSC) + "\n");
        sb.append("RES_CD                       : " + "\tSize " + RES_CD.length + " : " + getData(RES_CD) + "\n");
        sb.append("LND_AGNC_CD                  : " + "\tSize " + LND_AGNC_CD.length + " : " + getData(LND_AGNC_CD) + "\n");
        sb.append("BNK_TG_TRNS_DTM              : " + "\tSize " + BNK_TG_TRNS_DTM.length + " : " + getData(BNK_TG_TRNS_DTM) + "\n");
        sb.append("DB_TG_TRNS_DTM               : " + "\tSize " + DB_TG_TRNS_DTM.length + " : " + getData(DB_TG_TRNS_DTM) + "\n");
        sb.append("BNK_TG_NO                    : " + "\tSize " + BNK_TG_NO.length + " : " + getData(BNK_TG_NO) + "\n");
        sb.append("DB_TG_NO                     : " + "\tSize " + DB_TG_NO.length + " : " + getData(DB_TG_NO) + "\n");
        sb.append("RSRV_ITM_H                   : " + "\tSize " + RSRV_ITM_H.length + " : " + getData(RSRV_ITM_H) + "\n");
        sb.append("BNK_ASK_NO                   : " + "\tSize " + BNK_ASK_NO.length + " : " + getData(BNK_ASK_NO) + "\n");
        sb.append("LN_APRV_NO        	 	    : " + "\tSize " + LN_APRV_NO.length + " : " + getData(LN_APRV_NO) + "\n");
        sb.append("DB_MNG_NO                    : " + "\tSize " + DB_MNG_NO.length + " : " + getData(DB_MNG_NO) + "\n");
        sb.append("KOS_TG_TRNS_DTM              : " + "\tSize " + KOS_TG_TRNS_DTM.length + " : " + getData(KOS_TG_TRNS_DTM) + "\n");
        sb.append("KOS_TG_NO                    : " + "\tSize " + KOS_TG_NO.length + " : " + getData(KOS_TG_NO) + "\n");
        sb.append("PROC_DVSN_CD                 : " + "\tSize " + PROC_DVSN_CD.length + " : " + getData(PROC_DVSN_CD) + "\n");
        sb.append("RTH_ISRN_ENTR_YN             : " + "\tSize " + RTH_ISRN_ENTR_YN.length + " : " + getData(RTH_ISRN_ENTR_YN) + "\n");
        sb.append("RTH_ISRN_ENTR_CMPY           : " + "\tSize " + RTH_ISRN_ENTR_CMPY.length + " : " + getData(RTH_ISRN_ENTR_CMPY) + "\n");
        sb.append("RTH_ISRN_SCRT_NO             : " + "\tSize " + RTH_ISRN_SCRT_NO.length + " : " + getData(RTH_ISRN_SCRT_NO) + "\n");
        sb.append("PST_NO                       : " + "\tSize " + PST_NO.length + " : " + getData(PST_NO) + "\n");
        sb.append("CRTDN_CD                     : " + "\tSize " + CRTDN_CD.length + " : " + getData(CRTDN_CD) + "\n");
        sb.append("TRGT_ADDR                    : " + "\tSize " + TRGT_ADDR.length + " : " + getData(TRGT_ADDR) + "\n");
        sb.append("TRGT_DTL_ADDR                : " + "\tSize " + TRGT_DTL_ADDR.length + " : " + getData(TRGT_DTL_ADDR) + "\n");
        sb.append("RGSTR_UNQ_NO_1               : " + "\tSize " + RGSTR_UNQ_NO_1.length + " : " + getData(RGSTR_UNQ_NO_1) + "\n");
        sb.append("RGSTR_UNQ_NO_2               : " + "\tSize " + RGSTR_UNQ_NO_2.length + " : " + getData(RGSTR_UNQ_NO_2) + "\n");
        sb.append("RGSTR_UNQ_NO_3               : " + "\tSize " + RGSTR_UNQ_NO_3.length + " : " + getData(RGSTR_UNQ_NO_3) + "\n");
        sb.append("LND_KND_CD                   : " + "\tSize " + LND_KND_CD.length + " : " + getData(LND_KND_CD) + "\n");
        sb.append("FND_YN                       : " + "\tSize " + FND_YN.length + " : " + getData(FND_YN) + "\n");
        sb.append("PRDT_NM                      : " + "\tSize " + PRDT_NM.length + " : " + getData(PRDT_NM) + "\n");
        sb.append("PRDT_CD                      : " + "\tSize " + PRDT_CD.length + " : " + getData(PRDT_CD) + "\n");
        sb.append("GRNT_AGNC_CD                 : " + "\tSize " + GRNT_AGNC_CD.length + " : " + getData(GRNT_AGNC_CD) + "\n");
        sb.append("SRV_TRGT_YN                  : " + "\tSize " + SRV_TRGT_YN.length + " : " + getData(SRV_TRGT_YN) + "\n");
        sb.append("STND_TRGT_YN                 : " + "\tSize " + STND_TRGT_YN.length + " : " + getData(STND_TRGT_YN) + "\n");
        sb.append("RRCP_CHRG_TRGT_YN            : " + "\tSize " + RRCP_CHRG_TRGT_YN.length + " : " + getData(RRCP_CHRG_TRGT_YN) + "\n");
        sb.append("RVSN_CNTRCT_CHRG_TRGT_YN     : " + "\tSize " + RVSN_CNTRCT_CHRG_TRGT_YN.length + " : " + getData(RVSN_CNTRCT_CHRG_TRGT_YN) + "\n");
        sb.append("SSCPT_ASK_DT                 : " + "\tSize " + SSCPT_ASK_DT.length + " : " + getData(SSCPT_ASK_DT) + "\n");
        sb.append("LND_PLN_DT                   : " + "\tSize " + LND_PLN_DT.length + " : " + getData(LND_PLN_DT) + "\n");
        sb.append("RNTL_PRD_END_DT              : " + "\tSize " + RNTL_PRD_END_DT.length + " : " + getData(RNTL_PRD_END_DT) + "\n");
        sb.append("LND_EXPRD_DT                 : " + "\tSize " + LND_EXPRD_DT.length + " : " + getData(LND_EXPRD_DT) + "\n");
        sb.append("LND_PRD                      : " + "\tSize " + LND_PRD.length + " : " + getData(LND_PRD) + "\n");
        sb.append("LND_AMT                      : " + "\tSize " + LND_AMT.length + " : " + getData(LND_AMT) + "\n");
        sb.append("ISRN_ENTR_AMT                : " + "\tSize " + ISRN_ENTR_AMT.length + " : " + getData(ISRN_ENTR_AMT) + "\n");
        sb.append("OBJT_EBNK_RGSTR_RNK          : " + "\tSize " + OBJT_EBNK_RGSTR_RNK.length + " : " + getData(OBJT_EBNK_RGSTR_RNK) + "\n");
        sb.append("OBJT_EBNK_BND_MAX_AMT        : " + "\tSize " + OBJT_EBNK_BND_MAX_AMT.length + " : " + getData(OBJT_EBNK_BND_MAX_AMT) + "\n");
        sb.append("MGG_FNL_ODPRT_AMT            : " + "\tSize " + MGG_FNL_ODPRT_AMT.length + " : " + getData(MGG_FNL_ODPRT_AMT) + "\n");
        sb.append("TROL_FNL_ODPRT_AMT           : " + "\tSize " + TROL_FNL_ODPRT_AMT.length + " : " + getData(TROL_FNL_ODPRT_AMT) + "\n");
        sb.append("SRVC_END_DT                  : " + "\tSize " + SRVC_END_DT.length + " : " + getData(SRVC_END_DT) + "\n");
        sb.append("DBTR_NM                      : " + "\tSize " + DBTR_NM.length + " : " + getData(DBTR_NM) + "\n");
        sb.append("DBTR_RRNO                    : " + "\tSize " + DBTR_RRNO.length + " : " + getData(DBTR_RRNO) + "\n");
        sb.append("DBTR_PST_NO                  : " + "\tSize " + DBTR_PST_NO.length + " : " + getData(DBTR_PST_NO) + "\n");
        sb.append("DBTR_ADDR                    : " + "\tSize " + DBTR_ADDR.length + " : " + getData(DBTR_ADDR) + "\n");
        sb.append("DBTR_PHNO                    : " + "\tSize " + DBTR_PHNO.length + " : " + getData(DBTR_PHNO) + "\n");
        sb.append("DBTR_HPNO                    : " + "\tSize " + DBTR_HPNO.length + " : " + getData(DBTR_HPNO) + "\n");
        sb.append("WDNG_PLN_YN                  : " + "\tSize " + WDNG_PLN_YN.length + " : " + getData(WDNG_PLN_YN) + "\n");
        sb.append("WDNG_PLN_DT                  : " + "\tSize " + WDNG_PLN_DT.length + " : " + getData(WDNG_PLN_DT) + "\n");
        sb.append("HSHLDR_CNDDT_YN              : " + "\tSize " + HSHLDR_CNDDT_YN.length + " : " + getData(HSHLDR_CNDDT_YN) + "\n");
        sb.append("UNMRD_HSHLDR_25AG_LSTN_YN    : " + "\tSize " + UNMRD_HSHLDR_25AG_LSTN_YN.length + " : " + getData(UNMRD_HSHLDR_25AG_LSTN_YN) + "\n");
        sb.append("ACPT_DSC                     : " + "\tSize " + ACPT_DSC.length + " : " + getData(ACPT_DSC) + "\n");
        sb.append("LWFM_NM                      : " + "\tSize " + LWFM_NM.length + " : " + getData(LWFM_NM) + "\n");
        sb.append("LWFM_BIZNO                   : " + "\tSize " + LWFM_BIZNO.length + " : " + getData(LWFM_BIZNO) + "\n");
        sb.append("ASK_BRNCH_CD                 : " + "\tSize " + ASK_BRNCH_CD.length + " : " + getData(ASK_BRNCH_CD) + "\n");
        sb.append("ASK_BRNCH_NM                 : " + "\tSize " + ASK_BRNCH_NM.length + " : " + getData(ASK_BRNCH_NM) + "\n");
        sb.append("ASK_BRNCH_DRCTR_NM           : " + "\tSize " + ASK_BRNCH_DRCTR_NM.length + " : " + getData(ASK_BRNCH_DRCTR_NM) + "\n");
        sb.append("ASK_BRNCH_PHNO               : " + "\tSize " + ASK_BRNCH_PHNO.length + " : " + getData(ASK_BRNCH_PHNO) + "\n");
        sb.append("BNK_LES_DSC                  : " + "\tSize " + BNK_LES_DSC.length + " : " + getData(BNK_LES_DSC) + "\n");
        sb.append("FND_LES_DSC                  : " + "\tSize " + FND_LES_DSC.length + " : " + getData(FND_LES_DSC) + "\n");
        sb.append("CNDTL_CNTS                   : " + "\tSize " + CNDTL_CNTS.length + " : " + getData(CNDTL_CNTS) + "\n");
        sb.append("ISRN_PRMM                    : " + "\tSize " + ISRN_PRMM.length + " : " + getData(ISRN_PRMM) + "\n");
        sb.append("RSRV_ITM_B                   : " + "\tSize " + RSRV_ITM_B.length + " : " + getData(RSRV_ITM_B) + "\n");
        return sb.toString();
    }

    public void readDataStream(InputStream stream) {
        try {
            stream.read(TG_LEN, 0, TG_LEN.length);
            stream.read(TG_DSC, 0, TG_DSC.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(LND_AGNC_CD, 0, LND_AGNC_CD.length);
            stream.read(BNK_TG_TRNS_DTM, 0, BNK_TG_TRNS_DTM.length);
            stream.read(DB_TG_TRNS_DTM, 0, DB_TG_TRNS_DTM.length);
            stream.read(BNK_TG_NO, 0, BNK_TG_NO.length);
            stream.read(DB_TG_NO, 0, DB_TG_NO.length);
            stream.read(RSRV_ITM_H, 0, RSRV_ITM_H.length);
            stream.read(BNK_ASK_NO, 0, BNK_ASK_NO.length);
            stream.read(LN_APRV_NO, 0, LN_APRV_NO.length);
            stream.read(DB_MNG_NO, 0, DB_MNG_NO.length);
            stream.read(KOS_TG_TRNS_DTM, 0, KOS_TG_TRNS_DTM.length);
            stream.read(KOS_TG_NO, 0, KOS_TG_NO.length);
            stream.read(PROC_DVSN_CD, 0, PROC_DVSN_CD.length);
            stream.read(RTH_ISRN_ENTR_YN, 0, RTH_ISRN_ENTR_YN.length);
            stream.read(RTH_ISRN_ENTR_CMPY, 0, RTH_ISRN_ENTR_CMPY.length);
            stream.read(RTH_ISRN_SCRT_NO, 0, RTH_ISRN_SCRT_NO.length);
            stream.read(PST_NO, 0, PST_NO.length);
            stream.read(CRTDN_CD, 0, CRTDN_CD.length);
            stream.read(TRGT_ADDR, 0, TRGT_ADDR.length);
            stream.read(TRGT_DTL_ADDR, 0, TRGT_DTL_ADDR.length);
            stream.read(RGSTR_UNQ_NO_1, 0, RGSTR_UNQ_NO_1.length);
            stream.read(RGSTR_UNQ_NO_2, 0, RGSTR_UNQ_NO_2.length);
            stream.read(RGSTR_UNQ_NO_3, 0, RGSTR_UNQ_NO_3.length);
            stream.read(LND_KND_CD, 0, LND_KND_CD.length);
            stream.read(FND_YN, 0, FND_YN.length);
            stream.read(PRDT_NM, 0, PRDT_NM.length);
            stream.read(PRDT_CD, 0, PRDT_CD.length);
            stream.read(GRNT_AGNC_CD, 0, GRNT_AGNC_CD.length);
            stream.read(SRV_TRGT_YN, 0, SRV_TRGT_YN.length);
            stream.read(STND_TRGT_YN, 0, STND_TRGT_YN.length);
            stream.read(RRCP_CHRG_TRGT_YN, 0, RRCP_CHRG_TRGT_YN.length);
            stream.read(RVSN_CNTRCT_CHRG_TRGT_YN, 0, RVSN_CNTRCT_CHRG_TRGT_YN.length);
            stream.read(SSCPT_ASK_DT, 0, SSCPT_ASK_DT.length);
            stream.read(LND_PLN_DT, 0, LND_PLN_DT.length);
            stream.read(RNTL_PRD_END_DT, 0, RNTL_PRD_END_DT.length);
            stream.read(LND_EXPRD_DT, 0, LND_EXPRD_DT.length);
            stream.read(LND_PRD, 0, LND_PRD.length);
            stream.read(LND_AMT, 0, LND_AMT.length);
            stream.read(ISRN_ENTR_AMT, 0, ISRN_ENTR_AMT.length);
            stream.read(OBJT_EBNK_RGSTR_RNK, 0, OBJT_EBNK_RGSTR_RNK.length);
            stream.read(OBJT_EBNK_BND_MAX_AMT, 0, OBJT_EBNK_BND_MAX_AMT.length);
            stream.read(MGG_FNL_ODPRT_AMT, 0, MGG_FNL_ODPRT_AMT.length);
            stream.read(TROL_FNL_ODPRT_AMT, 0, TROL_FNL_ODPRT_AMT.length);
            stream.read(SRVC_END_DT, 0, SRVC_END_DT.length);
            stream.read(DBTR_NM, 0, DBTR_NM.length);
            stream.read(DBTR_RRNO, 0, DBTR_RRNO.length);
            stream.read(DBTR_PST_NO, 0, DBTR_PST_NO.length);
            stream.read(DBTR_ADDR, 0, DBTR_ADDR.length);
            stream.read(DBTR_PHNO, 0, DBTR_PHNO.length);
            stream.read(DBTR_HPNO, 0, DBTR_HPNO.length);
            stream.read(WDNG_PLN_YN, 0, WDNG_PLN_YN.length);
            stream.read(WDNG_PLN_DT, 0, WDNG_PLN_DT.length);
            stream.read(HSHLDR_CNDDT_YN, 0, HSHLDR_CNDDT_YN.length);
            stream.read(UNMRD_HSHLDR_25AG_LSTN_YN, 0, UNMRD_HSHLDR_25AG_LSTN_YN.length);
            stream.read(ACPT_DSC, 0, ACPT_DSC.length);
            stream.read(LWFM_NM, 0, LWFM_NM.length);
            stream.read(LWFM_BIZNO, 0, LWFM_BIZNO.length);
            stream.read(ASK_BRNCH_CD, 0, ASK_BRNCH_CD.length);
            stream.read(ASK_BRNCH_NM, 0, ASK_BRNCH_NM.length);
            stream.read(ASK_BRNCH_DRCTR_NM, 0, ASK_BRNCH_DRCTR_NM.length);
            stream.read(ASK_BRNCH_PHNO, 0, ASK_BRNCH_PHNO.length);
            stream.read(BNK_LES_DSC, 0, BNK_LES_DSC.length);
            stream.read(FND_LES_DSC, 0, FND_LES_DSC.length);
            stream.read(CNDTL_CNTS, 0, CNDTL_CNTS.length);
            stream.read(ISRN_PRMM, 0, ISRN_PRMM.length);
            stream.read(RSRV_ITM_B, 0, RSRV_ITM_B.length);

        } catch (Exception Ex) {
            Ex.printStackTrace();
        }
    }
}
