package com.bankle.common.wooriApi.socket.ins.socketData;


import com.bankle.common.utils.StringUtil;

import java.io.IOException;
import java.io.InputStream;

public class T6200W2 extends GetSetData {

    private final String DATE_FORMAT = "yyyyMMddHHmmss";
    private int cntColumn = 0;
    String[] arrName = null;   // Layout Column Name
    byte[] TG_LEN = new byte[8]; //전문 길이
    byte[] TG_DSC = new byte[5]; //전문 종별코드
    byte[] RES_CD = new byte[3]; //응답 코드
    byte[] LND_AGNC_CD = new byte[5]; //대출기관코드
    byte[] BNK_TG_TRNS_DTM = new byte[14];//은행전문전송일시
    byte[] DB_TG_TRNS_DTM = new byte[14];//DB전문전송일시
    byte[] BNK_TG_NO = new byte[8]; //은행전문번호
    byte[] DB_TG_NO = new byte[8]; //DB전문번호
    byte[] RSRV_ITM_H = new byte[39];//예약항목
    byte[] BNK_ASK_NO = new byte[20];//은행요청번호
    byte[] LN_APRV_NO = new byte[14];//대출승인번호
    byte[] DB_MNG_NO = new byte[20];//DB관리번호
    byte[] KOS_MNG_NO = new byte[20];//KOS관리번호
    byte[] KOS_TG_TRNS_DTM = new byte[14]; //KOS전문전송일시
    byte[] KOS_TG_NO = new byte[14]; //KOS전문번호
    byte[] LND_KCD = new byte[2]; //대출종류코드
    byte[] FND_YN = new byte[1];  //자금여부
    byte[] CNFMTN_DSC = new byte[1]; //확인종류코드
    byte[] SRV_DSC = new byte[2]; //서비스구분코드
    byte[] OJT_ANS = new byte[30]; //직불답변
    byte[] SJT_ANS_1 = new byte[200];  //간접답변1
    byte[] SJT_ANS_2 = new byte[200]; //간접답변2
    byte[] SJT_ANS_3 = new byte[200]; //간접답변3
    byte[] SJT_ANS_4 = new byte[200]; //간접답변4
    byte[] SJT_ANS_5 = new byte[200]; //간접답변5
    byte[] SLF_CTFC_AGNC = new byte[14];
    byte[] SLF_CTFC_TM = new byte[14];
    byte[] RES_YN = new byte[1];
    byte[] OPTM_YN = new byte[1];
    byte[] CNFM_RSLT_BNK_TRNS_YN = new byte[1];
    byte[] BNK_RES_DTM = new byte[14];
    byte[] LND_AMT_JST_PMNT_YN = new byte[1];
    byte[] RCPT_JST_CHRGYN = new byte[1];
    byte[] RGSTRACPT_THDY_YN = new byte[1];
    byte[] RGSTR_ERSR_ACPT_NO = new byte[50];
    byte[] FXCLT_ESTBS_YN = new byte[1];
    byte[] FXCLT_ESTBS_RNK_JST_YN = new byte[1];
    byte[] FXCLT_ESTBS_AMT_JST_YN = new byte[1];
    byte[] ACPTNO_JST_YN = new byte[1];
    byte[] ODPRT_JST_YN = new byte[1];
    byte[] RSCH_DTM = new byte[12];
    byte[] SRCHR_NM = new byte[20];
    byte[] SRCHR_PHNO = new byte[15];
    byte[] STND_RMK = new byte[300];
    byte[] LSSR_MVINHSHLD_YN = new byte[1];
    byte[] LSSR_LSSR_HVTTYN = new byte[1];
    byte[] LSSR_NM = new byte[20];
    byte[] LSSR_RLTSP = new byte[20];
    byte[] LSSR_MVIN_DT = new byte[8];
    byte[] LSHDR_MVIN_HSHLD_EANE = new byte[1];
    byte[] LSHDR_HVTT_YN = new byte[1];
    byte[] LSHDR_NM = new byte[30];
    byte[] LSHDR_RLTSP = new byte[20];
    byte[] LSHDR_MVIN_DT = new byte[8];
    byte[] DBTR_SLF_MVIN_YN = new byte[1];
    byte[] MVIN_ADDR_OPTM_YN = new byte[1];
    byte[] MVIN_DT_OPTM_YN = new byte[1];
    byte[] SPUS_MVINYN = new byte[1];
    byte[] DBTR_OTSD_MVIN_OPTM_YN = new byte[1];
    byte[] TTL_STRD_DTM = new byte[12];
    byte[] TTL_RSCH_DT = new byte[8];
    byte[] TTL_SRCHR_NM = new byte[40];
    byte[] TTL_DRWUP_DT = new byte[8];
    byte[] TTL_RMK = new byte[296];
    byte[] ISRN_SCRT_NO = new byte[15];
    byte[] ISRN_ENTR_AMT = new byte[15];
    byte[] RTHISRN_PRMM = new byte[15];
    byte[] UNUSL_FCT_EXST_YN = new byte[1];
    byte[] UNUSL_THNG_YN = new byte[1];
    byte[] CNDTL_EXEC_YN = new byte[1];
    byte[] RTH_RSCH_FN_YN = new byte[1];
    byte[] RSRV_ITM_B = new byte[784];


    public T6200W2() {
        setData(this.TG_LEN, "");
        setData(this.TG_DSC, "");
        setData(this.RES_CD, "");
        setData(this.LND_AGNC_CD, "");
        setData(this.BNK_TG_TRNS_DTM, "");
        setData(this.DB_TG_TRNS_DTM, "");
        setData(this.BNK_TG_NO, "");
        setData(this.DB_TG_NO, "");
        setData(this.RSRV_ITM_H, "");
        setData(this.BNK_ASK_NO, "");
        setData(this.LN_APRV_NO, "");
        setData(this.DB_MNG_NO, "");
        setData(this.KOS_MNG_NO, "");
        setData(this.KOS_TG_TRNS_DTM, "");
        setData(this.KOS_TG_NO, "");
        setData(this.LND_KCD, "");
        setData(this.FND_YN, "");
        setData(this.CNFMTN_DSC, "");
        setData(this.SRV_DSC, "");
        setData(this.OJT_ANS, "");
        setData(this.SJT_ANS_1, "");
        setData(this.SJT_ANS_2, "");
        setData(this.SJT_ANS_3, "");
        setData(this.SJT_ANS_4, "");
        setData(this.SJT_ANS_5, "");
        setData(this.SLF_CTFC_AGNC, "");
        setData(this.SLF_CTFC_TM, "");
        setData(this.RES_YN, "");
        setData(this.OPTM_YN, "");
        setData(this.CNFM_RSLT_BNK_TRNS_YN, "");
        setData(this.BNK_RES_DTM, "");
        setData(this.LND_AMT_JST_PMNT_YN, "");
        setData(this.RCPT_JST_CHRGYN, "");
        setData(this.RGSTRACPT_THDY_YN, "");
        setData(this.RGSTR_ERSR_ACPT_NO, "");
        setData(this.FXCLT_ESTBS_YN, "");
        setData(this.FXCLT_ESTBS_RNK_JST_YN, "");
        setData(this.FXCLT_ESTBS_AMT_JST_YN, "");
        setData(this.ACPTNO_JST_YN, "");
        setData(this.ODPRT_JST_YN, "");
        setData(this.RSCH_DTM, "");
        setData(this.SRCHR_NM, "");
        setData(this.SRCHR_PHNO, "");
        setData(this.STND_RMK, "");
        setData(this.LSSR_MVINHSHLD_YN, "");
        setData(this.LSSR_LSSR_HVTTYN, "");
        setData(this.LSSR_NM, "");
        setData(this.LSSR_RLTSP, "");
        setData(this.LSSR_MVIN_DT, "");
        setData(this.LSHDR_MVIN_HSHLD_EANE, "");
        setData(this.LSHDR_HVTT_YN, "");
        setData(this.LSHDR_NM, "");
        setData(this.LSHDR_RLTSP, "");
        setData(this.LSHDR_MVIN_DT, "");
        setData(this.DBTR_SLF_MVIN_YN, "");
        setData(this.MVIN_ADDR_OPTM_YN, "");
        setData(this.MVIN_DT_OPTM_YN, "");
        setData(this.SPUS_MVINYN, "");
        setData(this.DBTR_OTSD_MVIN_OPTM_YN, "");
        setData(this.TTL_STRD_DTM, "");
        setData(this.TTL_RSCH_DT, "");
        setData(this.TTL_SRCHR_NM, "");
        setData(this.TTL_DRWUP_DT, "");
        setData(this.TTL_RMK, "");
        setData(this.ISRN_SCRT_NO, "");
        setData(this.ISRN_ENTR_AMT, "");
        setData(this.RTHISRN_PRMM, "");
        setData(this.UNUSL_FCT_EXST_YN, "");
        setData(this.UNUSL_THNG_YN, "");
        setData(this.CNDTL_EXEC_YN, "");
        setData(this.RTH_RSCH_FN_YN, "");
        setData(this.RSRV_ITM_B, "");
    }

    public String getTG_LEN() {
        return getData(TG_LEN);
    }

    public String getTG_DSC() {
        return getData(TG_DSC);
    }

    public String getRES_CD() {
        return getData(RES_CD);
    }

    public String getLND_AGNC_CD() {
        return getData(LND_AGNC_CD);
    }

    public String getBNK_TG_TRNS_DTM() {
        return getData(BNK_TG_TRNS_DTM);
    }

    public String getDB_TG_TRNS_DTM() {
        return getData(DB_TG_TRNS_DTM);
    }

    public String getBNK_TG_NO() {
        return getData(BNK_TG_NO);
    }

    public String getDB_TG_NO() {
        return getData(DB_TG_NO);
    }

    public String getRSRV_ITM_H() {
        return getData(RSRV_ITM_H);
    }

    public String getBNK_ASK_NO() {
        return getData(BNK_ASK_NO);
    }

    public String getLN_APRV_NO() {
        return getData(LN_APRV_NO);
    }

    public String getDB_MNG_NO() {
        return getData(DB_MNG_NO);
    }

    public String getKOS_MNG_NO() {
        return getData(KOS_MNG_NO);
    }

    public String getKOS_TG_TRNS_DTM() {
        return getData(KOS_TG_TRNS_DTM);
    }

    public String getKOS_TG_NO() {
        return getData(KOS_TG_NO);
    }

    public String getLND_KCD() {
        return getData(LND_KCD);
    }

    public String getFND_YN() {
        return getData(FND_YN);
    }

    public String getCNFMTN_DSC() {
        return getData(CNFMTN_DSC);
    }

    public String getSRV_DSC() {
        return getData(SRV_DSC);
    }

    public String getOJT_ANS() {
        return getData(OJT_ANS);
    }

    public String getSJT_ANS_1() {
        return getData(SJT_ANS_1);
    }

    public String getSJT_ANS_2() {
        return getData(SJT_ANS_2);
    }

    public String getSJT_ANS_3() {
        return getData(SJT_ANS_3);
    }

    public String getSJT_ANS_4() {
        return getData(SJT_ANS_4);
    }

    public String getSJT_ANS_5() {
        return getData(SJT_ANS_5);
    }

    public String getSLF_CTFC_AGNC() {
        return getData(SLF_CTFC_AGNC);
    }

    public String getSLF_CTFC_TM() {
        return getData(SLF_CTFC_TM);
    }

    public String getRES_YN() {
        return getData(RES_YN);
    }

    public String getOPTM_YN() {
        return getData(OPTM_YN);
    }

    public String getCNFM_RSLT_BNK_TRNS_YN() {
        return getData(CNFM_RSLT_BNK_TRNS_YN);
    }

    public String getBNK_RES_DTM() {
        return getData(BNK_RES_DTM);
    }

    public String getLND_AMT_JST_PMNT_YN() {
        return getData(LND_AMT_JST_PMNT_YN);
    }

    public String getRCPT_JST_CHRGYN() {
        return getData(RCPT_JST_CHRGYN);
    }

    public String getRGSTRACPT_THDY_YN() {
        return getData(RGSTRACPT_THDY_YN);
    }

    public String getRGSTR_ERSR_ACPT_NO() {
        return getData(RGSTR_ERSR_ACPT_NO);
    }

    public String getFXCLT_ESTBS_YN() {
        return getData(FXCLT_ESTBS_YN);
    }

    public String getFXCLT_ESTBS_RNK_JST_YN() {
        return getData(FXCLT_ESTBS_RNK_JST_YN);
    }

    public String getFXCLT_ESTBS_AMT_JST_YN() {
        return getData(FXCLT_ESTBS_AMT_JST_YN);
    }

    public String getACPTNO_JST_YN() {
        return getData(ACPTNO_JST_YN);
    }

    public String getODPRT_JST_YN() {
        return getData(ODPRT_JST_YN);
    }

    public String getRSCH_DTM() {
        return getData(RSCH_DTM);
    }

    public String getSRCHR_NM() {
        return getData(SRCHR_NM);
    }

    public String getSRCHR_PHNO() {
        return getData(SRCHR_PHNO);
    }

    public String getSTND_RMK() {
        return getData(STND_RMK);
    }

    public String getLSSR_MVINHSHLD_YN() {
        return getData(LSSR_MVINHSHLD_YN);
    }

    public String getLSSR_LSSR_HVTTYN() {
        return getData(LSSR_LSSR_HVTTYN);
    }

    public String getLSSR_NM() {
        return getData(LSSR_NM);
    }

    public String getLSSR_RLTSP() {
        return getData(LSSR_RLTSP);
    }

    public String getLSSR_MVIN_DT() {
        return getData(LSSR_MVIN_DT);
    }

    public String getLSHDR_MVIN_HSHLD_EANE() {
        return getData(LSHDR_MVIN_HSHLD_EANE);
    }

    public String getLSHDR_HVTT_YN() {
        return getData(LSHDR_HVTT_YN);
    }

    public String getLSHDR_NM() {
        return getData(LSHDR_NM);
    }

    public String getLSHDR_RLTSP() {
        return getData(LSHDR_RLTSP);
    }

    public String getLSHDR_MVIN_DT() {
        return getData(LSHDR_MVIN_DT);
    }

    public String getDBTR_SLF_MVIN_YN() {
        return getData(DBTR_SLF_MVIN_YN);
    }

    public String getMVIN_ADDR_OPTM_YN() {
        return getData(MVIN_ADDR_OPTM_YN);
    }

    public String getMVIN_DT_OPTM_YN() {
        return getData(MVIN_DT_OPTM_YN);
    }

    public String getSPUS_MVINYN() {
        return getData(SPUS_MVINYN);
    }

    public String getDBTR_OTSD_MVIN_OPTM_YN() {
        return getData(DBTR_OTSD_MVIN_OPTM_YN);
    }

    public String getTTL_STRD_DTM() {
        return getData(TTL_STRD_DTM);
    }

    public String getTTL_RSCH_DT() {
        return getData(TTL_RSCH_DT);
    }

    public String getTTL_SRCHR_NM() {
        return getData(TTL_SRCHR_NM);
    }

    public String getTTL_DRWUP_DT() {
        return getData(TTL_DRWUP_DT);
    }

    public String getTTL_RMK() {
        return getData(TTL_RMK);
    }

    public String getISRN_SCRT_NO() {
        return getData(ISRN_SCRT_NO);
    }

    public String getISRN_ENTR_AMT() {
        return getData(ISRN_ENTR_AMT);
    }

    public String getRTHISRN_PRMM() {
        return getData(RTHISRN_PRMM);
    }

    public String getUNUSL_FCT_EXST_YN() {
        return getData(UNUSL_FCT_EXST_YN);
    }

    public String getUNUSL_THNG_YN() {
        return getData(UNUSL_THNG_YN);
    }

    public String getCNDTL_EXEC_YN() {
        return getData(CNDTL_EXEC_YN);
    }

    public String getRTH_RSCH_FN_YN() {
        return getData(RTH_RSCH_FN_YN);
    }

    public String getRSRV_ITM_B() {
        return getData(RSRV_ITM_B);
    }

    public void setTG_LEN(String TG_LEN) {
        setData(this.TG_LEN, TG_LEN,"N");
    }

    public void setTG_DSC(String TG_DSC) {
        setData(this.TG_DSC, TG_DSC,"S");
    }

    public void setRES_CD(String RES_CD) {
        setData(this.RES_CD, RES_CD,"S");
    }

    public void setLND_AGNC_CD(String LND_AGNC_CD) {
        setData(this.LND_AGNC_CD, LND_AGNC_CD,"S");
    }

    public void setBNK_TG_TRNS_DTM(String BNK_TG_TRNS_DTM) {
        setData(this.BNK_TG_TRNS_DTM, BNK_TG_TRNS_DTM,"S");
    }

    public void setDB_TG_TRNS_DTM(String DB_TG_TRNS_DTM) {
        setData(this.DB_TG_TRNS_DTM, DB_TG_TRNS_DTM,"S");
    }

    public void setBNK_TG_NO(String BNK_TG_NO) {
        setData(this.BNK_TG_NO, BNK_TG_NO,"S");
    }

    public void setDB_TG_NO(String DB_TG_NO) {
        setData(this.DB_TG_NO, DB_TG_NO,"N");
    }

    public void setRSRV_ITM_H(String RSRV_ITM_H) {
        setData(this.RSRV_ITM_H, RSRV_ITM_H,"K");
    }

    public void setBNK_ASK_NO(String BNK_ASK_NO) {
        setData(this.BNK_ASK_NO, BNK_ASK_NO,"S");
    }

    public void setLN_APRV_NO(String LN_APRV_NO) {
        setData(this.LN_APRV_NO, LN_APRV_NO,"S");
    }

    public void setDB_MNG_NO(String DB_MNG_NO) {
        setData(this.DB_MNG_NO, DB_MNG_NO,"S");
    }

    public void setKOS_MNG_NO(String KOS_MNG_NO) {
        setData(this.KOS_MNG_NO, KOS_MNG_NO,"S");
    }

    public void setKOS_TG_TRNS_DTM(String KOS_TG_TRNS_DTM) {
        setData(this.KOS_TG_TRNS_DTM, KOS_TG_TRNS_DTM,"S");
    }

    public void setKOS_TG_NO(String KOS_TG_NO) {
        setData(this.KOS_TG_NO, KOS_TG_NO,"S");
    }

    public void setLND_KCD(String LND_KCD) {
        setData(this.LND_KCD, LND_KCD,"S");
    }

    public void setFND_YN(String FND_YN) {
        setData(this.FND_YN, FND_YN,"S");
    }

    public void setCNFMTN_DSC(String CNFMTN_DSC) {
        setData(this.CNFMTN_DSC, CNFMTN_DSC,"S");
    }

    public void setSRV_DSC(String SRV_DSC) {
        setData(this.SRV_DSC, SRV_DSC,"S");
    }

    public void setOJT_ANS(String OJT_ANS) {
        setData(this.OJT_ANS, OJT_ANS,"S");
    }

    public void setSJT_ANS_1(String SJT_ANS_1) {
        setData(this.SJT_ANS_1, SJT_ANS_1,"K");
    }

    public void setSJT_ANS_2(String SJT_ANS_2) {
        setData(this.SJT_ANS_2, SJT_ANS_2,"K");
    }

    public void setSJT_ANS_3(String SJT_ANS_3) {
        setData(this.SJT_ANS_3, SJT_ANS_3,"K");
    }

    public void setSJT_ANS_4(String SJT_ANS_4) {
        setData(this.SJT_ANS_4, SJT_ANS_4,"K");
    }

    public void setSJT_ANS_5(String SJT_ANS_5) {
        setData(this.SJT_ANS_5, SJT_ANS_5,"K");
    }

    public void setSLF_CTFC_AGNC(String SLF_CTFC_AGNC) {
        setData(this.SLF_CTFC_AGNC, SLF_CTFC_AGNC,"K");
    }

    public void setSLF_CTFC_TM(String SLF_CTFC_TM) {
        setData(this.SLF_CTFC_TM, SLF_CTFC_TM,"S");
    }

    public void setRES_YN(String RES_YN) {
        setData(this.RES_YN, RES_YN,"S");
    }

    public void setOPTM_YN(String OPTM_YN) {
        setData(this.OPTM_YN, OPTM_YN,"S");
    }

    public void setCNFM_RSLT_BNK_TRNS_YN(String CNFM_RSLT_BNK_TRNS_YN) {
        setData(this.CNFM_RSLT_BNK_TRNS_YN, CNFM_RSLT_BNK_TRNS_YN,"S");
    }

    public void setBNK_RES_DTM(String BNK_RES_DTM) {
        setData(this.BNK_RES_DTM, BNK_RES_DTM,"S");
    }

    public void setLND_AMT_JST_PMNT_YN(String LND_AMT_JST_PMNT_YN) {
        setData(this.LND_AMT_JST_PMNT_YN, LND_AMT_JST_PMNT_YN,"S");
    }

    public void setRCPT_JST_CHRGYN(String RCPT_JST_CHRGYN) {
        setData(this.RCPT_JST_CHRGYN, RCPT_JST_CHRGYN,"S");
    }

    public void setRGSTRACPT_THDY_YN(String RGSTRACPT_THDY_YN) {
        setData(this.RGSTRACPT_THDY_YN, RGSTRACPT_THDY_YN,"S");
    }

    public void setRGSTR_ERSR_ACPT_NO(String RGSTR_ERSR_ACPT_NO) {
        setData(this.RGSTR_ERSR_ACPT_NO, RGSTR_ERSR_ACPT_NO,"S");
    }

    public void setFXCLT_ESTBS_YN(String FXCLT_ESTBS_YN) {
        setData(this.FXCLT_ESTBS_YN, FXCLT_ESTBS_YN,"S");
    }

    public void setFXCLT_ESTBS_RNK_JST_YN(String FXCLT_ESTBS_RNK_JST_YN) {
        setData(this.FXCLT_ESTBS_RNK_JST_YN, FXCLT_ESTBS_RNK_JST_YN,"S");
    }

    public void setFXCLT_ESTBS_AMT_JST_YN(String FXCLT_ESTBS_AMT_JST_YN) {
        setData(this.FXCLT_ESTBS_AMT_JST_YN, FXCLT_ESTBS_AMT_JST_YN,"S");
    }

    public void setACPTNO_JST_YN(String ACPTNO_JST_YN) {
        setData(this.ACPTNO_JST_YN, ACPTNO_JST_YN,"S");
    }

    public void setODPRT_JST_YN(String ODPRT_JST_YN) {
        setData(this.ODPRT_JST_YN, ODPRT_JST_YN,"S");
    }

    public void setRSCH_DTM(String RSCH_DTM) {
        setData(this.RSCH_DTM, RSCH_DTM,"S");
    }

    public void setSRCHR_NM(String SRCHR_NM) {
        setData(this.SRCHR_NM, SRCHR_NM,"K");
    }

    public void setSRCHR_PHNO(String SRCHR_PHNO) {
        setData(this.SRCHR_PHNO, SRCHR_PHNO,"S");
    }

    public void setSTND_RMK(String STND_RMK) {
        setData(this.STND_RMK, STND_RMK,"K");
    }

    public void setLSSR_MVINHSHLD_YN(String LSSR_MVINHSHLD_YN) {
        setData(this.LSSR_MVINHSHLD_YN, LSSR_MVINHSHLD_YN,"S");
    }

    public void setLSSR_LSSR_HVTTYN(String LSSR_LSSR_HVTTYN) {
        setData(this.LSSR_LSSR_HVTTYN, LSSR_LSSR_HVTTYN,"S");
    }

    public void setLSSR_NM(String LSSR_NM) {
        setData(this.LSSR_NM, LSSR_NM,"K");
    }

    public void setLSSR_RLTSP(String LSSR_RLTSP) {
        setData(this.LSSR_RLTSP, LSSR_RLTSP,"K");
    }

    public void setLSSR_MVIN_DT(String LSSR_MVIN_DT) {
        setData(this.LSSR_MVIN_DT, LSSR_MVIN_DT,"S");
    }

    public void setLSHDR_MVIN_HSHLD_EANE(String LSHDR_MVIN_HSHLD_EANE) {
        setData(this.LSHDR_MVIN_HSHLD_EANE, LSHDR_MVIN_HSHLD_EANE,"S");
    }

    public void setLSHDR_HVTT_YN(String LSHDR_HVTT_YN) {
        setData(this.LSHDR_HVTT_YN, LSHDR_HVTT_YN,"S");
    }

    public void setLSHDR_NM(String LSHDR_NM) {
        setData(this.LSHDR_NM, LSHDR_NM,"K");
    }

    public void setLSHDR_RLTSP(String LSHDR_RLTSP) {
        setData(this.LSHDR_RLTSP, LSHDR_RLTSP,"K");
    }

    public void setLSHDR_MVIN_DT(String LSHDR_MVIN_DT) {
        setData(this.LSHDR_MVIN_DT, LSHDR_MVIN_DT,"S");
    }

    public void setDBTR_SLF_MVIN_YN(String DBTR_SLF_MVIN_YN) {
        setData(this.DBTR_SLF_MVIN_YN, DBTR_SLF_MVIN_YN,"S");
    }

    public void setMVIN_ADDR_OPTM_YN(String MVIN_ADDR_OPTM_YN) {
        setData(this.MVIN_ADDR_OPTM_YN, MVIN_ADDR_OPTM_YN,"S");
    }

    public void setMVIN_DT_OPTM_YN(String MVIN_DT_OPTM_YN) {
        setData(this.MVIN_DT_OPTM_YN, MVIN_DT_OPTM_YN,"S");
    }

    public void setSPUS_MVINYN(String SPUS_MVINYN) {
        setData(this.SPUS_MVINYN, SPUS_MVINYN,"S");
    }

    public void setDBTR_OTSD_MVIN_OPTM_YN(String DBTR_OTSD_MVIN_OPTM_YN) {
        setData(this.DBTR_OTSD_MVIN_OPTM_YN, DBTR_OTSD_MVIN_OPTM_YN,"S");
    }

    public void setTTL_STRD_DTM(String TTL_STRD_DTM) {
        setData(this.TTL_STRD_DTM, TTL_STRD_DTM,"S");
    }

    public void setTTL_RSCH_DT(String TTL_RSCH_DT) {
        setData(this.TTL_RSCH_DT, TTL_RSCH_DT,"S");
    }

    public void setTTL_SRCHR_NM(String TTL_SRCHR_NM) {
        setData(this.TTL_SRCHR_NM, TTL_SRCHR_NM,"K");
    }

    public void setTTL_DRWUP_DT(String TTL_DRWUP_DT) {
        setData(this.TTL_DRWUP_DT, TTL_DRWUP_DT,"S");
    }

    public void setTTL_RMK(String TTL_RMK) {
        setData(this.TTL_RMK, TTL_RMK,"K");
    }

    public void setISRN_SCRT_NO(String ISRN_SCRT_NO) {
        setData(this.ISRN_SCRT_NO, ISRN_SCRT_NO,"S");
    }

    public void setISRN_ENTR_AMT(String ISRN_ENTR_AMT) {
        setData(this.ISRN_ENTR_AMT, ISRN_ENTR_AMT,"S");
    }

    public void setRTHISRN_PRMM(String RTHISRN_PRMM) {
        setData(this.RTHISRN_PRMM, RTHISRN_PRMM,"S");
    }

    public void setUNUSL_FCT_EXST_YN(String UNUSL_FCT_EXST_YN) {
        setData(this.UNUSL_FCT_EXST_YN, UNUSL_FCT_EXST_YN,"S");
    }

    public void setUNUSL_THNG_YN(String UNUSL_THNG_YN) {
        setData(this.UNUSL_THNG_YN, UNUSL_THNG_YN,"S");
    }

    public void setCNDTL_EXEC_YN(String CNDTL_EXEC_YN) {
        setData(this.CNDTL_EXEC_YN, CNDTL_EXEC_YN,"S");
    }

    public void setRTH_RSCH_FN_YN(String RTH_RSCH_FN_YN) {
        setData(this.RTH_RSCH_FN_YN, RTH_RSCH_FN_YN,"S");
    }

    public void setRSRV_ITM_B(String RSRV_ITM_B) {
        setData(this.RSRV_ITM_B, RSRV_ITM_B,"K");
    }


    /**
     * @param :
     * @return :
     * @name : T6200W2.toString
     * @author : JuHeon Kim
     **/
    /*===========================================================================================*/
    /* Function Name : print  Layout 정보 출력                                                   */
    /* Parameter     : tgtDsc    => get 사용 대상 (K L KOS [default], B : BANK)                  */
    /*===========================================================================================*/
    public String toString(String logYN) {

        StringBuffer sb = new StringBuffer();
        try {
            String varName = "";
            for (int i = 0; i < cntColumn; i++) {
                varName = arrName[i];

                if ("N".equals(logYN)) {
                    sb.append(getData(varName, "N"));
                } else {
                    sb.append(StringUtil.rpad(varName, 15, " ") + " : "
                            + StringUtil.lpad(getLength(varName) + "", 4, "0") + "\tData ["
                            + getData(varName, "N") + "]\n");
                }
            }
        } catch (Exception Ex) {
            Ex.printStackTrace();
        }
        return sb.toString();
    }

    public String dataToString() {
        return getData(TG_LEN) + getData(TG_DSC) + getData(RES_CD) + getData(LND_AGNC_CD) + getData(BNK_TG_TRNS_DTM) + getData(DB_TG_TRNS_DTM) +
                getData(BNK_TG_NO) + getData(DB_TG_NO) + getData(RSRV_ITM_H) + getData(BNK_ASK_NO) + getData(LN_APRV_NO) + getData(DB_MNG_NO) +
                getData(KOS_MNG_NO) + getData(KOS_TG_TRNS_DTM) + getData(KOS_TG_NO) + getData(LND_KCD) + getData(FND_YN) + getData(CNFMTN_DSC) +
                getData(SRV_DSC) + getData(OJT_ANS) + getData(SJT_ANS_1) + getData(SJT_ANS_2) + getData(SJT_ANS_3) + getData(SJT_ANS_4) +
                getData(SJT_ANS_5) + getData(SLF_CTFC_AGNC) + getData(SLF_CTFC_TM) + getData(RES_YN) + getData(OPTM_YN) +
                getData(CNFM_RSLT_BNK_TRNS_YN) + getData(BNK_RES_DTM) + getData(LND_AMT_JST_PMNT_YN) + getData(RCPT_JST_CHRGYN) + getData(RGSTRACPT_THDY_YN) +
                getData(RGSTR_ERSR_ACPT_NO) + getData(FXCLT_ESTBS_YN) + getData(FXCLT_ESTBS_RNK_JST_YN) + getData(FXCLT_ESTBS_AMT_JST_YN) + getData(ACPTNO_JST_YN) +
                getData(ODPRT_JST_YN) + getData(RSCH_DTM) + getData(SRCHR_NM) + getData(SRCHR_PHNO) + getData(STND_RMK) + getData(LSSR_MVINHSHLD_YN) +
                getData(LSSR_LSSR_HVTTYN) + getData(LSSR_NM) + getData(LSSR_RLTSP) + getData(LSSR_MVIN_DT) + getData(LSHDR_MVIN_HSHLD_EANE) + getData(LSHDR_HVTT_YN) +
                getData(LSHDR_NM) + getData(LSHDR_RLTSP) + getData(LSHDR_MVIN_DT) + getData(DBTR_SLF_MVIN_YN) + getData(MVIN_ADDR_OPTM_YN) +
                getData(MVIN_DT_OPTM_YN) + getData(SPUS_MVINYN) + getData(DBTR_OTSD_MVIN_OPTM_YN) + getData(TTL_STRD_DTM) + getData(TTL_RSCH_DT) +
                getData(TTL_SRCHR_NM) + getData(TTL_DRWUP_DT) + getData(TTL_RMK) + getData(ISRN_SCRT_NO) + getData(ISRN_ENTR_AMT) +
                getData(RTHISRN_PRMM) + getData(UNUSL_FCT_EXST_YN) + getData(UNUSL_THNG_YN) + getData(CNDTL_EXEC_YN) + getData(RTH_RSCH_FN_YN) + getData(RSRV_ITM_B);
    }

    public String print() {

        StringBuffer sb = new StringBuffer();
        sb.append("TG_LEN        	 	           : " + "\tSize " + TG_LEN.length + " : " + getData(TG_LEN) + "\n");
        sb.append("TG_DSC                          : " + "\tSize " + TG_DSC.length + " : " + getData(TG_DSC) + "\n");
        sb.append("RES_CD                          : " + "\tSize " + RES_CD.length + " : " + getData(RES_CD) + "\n");
        sb.append("LND_AGNC_CD                     : " + "\tSize " + LND_AGNC_CD.length + " : " + getData(LND_AGNC_CD) + "\n");
        sb.append("BNK_TG_TRNS_DTM                 : " + "\tSize " + BNK_TG_TRNS_DTM.length + " : " + getData(BNK_TG_TRNS_DTM) + "\n");
        sb.append("DB_TG_TRNS_DTM                  : " + "\tSize " + DB_TG_TRNS_DTM.length + " : " + getData(DB_TG_TRNS_DTM) + "\n");
        sb.append("BNK_TG_NO                       : " + "\tSize " + BNK_TG_NO.length + " : " + getData(BNK_TG_NO) + "\n");
        sb.append("DB_TG_NO                        : " + "\tSize " + DB_TG_NO.length + " : " + getData(DB_TG_NO) + "\n");
        sb.append("RSRV_ITM_H                      : " + "\tSize " + RSRV_ITM_H.length + " : " + getData(RSRV_ITM_H) + "\n");
        sb.append("BNK_ASK_NO                      : " + "\tSize " + BNK_ASK_NO.length + " : " + getData(BNK_ASK_NO) + "\n");
        sb.append("LN_APRV_NO                      : " + "\tSize " + LN_APRV_NO.length + " : " + getData(LN_APRV_NO) + "\n");
        sb.append("DB_MNG_NO                       : " + "\tSize " + DB_MNG_NO.length + " : " + getData(DB_MNG_NO) + "\n");
        sb.append("KOS_MNG_NO                      : " + "\tSize " + KOS_MNG_NO.length + " : " + getData(KOS_MNG_NO) + "\n");
        sb.append("KOS_TG_TRNS_DTM                 : " + "\tSize " + KOS_TG_TRNS_DTM.length + " : " + getData(KOS_TG_TRNS_DTM) + "\n");
        sb.append("KOS_TG_NO                       : " + "\tSize " + KOS_TG_NO.length + " : " + getData(KOS_TG_NO) + "\n");
        sb.append("LND_KCD                         : " + "\tSize " + LND_KCD.length + " : " + getData(LND_KCD) + "\n");
        sb.append("FND_YN                          : " + "\tSize " + FND_YN.length + " : " + getData(FND_YN) + "\n");
        sb.append("CNFMTN_DSC                      : " + "\tSize " + CNFMTN_DSC.length + " : " + getData(CNFMTN_DSC) + "\n");
        sb.append("SRV_DSC                         : " + "\tSize " + SRV_DSC.length + " : " + getData(SRV_DSC) + "\n");
        sb.append("OJT_ANS                         : " + "\tSize " + OJT_ANS.length + " : " + getData(OJT_ANS) + "\n");
        sb.append("SJT_ANS_1                       : " + "\tSize " + SJT_ANS_1.length + " : " + getData(SJT_ANS_1) + "\n");
        sb.append("SJT_ANS_2                       : " + "\tSize " + SJT_ANS_2.length + " : " + getData(SJT_ANS_2) + "\n");
        sb.append("SJT_ANS_3                       : " + "\tSize " + SJT_ANS_3.length + " : " + getData(SJT_ANS_3) + "\n");
        sb.append("SJT_ANS_4                       : " + "\tSize " + SJT_ANS_4.length + " : " + getData(SJT_ANS_4) + "\n");
        sb.append("SJT_ANS_5                       : " + "\tSize " + SJT_ANS_5.length + " : " + getData(SJT_ANS_5) + "\n");
        sb.append("SLF_CTFC_AGNC                   : " + "\tSize " + SLF_CTFC_AGNC.length + " : " + getData(SLF_CTFC_AGNC) + "\n");
        sb.append("SLF_CTFC_TM                     : " + "\tSize " + SLF_CTFC_TM.length + " : " + getData(SLF_CTFC_TM) + "\n");
        sb.append("RES_YN                          : " + "\tSize " + RES_YN.length + " : " + getData(RES_YN) + "\n");
        sb.append("OPTM_YN                         : " + "\tSize " + OPTM_YN.length + " : " + getData(OPTM_YN) + "\n");
        sb.append("CNFM_RSLT_BNK_TRNS_YN           : " + "\tSize " + CNFM_RSLT_BNK_TRNS_YN.length + " : " + getData(CNFM_RSLT_BNK_TRNS_YN) + "\n");
        sb.append("BNK_RES_DTM                     : " + "\tSize " + BNK_RES_DTM.length + " : " + getData(BNK_RES_DTM) + "\n");
        sb.append("LND_AMT_JST_PMNT_YN             : " + "\tSize " + LND_AMT_JST_PMNT_YN.length + " : " + getData(LND_AMT_JST_PMNT_YN) + "\n");
        sb.append("RCPT_JST_CHRGYN                 : " + "\tSize " + RCPT_JST_CHRGYN.length + " : " + getData(RCPT_JST_CHRGYN) + "\n");
        sb.append("RGSTRACPT_THDY_YN               : " + "\tSize " + RGSTRACPT_THDY_YN.length + " : " + getData(RGSTRACPT_THDY_YN) + "\n");
        sb.append("RGSTR_ERSR_ACPT_NO              : " + "\tSize " + RGSTR_ERSR_ACPT_NO.length + " : " + getData(RGSTR_ERSR_ACPT_NO) + "\n");
        sb.append("FXCLT_ESTBS_YN                  : " + "\tSize " + FXCLT_ESTBS_YN.length + " : " + getData(FXCLT_ESTBS_YN) + "\n");
        sb.append("FXCLT_ESTBS_RNK_JST_YN          : " + "\tSize " + FXCLT_ESTBS_RNK_JST_YN.length + " : " + getData(FXCLT_ESTBS_RNK_JST_YN) + "\n");
        sb.append("FXCLT_ESTBS_AMT_JST_YN          : " + "\tSize " + FXCLT_ESTBS_AMT_JST_YN.length + " : " + getData(FXCLT_ESTBS_AMT_JST_YN) + "\n");
        sb.append("ACPTNO_JST_YN                   : " + "\tSize " + ACPTNO_JST_YN.length + " : " + getData(ACPTNO_JST_YN) + "\n");
        sb.append("ODPRT_JST_YN                    : " + "\tSize " + ODPRT_JST_YN.length + " : " + getData(ODPRT_JST_YN) + "\n");
        sb.append("RSCH_DTM                        : " + "\tSize " + RSCH_DTM.length + " : " + getData(RSCH_DTM) + "\n");
        sb.append("SRCHR_NM                        : " + "\tSize " + SRCHR_NM.length + " : " + getData(SRCHR_NM) + "\n");
        sb.append("SRCHR_PHNO                      : " + "\tSize " + SRCHR_PHNO.length + " : " + getData(SRCHR_PHNO) + "\n");
        sb.append("STND_RMK                        : " + "\tSize " + STND_RMK.length + " : " + getData(STND_RMK) + "\n");
        sb.append("LSSR_MVINHSHLD_YN               : " + "\tSize " + LSSR_MVINHSHLD_YN.length + " : " + getData(LSSR_MVINHSHLD_YN) + "\n");
        sb.append("LSSR_LSSR_HVTTYN                : " + "\tSize " + LSSR_LSSR_HVTTYN.length + " : " + getData(LSSR_LSSR_HVTTYN) + "\n");
        sb.append("LSSR_NM                         : " + "\tSize " + LSSR_NM.length + " : " + getData(LSSR_NM) + "\n");
        sb.append("LSSR_RLTSP                      : " + "\tSize " + LSSR_RLTSP.length + " : " + getData(LSSR_RLTSP) + "\n");
        sb.append("LSSR_MVIN_DT                    : " + "\tSize " + LSSR_MVIN_DT.length + " : " + getData(LSSR_MVIN_DT) + "\n");
        sb.append("LSHDR_MVIN_HSHLD_EANE           : " + "\tSize " + LSHDR_MVIN_HSHLD_EANE.length + " : " + getData(LSHDR_MVIN_HSHLD_EANE) + "\n");
        sb.append("LSHDR_HVTT_YN                   : " + "\tSize " + LSHDR_HVTT_YN.length + " : " + getData(LSHDR_HVTT_YN) + "\n");
        sb.append("LSHDR_NM                        : " + "\tSize " + LSHDR_NM.length + " : " + getData(LSHDR_NM) + "\n");
        sb.append("LSHDR_RLTSP                     : " + "\tSize " + LSHDR_RLTSP.length + " : " + getData(LSHDR_RLTSP) + "\n");
        sb.append("LSHDR_MVIN_DT                   : " + "\tSize " + LSHDR_MVIN_DT.length + " : " + getData(LSHDR_MVIN_DT) + "\n");
        sb.append("DBTR_SLF_MVIN_YN                : " + "\tSize " + DBTR_SLF_MVIN_YN.length + " : " + getData(DBTR_SLF_MVIN_YN) + "\n");
        sb.append("MVIN_ADDR_OPTM_YN               : " + "\tSize " + MVIN_ADDR_OPTM_YN.length + " : " + getData(MVIN_ADDR_OPTM_YN) + "\n");
        sb.append("MVIN_DT_OPTM_YN                 : " + "\tSize " + MVIN_DT_OPTM_YN.length + " : " + getData(MVIN_DT_OPTM_YN) + "\n");
        sb.append("SPUS_MVINYN                     : " + "\tSize " + SPUS_MVINYN.length + " : " + getData(SPUS_MVINYN) + "\n");
        sb.append("DBTR_OTSD_MVIN_OPTM_YN          : " + "\tSize " + DBTR_OTSD_MVIN_OPTM_YN.length + " : " + getData(DBTR_OTSD_MVIN_OPTM_YN) + "\n");
        sb.append("TTL_STRD_DTM                    : " + "\tSize " + TTL_STRD_DTM.length + " : " + getData(TTL_STRD_DTM) + "\n");
        sb.append("TTL_RSCH_DT                     : " + "\tSize " + TTL_RSCH_DT.length + " : " + getData(TTL_RSCH_DT) + "\n");
        sb.append("TTL_SRCHR_NM                    : " + "\tSize " + TTL_SRCHR_NM.length + " : " + getData(TTL_SRCHR_NM) + "\n");
        sb.append("TTL_DRWUP_DT                    : " + "\tSize " + TTL_DRWUP_DT.length + " : " + getData(TTL_DRWUP_DT) + "\n");
        sb.append("TTL_RMK                         : " + "\tSize " + TTL_RMK.length + " : " + getData(TTL_RMK) + "\n");
        sb.append("ISRN_SCRT_NO                    : " + "\tSize " + ISRN_SCRT_NO.length + " : " + getData(ISRN_SCRT_NO) + "\n");
        sb.append("ISRN_ENTR_AMT                   : " + "\tSize " + ISRN_ENTR_AMT.length + " : " + getData(ISRN_ENTR_AMT) + "\n");
        sb.append("RTHISRN_PRMM                    : " + "\tSize " + RTHISRN_PRMM.length + " : " + getData(RTHISRN_PRMM) + "\n");
        sb.append("UNUSL_FCT_EXST_YN               : " + "\tSize " + UNUSL_FCT_EXST_YN.length + " : " + getData(UNUSL_FCT_EXST_YN) + "\n");
        sb.append("UNUSL_THNG_YN                   : " + "\tSize " + UNUSL_THNG_YN.length + " : " + getData(UNUSL_THNG_YN) + "\n");
        sb.append("CNDTL_EXEC_YN                   : " + "\tSize " + CNDTL_EXEC_YN.length + " : " + getData(CNDTL_EXEC_YN) + "\n");
        sb.append("RTH_RSCH_FN_YN                  : " + "\tSize " + RTH_RSCH_FN_YN.length + " : " + getData(RTH_RSCH_FN_YN) + "\n");
        sb.append("RSRV_ITM_B                      : " + "\tSize " + RSRV_ITM_B.length + " : " + getData(RSRV_ITM_B) + "\n");
        return sb.toString();
    }

    public void readDataStream(InputStream stream) {
        try {
            stream.read(TG_LEN, 0, TG_LEN.length);
            stream.read(TG_DSC, 0, TG_DSC.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(LND_AGNC_CD, 0, LND_AGNC_CD.length);
            stream.read(BNK_TG_TRNS_DTM, 0, BNK_TG_TRNS_DTM.length);
            stream.read(DB_TG_TRNS_DTM, 0, DB_TG_TRNS_DTM.length);
            stream.read(BNK_TG_NO, 0, BNK_TG_NO.length);
            stream.read(DB_TG_NO, 0, DB_TG_NO.length);
            stream.read(RSRV_ITM_H, 0, RSRV_ITM_H.length);
            stream.read(BNK_ASK_NO, 0, BNK_ASK_NO.length);
            stream.read(LN_APRV_NO, 0, LN_APRV_NO.length);
            stream.read(DB_MNG_NO, 0, DB_MNG_NO.length);
            stream.read(KOS_MNG_NO, 0, KOS_MNG_NO.length);
            stream.read(KOS_TG_TRNS_DTM, 0, KOS_TG_TRNS_DTM.length);
            stream.read(KOS_TG_NO, 0, KOS_TG_NO.length);
            stream.read(LND_KCD, 0, LND_KCD.length);
            stream.read(FND_YN, 0, FND_YN.length);
            stream.read(CNFMTN_DSC, 0, CNFMTN_DSC.length);
            stream.read(SRV_DSC, 0, SRV_DSC.length);
            stream.read(OJT_ANS, 0, OJT_ANS.length);
            stream.read(SJT_ANS_1, 0, SJT_ANS_1.length);
            stream.read(SJT_ANS_2, 0, SJT_ANS_2.length);
            stream.read(SJT_ANS_3, 0, SJT_ANS_3.length);
            stream.read(SJT_ANS_4, 0, SJT_ANS_4.length);
            stream.read(SJT_ANS_5, 0, SJT_ANS_5.length);
            stream.read(SLF_CTFC_AGNC, 0, SLF_CTFC_AGNC.length);
            stream.read(SLF_CTFC_TM, 0, SLF_CTFC_TM.length);
            stream.read(RES_YN, 0, RES_YN.length);
            stream.read(OPTM_YN, 0, OPTM_YN.length);
            stream.read(CNFM_RSLT_BNK_TRNS_YN, 0, CNFM_RSLT_BNK_TRNS_YN.length);
            stream.read(BNK_RES_DTM, 0, BNK_RES_DTM.length);
            stream.read(LND_AMT_JST_PMNT_YN, 0, LND_AMT_JST_PMNT_YN.length);
            stream.read(RCPT_JST_CHRGYN, 0, RCPT_JST_CHRGYN.length);
            stream.read(RGSTRACPT_THDY_YN, 0, RGSTRACPT_THDY_YN.length);
            stream.read(RGSTR_ERSR_ACPT_NO, 0, RGSTR_ERSR_ACPT_NO.length);
            stream.read(FXCLT_ESTBS_YN, 0, FXCLT_ESTBS_YN.length);
            stream.read(FXCLT_ESTBS_RNK_JST_YN, 0, FXCLT_ESTBS_RNK_JST_YN.length);
            stream.read(FXCLT_ESTBS_AMT_JST_YN, 0, FXCLT_ESTBS_AMT_JST_YN.length);
            stream.read(ACPTNO_JST_YN, 0, ACPTNO_JST_YN.length);
            stream.read(ODPRT_JST_YN, 0, ODPRT_JST_YN.length);
            stream.read(RSCH_DTM, 0, RSCH_DTM.length);
            stream.read(SRCHR_NM, 0, SRCHR_NM.length);
            stream.read(SRCHR_PHNO, 0, SRCHR_PHNO.length);
            stream.read(STND_RMK, 0, STND_RMK.length);
            stream.read(LSSR_MVINHSHLD_YN, 0, LSSR_MVINHSHLD_YN.length);
            stream.read(LSSR_LSSR_HVTTYN, 0, LSSR_LSSR_HVTTYN.length);
            stream.read(LSSR_NM, 0, LSSR_NM.length);
            stream.read(LSSR_RLTSP, 0, LSSR_RLTSP.length);
            stream.read(LSSR_MVIN_DT, 0, LSSR_MVIN_DT.length);
            stream.read(LSHDR_MVIN_HSHLD_EANE, 0, LSHDR_MVIN_HSHLD_EANE.length);
            stream.read(LSHDR_HVTT_YN, 0, LSHDR_HVTT_YN.length);
            stream.read(LSHDR_NM, 0, LSHDR_NM.length);
            stream.read(LSHDR_RLTSP, 0, LSHDR_RLTSP.length);
            stream.read(LSHDR_MVIN_DT, 0, LSHDR_MVIN_DT.length);
            stream.read(DBTR_SLF_MVIN_YN, 0, DBTR_SLF_MVIN_YN.length);
            stream.read(MVIN_ADDR_OPTM_YN, 0, MVIN_ADDR_OPTM_YN.length);
            stream.read(MVIN_DT_OPTM_YN, 0, MVIN_DT_OPTM_YN.length);
            stream.read(SPUS_MVINYN, 0, SPUS_MVINYN.length);
            stream.read(DBTR_OTSD_MVIN_OPTM_YN, 0, DBTR_OTSD_MVIN_OPTM_YN.length);
            stream.read(TTL_STRD_DTM, 0, TTL_STRD_DTM.length);
            stream.read(TTL_RSCH_DT, 0, TTL_RSCH_DT.length);
            stream.read(TTL_SRCHR_NM, 0, TTL_SRCHR_NM.length);
            stream.read(TTL_DRWUP_DT, 0, TTL_DRWUP_DT.length);
            stream.read(TTL_RMK, 0, TTL_RMK.length);
            stream.read(ISRN_SCRT_NO, 0, ISRN_SCRT_NO.length);
            stream.read(ISRN_ENTR_AMT, 0, ISRN_ENTR_AMT.length);
            stream.read(RTHISRN_PRMM, 0, RTHISRN_PRMM.length);
            stream.read(UNUSL_FCT_EXST_YN, 0, UNUSL_FCT_EXST_YN.length);
            stream.read(UNUSL_THNG_YN, 0, UNUSL_THNG_YN.length);
            stream.read(CNDTL_EXEC_YN, 0, CNDTL_EXEC_YN.length);
            stream.read(RTH_RSCH_FN_YN, 0, RTH_RSCH_FN_YN.length);
            stream.read(RSRV_ITM_B, 0, RSRV_ITM_B.length);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
