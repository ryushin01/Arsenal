package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoTrnDb6200W2Dto;
import com.bankle.common.entity.TbWoTrnDb6200W2;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoTrnDb6200W2Mapper extends DefaultMapper<TbWoTrnDb6200W2Dto, TbWoTrnDb6200W2> {
    TbWoTrnDb6200W2Mapper INSTANCE = Mappers.getMapper(TbWoTrnDb6200W2Mapper.class);
}