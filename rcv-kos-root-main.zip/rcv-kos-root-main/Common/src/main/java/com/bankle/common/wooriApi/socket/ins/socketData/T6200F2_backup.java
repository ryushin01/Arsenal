package com.bankle.common.wooriApi.socket.ins.socketData;

import java.io.IOException;
import java.io.InputStream;

public class T6200F2_backup extends GetSetData {
    byte[] TG_LEN = new byte[4];
    byte[] TG_DSC = new byte[4];
    byte[] BNK_TG_NO = new byte[8];
    byte[] FA_TG_NO = new byte[8];
    byte[] KOS_TG_SND_NO = new byte[14];
    byte[] TG_SND_DTM = new byte[14];
    byte[] TG_RCV_DTM = new byte[14];
    byte[] RES_CD = new byte[3];
    byte[] RSRV_ITM_H = new byte[35];
    byte[] BNK_TTL_REQ_NO = new byte[20];
    byte[] LN_APRV_NO = new byte[20];
    byte[] PROC_DSC = new byte[2];
    byte[] LND_KND_CD = new byte[2];
    byte[] FND_USE_CD = new byte[2];
    byte[] LND_PMNT_CNFM_SLF_CD = new byte[1];
    byte[] RCPT_INFO_CNFM_SLF_CD = new byte[1];
    byte[] THDY_RGSTR_ACPT_NO_INPT_YN = new byte[1];
    byte[] ESTBS_RGSTR_ACPT_NO_1 = new byte[9];
    byte[] ESTBS_RGSTR_ACPT_NO_2 = new byte[9];
    byte[] ESTBS_RGSTR_ACPT_NO_3 = new byte[9];
    byte[] ERSR_ACPT_NO_1 = new byte[9];
    byte[] ERSR_ACPT_NO_2 = new byte[9];
    byte[] ERSR_ACPT_NO_3 = new byte[9];
    //byte[] ERSR_ACPT_NO_4 = new byte[9];
    byte[] RMK_B1 = new byte[100];
    byte[] BNK_FXCLT_ESTBS_FN_YN = new byte[1];
    byte[] BNK_FXCLT_RNK_MTH_YN = new byte[1];
    byte[] BNK_FXCLT_ESTBS_NO_MTH_YN = new byte[1];
    byte[] RGST_ATCP_THNG_ADDR = new byte[300];
    byte[] RGSTR_UNQ_NO_1 = new byte[14];
    byte[] RGSTR_UNQ_NO_2 = new byte[14];
    byte[] RGSTR_UNQ_NO_3 = new byte[14];
    byte[] RGSTR_UNQ_NO_4 = new byte[14];
    byte[] RGSTR_UNQ_NO_5 = new byte[14];
    byte[] BNK_FXCLT_RGSTR_ACPT_DT = new byte[8];
    byte[] OWN_OWNSH_MV_RGSTR_ACPT_DT = new byte[8];
    byte[] OWN_NM_1 = new byte[50];
    byte[] OWN_NM_2 = new byte[50];
    byte[] OWN_NM_3 = new byte[50];
    byte[] OWN_BIRTH_DT_1 = new byte[13];
    byte[] OWN_BIRTH_DT_2 = new byte[13];
    byte[] OWN_BIRTH_DT_3 = new byte[13];
    byte[] RMK_B2 = new byte[150];
    byte[] DBTR_RRCP_SBMT_YN = new byte[1];
    byte[] DBTR_FRC_SBMT_YN = new byte[1];
    byte[] RRCP_DBTR_SLF_RGST_YN = new byte[1];
    byte[] RRCP_SPUS_RGST_YN = new byte[1];
    byte[] FRC_SPUS_CNFM_YN = new byte[1];
    byte[] RMK_B3 = new byte[150];
    byte[] DBTR_TGRC_SBMT_YN = new byte[1];
    byte[] TGRC_DBTR_SLF_MVIN_YN = new byte[1];
    byte[] TGRC_DBTR_OTSD_SPRT_HSHLD_EANE = new byte[1];
    byte[] EXEDT_MV_MVIN_EANE = new byte[1];
    byte[] BNK_DBTR_TGRC_MTH_YN = new byte[1];
    byte[] NOW_RENTER_EVCT_YN = new byte [1];
    byte[] MVIN_HSHLD_RD_DTM = new byte[14];
    byte[] RMK_B4 = new byte[200];
    byte[] RSCH_AGNC_NM = new byte[30];
    byte[] SRCHR_NM = new byte[50];
    byte[] SRCHR_PHNO = new byte[20];
    byte[] RSCH_DTM = new byte[14];
    byte[] SRV_RSCH_DSC = new byte[1];
    byte[] OJT_ANS = new byte[50];
    byte[] SJT_ANS_1 = new byte[200];
    byte[] SJT_ANS_2 = new byte[200];
    byte[] SJT_ANS_3 = new byte[200];
    byte[] SJT_ANS_4 = new byte[200];
    byte[] SJT_ANS_5 = new byte[200];
    byte[] SLF_CTFC_AGNC = new byte[50];
    byte[] SLF_CTFC_TM = new byte[12];
    byte[] RESYN = new byte[1];
    byte[] PSL_CNFM_STRD_OPTM_YN = new byte[1];
    byte[] PSL_CNFM_RSLT_BNK_TRNS_YN = new byte[1];
    byte[] PSL_CNFM_RSLT_BNK_RCV_TM = new byte[12];
    byte[] FST_EXMN_RSLT = new byte[1];
    byte[] SCD_EXMN_RSLT = new byte[1];
    byte[] RSRV_ITM_B = new byte[350];
    //byte[] RRCP_CNFM_REQ_YN = new byte[1];


    public T6200F2_backup() {
        setData(this.TG_LEN, "");
        setData(this.TG_DSC, "");
        setData(this.BNK_TG_NO, "");
        setData(this.FA_TG_NO, "");
        setData(this.KOS_TG_SND_NO, "");
        setData(this.TG_SND_DTM, "");
        setData(this.TG_RCV_DTM, "");
        setData(this.RES_CD, "");
        setData(this.RSRV_ITM_H, "");
        setData(this.BNK_TTL_REQ_NO, "");
        setData(this.PROC_DSC, "");
        setData(this.LND_KND_CD, "");
        setData(this.FND_USE_CD, "");
        setData(this.LND_PMNT_CNFM_SLF_CD, "");
        setData(this.RCPT_INFO_CNFM_SLF_CD, "");
        setData(this.THDY_RGSTR_ACPT_NO_INPT_YN, "");
        setData(this.ESTBS_RGSTR_ACPT_NO_1, "");
        setData(this.ESTBS_RGSTR_ACPT_NO_2, "");
        setData(this.ESTBS_RGSTR_ACPT_NO_3, "");
        setData(this.ERSR_ACPT_NO_1, "");
        setData(this.ERSR_ACPT_NO_2, "");
        setData(this.ERSR_ACPT_NO_3, "");
        setData(this.RMK_B1, "");
        setData(this.BNK_FXCLT_ESTBS_FN_YN, "");
        setData(this.BNK_FXCLT_RNK_MTH_YN, "");
        setData(this.BNK_FXCLT_ESTBS_NO_MTH_YN, "");
        setData(this.RGST_ATCP_THNG_ADDR, "");
        setData(this.RGSTR_UNQ_NO_1, "");
        setData(this.RGSTR_UNQ_NO_2, "");
        setData(this.RGSTR_UNQ_NO_3, "");
        setData(this.RGSTR_UNQ_NO_4, "");
        setData(this.RGSTR_UNQ_NO_5, "");
        setData(this.BNK_FXCLT_RGSTR_ACPT_DT, "");
        setData(this.OWN_OWNSH_MV_RGSTR_ACPT_DT, "");
        setData(this.OWN_NM_1, "");
        setData(this.OWN_NM_2, "");
        setData(this.OWN_NM_3, "");
        setData(this.OWN_BIRTH_DT_1, "");
        setData(this.OWN_BIRTH_DT_2, "");
        setData(this.OWN_BIRTH_DT_3, "");
        setData(this.RMK_B2, "");
        setData(this.DBTR_RRCP_SBMT_YN, "");
        setData(this.DBTR_FRC_SBMT_YN, "");
        setData(this.RRCP_DBTR_SLF_RGST_YN, "");
        setData(this.RRCP_SPUS_RGST_YN, "");
        setData(this.FRC_SPUS_CNFM_YN, "");
        setData(this.RMK_B3, "");
        setData(this.DBTR_TGRC_SBMT_YN, "");
        setData(this.TGRC_DBTR_SLF_MVIN_YN, "");
        setData(this.TGRC_DBTR_OTSD_SPRT_HSHLD_EANE, "");
        setData(this.EXEDT_MV_MVIN_EANE, "");
        setData(this.BNK_DBTR_TGRC_MTH_YN, "");
        setData(this.NOW_RENTER_EVCT_YN, "");
        setData(this.MVIN_HSHLD_RD_DTM, "");
        setData(this.RMK_B4, "");
        setData(this.RSCH_AGNC_NM, "");
        setData(this.SRCHR_NM, "");
        setData(this.SRCHR_PHNO, "");
        setData(this.RSCH_DTM, "");
        setData(this.SRV_RSCH_DSC, "");
        setData(this.OJT_ANS, "");
        setData(this.SJT_ANS_1, "");
        setData(this.SJT_ANS_2, "");
        setData(this.SJT_ANS_3, "");
        setData(this.SJT_ANS_4, "");
        setData(this.SJT_ANS_5, "");
        setData(this.SLF_CTFC_AGNC, "");
        setData(this.SLF_CTFC_TM, "");
        setData(this.RESYN, "");
        setData(this.PSL_CNFM_STRD_OPTM_YN, "");
        setData(this.PSL_CNFM_RSLT_BNK_TRNS_YN, "");
        setData(this.PSL_CNFM_RSLT_BNK_RCV_TM, "");
        setData(this.FST_EXMN_RSLT, "");
        setData(this.SCD_EXMN_RSLT, "");
        setData(this.RSRV_ITM_B, "");
        //setData(this.RRCP_CNFM_REQ_YN, "");
    }

    public String getTG_LEN() {
        return getData(TG_LEN);
    }

    public String getTG_DSC() {
        return getData(TG_DSC);
    }

    public String getBNK_TG_NO() {
        return getData(BNK_TG_NO);
    }

    public String getFA_TG_NO() {
        return getData(FA_TG_NO);
    }

    public String getKOS_TG_SND_NO() {
        return getData(KOS_TG_SND_NO);
    }

    public String getTG_SND_DTM() {
        return getData(TG_SND_DTM);
    }

    public String getTG_RCV_DTM() {
        return getData(TG_RCV_DTM);
    }

    public String getRES_CD() {
        return getData(RES_CD);
    }

    public String getRSRV_ITM_H() {
        return getData(RSRV_ITM_H);
    }

    public String getBNK_TTL_REQ_NO() {
        return getData(BNK_TTL_REQ_NO);
    }

    public String getLN_APRV_NO() {
        return getData(LN_APRV_NO);
    }

    public String getPROC_DSC() {
        return getData(PROC_DSC);
    }

    public String getLND_KND_CD() {
        return getData(LND_KND_CD);
    }

    public String getFND_USE_CD() {
        return getData(FND_USE_CD);
    }

    public String getLND_PMNT_CNFM_SLF_CD() {
        return getData(LND_PMNT_CNFM_SLF_CD);
    }

    public String getRCPT_INFO_CNFM_SLF_CD() {
        return getData(RCPT_INFO_CNFM_SLF_CD);
    }

    public String getTHDY_RGSTR_ACPT_NO_INPT_YN() {
        return getData(THDY_RGSTR_ACPT_NO_INPT_YN);
    }

    public String getESTBS_RGSTR_ACPT_NO_1() {
        return getData(ESTBS_RGSTR_ACPT_NO_1);
    }

    public String getESTBS_RGSTR_ACPT_NO_2() {
        return getData(ESTBS_RGSTR_ACPT_NO_2);
    }

    public String getESTBS_RGSTR_ACPT_NO_3() {
        return getData(ESTBS_RGSTR_ACPT_NO_3);
    }

    public String getERSR_ACPT_NO_1() {
        return getData(ERSR_ACPT_NO_1);
    }

    public String getERSR_ACPT_NO_2() {
        return getData(ERSR_ACPT_NO_2);
    }

    public String getERSR_ACPT_NO_3() {
        return getData(ERSR_ACPT_NO_3);
    }

    public String getRMK_B1() {
        return getData(RMK_B1);
    }

    public String getBNK_FXCLT_ESTBS_FN_YN() {
        return getData(BNK_FXCLT_ESTBS_FN_YN);
    }

    public String getBNK_FXCLT_RNK_MTH_YN() {
        return getData(BNK_FXCLT_RNK_MTH_YN);
    }

    public String getBNK_FXCLT_ESTBS_NO_MTH_YN() {
        return getData(BNK_FXCLT_ESTBS_NO_MTH_YN);
    }

    public String getRGST_ATCP_THNG_ADDR() {
        return getData(RGST_ATCP_THNG_ADDR);
    }

    public String getRGSTR_UNQ_NO_1() {
        return getData(RGSTR_UNQ_NO_1);
    }

    public String getRGSTR_UNQ_NO_2() {
        return getData(RGSTR_UNQ_NO_2);
    }

    public String getRGSTR_UNQ_NO_3() {
        return getData(RGSTR_UNQ_NO_3);
    }

    public String getRGSTR_UNQ_NO_4() {
        return getData(RGSTR_UNQ_NO_4);
    }

    public String getRGSTR_UNQ_NO_5() {
        return getData(RGSTR_UNQ_NO_5);
    }

    public String getBNK_FXCLT_RGSTR_ACPT_DT() {
        return getData(BNK_FXCLT_RGSTR_ACPT_DT);
    }

    public String getOWN_OWNSH_MV_RGSTR_ACPT_DT() {
        return getData(OWN_OWNSH_MV_RGSTR_ACPT_DT);
    }

    public String getOWN_NM_1() {
        return getData(OWN_NM_1);
    }

    public String getOWN_NM_2() {
        return getData(OWN_NM_2);
    }

    public String getOWN_NM_3() {
        return getData(OWN_NM_3);
    }

    public String getOWN_BIRTH_DT_1() {
        return getData(OWN_BIRTH_DT_1);
    }

    public String getOWN_BIRTH_DT_2() {
        return getData(OWN_BIRTH_DT_2);
    }

    public String getOWN_BIRTH_DT_3() {
        return getData(OWN_BIRTH_DT_3);
    }

    public String getRMK_B2() {
        return getData(RMK_B2);
    }

    public String getDBTR_RRCP_SBMT_YN() {
        return getData(DBTR_RRCP_SBMT_YN);
    }

    public String getDBTR_FRC_SBMT_YN() {
        return getData(DBTR_FRC_SBMT_YN);
    }

    public String getRRCP_DBTR_SLF_RGST_YN() {
        return getData(RRCP_DBTR_SLF_RGST_YN);
    }

    public String getRRCP_SPUS_RGST_YN() {
        return getData(RRCP_SPUS_RGST_YN);
    }

    public String getFRC_SPUS_CNFM_YN() {
        return getData(FRC_SPUS_CNFM_YN);
    }

    public String getRMK_B3() {
        return getData(RMK_B3);
    }

    public String getDBTR_TGRC_SBMT_YN() {
        return getData(DBTR_TGRC_SBMT_YN);
    }

    public String getTGRC_DBTR_SLF_MVIN_YN() {
        return getData(TGRC_DBTR_SLF_MVIN_YN);
    }

    public String getTGRC_DBTR_OTSD_SPRT_HSHLD_EANE() {
        return getData(TGRC_DBTR_OTSD_SPRT_HSHLD_EANE);
    }

    public String getEXEDT_MV_MVIN_EANE() {
        return getData(EXEDT_MV_MVIN_EANE);
    }

    public String getBNK_DBTR_TGRC_MTH_YN() { return getData(BNK_DBTR_TGRC_MTH_YN); }

    public String getNOW_RENTER_EVCT_YN() { return getData(NOW_RENTER_EVCT_YN); }

    public String getMVIN_HSHLD_RD_DTM() {
        return getData(MVIN_HSHLD_RD_DTM);
    }

    public String getRMK_B4() {
        return getData(RMK_B4);
    }

    public String getRSCH_AGNC_NM() {
        return getData(RSCH_AGNC_NM);
    }

    public String getSRCHR_NM() {
        return getData(SRCHR_NM);
    }


    public String getSRCHR_PHNO() {
        return getData(SRCHR_PHNO);
    }

    public String getRSCH_DTM() {
        return getData(RSCH_DTM);
    }

    public String getSRV_RSCH_DSC() {
        return getData(SRV_RSCH_DSC);
    }

    public String getOJT_ANS() {
        return getData(OJT_ANS);
    }

    public String getSJT_ANS_1() {
        return getData(SJT_ANS_1);
    }

    public String getSJT_ANS_2() {
        return getData(SJT_ANS_2);
    }

    public String getSJT_ANS_3() {
        return getData(SJT_ANS_3);
    }


    public String getSJT_ANS_4() {
        return getData(SJT_ANS_4);
    }


    public String getSJT_ANS_5() {
        return getData(SJT_ANS_5);
    }

    public String getSLF_CTFC_AGNC() {
        return getData(SLF_CTFC_AGNC);
    }


    public String getSLF_CTFC_TM() {
        return getData(SLF_CTFC_TM);
    }

    public String RESYN() {
        return getData(RESYN);
    }

    public String getPSL_CNFM_STRD_OPTM_YN() {
        return getData(PSL_CNFM_STRD_OPTM_YN);
    }

    public String getPSL_CNFM_RSLT_BNK_TRNS_YN() {
        return getData(PSL_CNFM_RSLT_BNK_TRNS_YN);
    }

    public String getPSL_CNFM_RSLT_BNK_RCV_TM() {
        return getData(PSL_CNFM_RSLT_BNK_RCV_TM);
    }

    public String getFST_EXMN_RSLT() { return getData(FST_EXMN_RSLT); }

    public String getSCD_EXMN_RSLT() { return getData(SCD_EXMN_RSLT); }

    public String getRSRV_ITM_B() { return getData(RSRV_ITM_B); }

    //public String getRRCP_CNFM_REQ_YN() { return getData(RRCP_CNFM_REQ_YN); }

    public void setTG_LEN(String TG_LEN) { setData(this.TG_LEN, TG_LEN, "N"); }

    public void setTG_DSC(String TG_DSC) { setData(this.TG_DSC, TG_DSC, "S"); }

    public void setBNK_TG_NO(String BNK_TG_NO) { setData(this.BNK_TG_NO, BNK_TG_NO, "S"); }

    public void setFA_TG_NO(String FA_TG_NO) { setData(this.FA_TG_NO, FA_TG_NO, "S"); }

    public void setKOS_TG_SND_NO(String KOS_TG_SND_NO) { setData(this.KOS_TG_SND_NO, KOS_TG_SND_NO, "S"); }

    public void setTG_SND_DTM(String TG_SND_DTM) { setData(this.TG_SND_DTM, TG_SND_DTM, "S"); }

    public void setTG_RCV_DTM(String TG_RCV_DTM) { setData(this.TG_RCV_DTM, TG_RCV_DTM, "S"); }

    public void setRES_CD(String RES_CD) { setData(this.RES_CD, RES_CD, "S"); }

    public void setRSRV_ITM_H(String RSRV_ITM_H) { setData(this.RSRV_ITM_H, RSRV_ITM_H, "S"); }

    public void setBNK_TTL_REQ_NO(String BNK_TTL_REQ_NO) { setData(this.BNK_TTL_REQ_NO, BNK_TTL_REQ_NO, "S"); }

    public void setLN_APRV_NO(String LN_APRV_NO) { setData(this.LN_APRV_NO, LN_APRV_NO, "S"); }

    public void setPROC_DSC(String PROC_DSC) { setData(this.PROC_DSC, PROC_DSC, "S"); }

    public void setLND_KND_CD(String LND_KIND_CD) { setData(this.LND_KND_CD, LND_KIND_CD, "S"); }

    public void setFND_USE_CD(String FND_USE_CD) { setData(this.FND_USE_CD, FND_USE_CD, "S"); }

    public void setLND_PMNT_CNFM_SLF_CD(String LND_PMNT_CNFM_SLF_CD) { setData(this.LND_PMNT_CNFM_SLF_CD, LND_PMNT_CNFM_SLF_CD, "S"); }

    public void setRCPT_INFO_CNFM_SLF_CD(String RCPT_INFO_CNFM_SLF_CD) { setData(this.RCPT_INFO_CNFM_SLF_CD, RCPT_INFO_CNFM_SLF_CD, "S"); }

    public void setTHDY_RGSTR_ACPT_NO_INPT_YN(String THDY_RGSTR_ACPT_NO_INPT_YN) { setData(this.THDY_RGSTR_ACPT_NO_INPT_YN, THDY_RGSTR_ACPT_NO_INPT_YN, "S"); }

    public void setESTBS_RGSTR_ACPT_NO_1(String ESTBS_RGSTR_ACPT_NO_1) { setData(this.ESTBS_RGSTR_ACPT_NO_1, ESTBS_RGSTR_ACPT_NO_1, "S"); }

    public void setESTBS_RGSTR_ACPT_NO_2(String ESTBS_RGSTR_ACPT_NO_2) { setData(this.ESTBS_RGSTR_ACPT_NO_2, ESTBS_RGSTR_ACPT_NO_2, "S"); }


    public void setESTBS_RGSTR_ACPT_NO_3(String ESTBS_RGSTR_ACPT_NO_3) { setData(this.ESTBS_RGSTR_ACPT_NO_3, ESTBS_RGSTR_ACPT_NO_3, "S"); }

    public void setERSR_ACPT_NO_1(String ERSR_ACPT_NO_1) { setData(this.ERSR_ACPT_NO_1, ERSR_ACPT_NO_1, "S"); }

    public void setERSR_ACPT_NO_2(String ERSR_ACPT_NO_2) { setData(this.ERSR_ACPT_NO_2, ERSR_ACPT_NO_2, "S"); }

    public void setERSR_ACPT_NO_3(String ERSR_ACPT_NO_3) { setData(this.ERSR_ACPT_NO_3, ERSR_ACPT_NO_3, "S"); }

    public void setRMK_B1(String RMK_B1) { setData(this.RMK_B1, RMK_B1, "K"); }

    public void setBNK_FXCLT_ESTBS_FN_YN(String BNK_FXCLT_ESTBS_FN_YN) { setData(this.BNK_FXCLT_ESTBS_FN_YN, BNK_FXCLT_ESTBS_FN_YN, "S"); }

    public void setBNK_FXCLT_RNK_MTH_YN(String BNK_FXCLT_RNK_MTH_YN) { setData(this.BNK_FXCLT_RNK_MTH_YN, BNK_FXCLT_RNK_MTH_YN, "S"); }

    public void setBNK_FXCLT_ESTBS_NO_MTH_YN(String BNK_FXCLT_ESTBS_NO_MTH_YN) { setData(this.BNK_FXCLT_ESTBS_NO_MTH_YN, BNK_FXCLT_ESTBS_NO_MTH_YN, "S"); }

    public void setRGST_ATCP_THNG_ADDR(String RGST_ATCP_THNG_ADDR) { setData(this.RGST_ATCP_THNG_ADDR, RGST_ATCP_THNG_ADDR, "K"); }

    public void setRGSTR_UNQ_NO_1(String RGSTR_UNQ_NO_1) { setData(this.RGSTR_UNQ_NO_1, RGSTR_UNQ_NO_1, "S"); }

    public void setRGSTR_UNQ_NO_2(String RGSTR_UNQ_NO_2) { setData(this.RGSTR_UNQ_NO_2, RGSTR_UNQ_NO_2, "S"); }


    public void setRGSTR_UNQ_NO_3(String RGSTR_UNQ_NO_3) { setData(this.RGSTR_UNQ_NO_3, RGSTR_UNQ_NO_3, "S"); }


    public void setRGSTR_UNQ_NO_4(String RGSTR_UNQ_NO_4) { setData(this.RGSTR_UNQ_NO_4, RGSTR_UNQ_NO_4, "S"); }


    public void setRGSTR_UNQ_NO_5(String RGSTR_UNQ_NO_5) { setData(this.RGSTR_UNQ_NO_5, RGSTR_UNQ_NO_5, "S"); }

    public void setBNK_FXCLT_RGSTR_ACPT_DT(String BNK_FXCLT_RGSTR_ACPT_DT) { setData(this.BNK_FXCLT_RGSTR_ACPT_DT, BNK_FXCLT_RGSTR_ACPT_DT, "S"); }

    public void setOWN_OWNSH_MV_RGSTR_ACPT_DT(String OWN_OWNSH_MV_RGSTR_ACPT_DT) { setData(this.OWN_OWNSH_MV_RGSTR_ACPT_DT, OWN_OWNSH_MV_RGSTR_ACPT_DT, "S"); }

    public void setOWN_NM_1(String OWN_NM_1) { setData(this.OWN_NM_1, OWN_NM_1, "K"); }

    public void setOWN_NM_2(String OWN_NM_2) { setData(this.OWN_NM_2, OWN_NM_2, "K"); }

    public void setOWN_NM_3(String OWN_NM_3) { setData(this.OWN_NM_3, OWN_NM_3, "K"); }

    public void setOWN_BIRTH_DT_1(String OWN_BIRTH_DT_1) { setData(this.OWN_BIRTH_DT_1, OWN_BIRTH_DT_1, "S"); }


    public void setOWN_BIRTH_DT_2(String OWN_BIRTH_DT_2) { setData(this.OWN_BIRTH_DT_2, OWN_BIRTH_DT_2, "S"); }


    public void setOWN_BIRTH_DT_3(String OWN_BIRTH_DT_3) { setData(this.OWN_BIRTH_DT_3, OWN_BIRTH_DT_3, "S"); }

    public void setRMK_B2(String RMK_B2) { setData(this.RMK_B2, RMK_B2, "K"); }

    public void setDBTR_RRCP_SBMT_YN(String DBTR_RRCP_SBMT_YN) { setData(this.DBTR_RRCP_SBMT_YN, DBTR_RRCP_SBMT_YN, "S"); }

    public void setDBTR_FRC_SBMT_YN(String DBTR_FRC_SBMT_YN) { setData(this.DBTR_FRC_SBMT_YN, DBTR_FRC_SBMT_YN, "S"); }

    public void setRRCP_DBTR_SLF_RGST_YN(String RRCP_DBTR_SLF_RGST_YN) { setData(this.RRCP_DBTR_SLF_RGST_YN, RRCP_DBTR_SLF_RGST_YN, "S"); }

    public void setRRCP_SPUS_RGST_YN(String RRCP_SPUS_RGST_YN) { setData(this.RRCP_SPUS_RGST_YN, RRCP_SPUS_RGST_YN, "S"); }

    public void setFRC_SPUS_CNFM_YN(String FRC_SPUS_CNFM_YN) { setData(this.FRC_SPUS_CNFM_YN, FRC_SPUS_CNFM_YN, "S"); }

    public void setRMK_B3(String RMK_B3) { setData(this.RMK_B3, RMK_B3, "K"); }

    public void setDBTR_TGRC_SBMT_YN(String DBTR_TGRC_SBMT_YN) { setData(this.DBTR_TGRC_SBMT_YN, DBTR_TGRC_SBMT_YN, "S"); }

    public void setTGRC_DBTR_SLF_MVIN_YN(String TGRC_DBTR_SLF_MVIN_YN) { setData(this.TGRC_DBTR_SLF_MVIN_YN, TGRC_DBTR_SLF_MVIN_YN, "S"); }

    public void setTGRC_DBTR_OTSD_SPRT_HSHLD_EANE(String TGRC_DBTR_OTSD_SPRT_HSHLD_EANE) { setData(this.TGRC_DBTR_OTSD_SPRT_HSHLD_EANE, TGRC_DBTR_OTSD_SPRT_HSHLD_EANE, "S"); }

    public void setEXEDT_MV_MVIN_EANE(String EXEDT_MV_MVIN_EANE) { setData(this.EXEDT_MV_MVIN_EANE, EXEDT_MV_MVIN_EANE, "S"); }

    public void setBNK_DBTR_TGRC_MTH_YN(String BNK_DBTR_TGRC_MTH_YN) { setData(this.BNK_DBTR_TGRC_MTH_YN, BNK_DBTR_TGRC_MTH_YN, "S"); }
    public void setNOW_RENTER_EVCT_YN(String NOW_RENTER_EVCT_YN) { setData(this.NOW_RENTER_EVCT_YN, NOW_RENTER_EVCT_YN, "S"); }

    public void setMVIN_HSHLD_RD_DTM(String MVIN_HSHLD_RD_DTM) { setData(this.MVIN_HSHLD_RD_DTM, MVIN_HSHLD_RD_DTM, "S"); }

    public void setRMK_B4(String RMK_B4) { setData(this.RMK_B4, RMK_B4, "K"); }

    public void setRSCH_AGNC_NM(String RSCH_AGNC_NM) { setData(this.RSCH_AGNC_NM, RSCH_AGNC_NM, "K"); }

    public void setSRCHR_NM(String SRCHR_NM) { setData(this.SRCHR_NM, SRCHR_NM, "K"); }

    public void setSRCHR_PHNO(String SRCHR_PHNO) { setData(this.SRCHR_PHNO, SRCHR_PHNO, "S"); }

    public void setRSCH_DTM(String RSCH_DTM) { setData(this.RSCH_DTM, RSCH_DTM, "S"); }

    public void setSRV_RSCH_DSC(String SRV_RSCH_DSC) { setData(this.SRV_RSCH_DSC, SRV_RSCH_DSC, "S"); }

    public void setOJT_ANS(String OJT_ANS) { setData(this.OJT_ANS, OJT_ANS, "K"); }

    public void setSJT_ANS_1(String SJT_ANS_1) { setData(this.SJT_ANS_1, SJT_ANS_1, "K"); }

    public void setSJT_ANS_2(String SJT_ANS_2) { setData(this.SJT_ANS_2, SJT_ANS_2, "K"); }

    public void setSJT_ANS_3(String SJT_ANS_3) { setData(this.SJT_ANS_3, SJT_ANS_3, "K"); }

    public void setSJT_ANS_4(String SJT_ANS_4) { setData(this.SJT_ANS_4, SJT_ANS_4, "K"); }

    public void setSJT_ANS_5(String SJT_ANS_5) { setData(this.SJT_ANS_5, SJT_ANS_5, "K"); }

    public void setSLF_CTFC_AGNC(String SLF_CTFC_AGNC) { setData(this.SLF_CTFC_AGNC, SLF_CTFC_AGNC, "S"); }

    public void setSLF_CTFC_TM(String SLF_CTFC_TM) { setData(this.SLF_CTFC_TM, SLF_CTFC_TM, "S"); }

    public void setRESYN(String RESYN) { setData(this.RESYN, RESYN, "S"); }

    public void setPSL_CNFM_STRD_OPTM_YN(String PSL_CNFM_STRD_OPTM_YN) { setData(this.PSL_CNFM_STRD_OPTM_YN, PSL_CNFM_STRD_OPTM_YN, "S"); }

    public void setPSL_CNFM_RSLT_BNK_TRNS_YN(String PSL_CNFM_RSLT_BNK_TRNS_YN) { setData(this.PSL_CNFM_RSLT_BNK_TRNS_YN, PSL_CNFM_RSLT_BNK_TRNS_YN, "S"); }

    public void setPSL_CNFM_RSLT_BNK_RCV_TM(String PSL_CNFM_RSLT_BNK_RCV_TM) { setData(this.PSL_CNFM_RSLT_BNK_RCV_TM, PSL_CNFM_RSLT_BNK_RCV_TM, "S"); }

    public void setFST_EXMN_RSLT(String FST_EXMN_RSLT) { setData(this.FST_EXMN_RSLT, FST_EXMN_RSLT, "S"); }

    public void setSCD_EXMN_RSLT(String SCD_EXMN_RSLT) { setData(this.SCD_EXMN_RSLT, SCD_EXMN_RSLT, "S"); }

    public void setRSRV_ITM_B(String RSRV_ITM_B) { setData(this.RSRV_ITM_B, RSRV_ITM_B, "S"); }

    //public void setRRCP_CNFM_REQ_YN(String RRCP_CNFM_REQ_YN) { setData(this.RRCP_CNFM_REQ_YN, RRCP_CNFM_REQ_YN); }

    public String dataToString() {
        return getData(TG_LEN) + getData(TG_DSC) + getData(BNK_TG_NO) + getData(FA_TG_NO) + getData(KOS_TG_SND_NO) +
                getData(TG_SND_DTM) + getData(TG_RCV_DTM) + getData(RES_CD) + getData(RSRV_ITM_H) + getData(BNK_TTL_REQ_NO) + getData(LN_APRV_NO) +
                getData(PROC_DSC) + getData(LND_KND_CD) + getData(FND_USE_CD) + getData(LND_PMNT_CNFM_SLF_CD) + getData(RCPT_INFO_CNFM_SLF_CD) +
                getData(THDY_RGSTR_ACPT_NO_INPT_YN) + getData(ESTBS_RGSTR_ACPT_NO_1) + getData(ESTBS_RGSTR_ACPT_NO_2) + getData(ESTBS_RGSTR_ACPT_NO_3) + getData(ERSR_ACPT_NO_1) +
                getData(ERSR_ACPT_NO_2) + getData(ERSR_ACPT_NO_3) + getData(RMK_B1) + getData(BNK_FXCLT_ESTBS_FN_YN) + getData(BNK_FXCLT_RNK_MTH_YN) +
                getData(BNK_FXCLT_ESTBS_NO_MTH_YN) + getData(RGST_ATCP_THNG_ADDR) + getData(RGSTR_UNQ_NO_1) + getData(RGSTR_UNQ_NO_2) + getData(RGSTR_UNQ_NO_3) + getData(RGSTR_UNQ_NO_4) +
                getData(RGSTR_UNQ_NO_5) + getData(BNK_FXCLT_RGSTR_ACPT_DT) + getData(OWN_OWNSH_MV_RGSTR_ACPT_DT) + getData(OWN_NM_1) + getData(OWN_NM_2) +
                getData(OWN_NM_3) + getData(OWN_BIRTH_DT_1) + getData(OWN_BIRTH_DT_2) + getData(OWN_BIRTH_DT_3) + getData(RMK_B2) +
                getData(DBTR_RRCP_SBMT_YN) + getData(DBTR_FRC_SBMT_YN) + getData(RRCP_DBTR_SLF_RGST_YN) + getData(RRCP_SPUS_RGST_YN) +
                getData(FRC_SPUS_CNFM_YN) + getData(RMK_B3) + getData(DBTR_TGRC_SBMT_YN) + getData(TGRC_DBTR_SLF_MVIN_YN) + getData(TGRC_DBTR_OTSD_SPRT_HSHLD_EANE) +
                getData(EXEDT_MV_MVIN_EANE) + getData(BNK_DBTR_TGRC_MTH_YN) + getData(NOW_RENTER_EVCT_YN) + getData(MVIN_HSHLD_RD_DTM) + getData(RMK_B4) + getData(RSCH_AGNC_NM) +
                getData(SRCHR_NM) + getData(SRCHR_PHNO) + getData(RSCH_DTM) + getData(SRV_RSCH_DSC) + getData(OJT_ANS) +
                getData(SJT_ANS_1) + getData(SJT_ANS_2) + getData(SJT_ANS_3) + getData(SJT_ANS_4) + getData(SJT_ANS_5) +
                getData(SLF_CTFC_AGNC) + getData(SLF_CTFC_TM) + getData(RESYN) + getData(PSL_CNFM_STRD_OPTM_YN) + getData(PSL_CNFM_RSLT_BNK_TRNS_YN) +
                getData(PSL_CNFM_RSLT_BNK_RCV_TM) + getData(FST_EXMN_RSLT) + getData(SCD_EXMN_RSLT) + getData(RSRV_ITM_B);
    }

    public String print() {

        StringBuffer sb = new StringBuffer();

        sb.append("TG_LEN        	 	          : " + "\tSize " + TG_LEN.length + " : " + getData(TG_LEN) + "\n");
        sb.append("TG_DSC                         : " + "\tSize " + TG_DSC.length + " : " + getData(TG_DSC) + "\n");
        sb.append("BNK_TG_NO                      : " + "\tSize " + BNK_TG_NO.length + " : " + getData(BNK_TG_NO) + "\n");
        sb.append("FA_TG_NO                       : " + "\tSize " + FA_TG_NO.length + " : " + getData(FA_TG_NO) + "\n");
        sb.append("KOS_TG_SND_NO                  : " + "\tSize " + KOS_TG_SND_NO.length + " : " + getData(KOS_TG_SND_NO) + "\n");
        sb.append("TG_SND_DTM                     : " + "\tSize " + TG_SND_DTM.length + " : " + getData(TG_SND_DTM) + "\n");
        sb.append("TG_RCV_DTM                     : " + "\tSize " + TG_RCV_DTM.length + " : " + getData(TG_RCV_DTM) + "\n");
        sb.append("RES_CD                         : " + "\tSize " + RES_CD.length + " : " + getData(RES_CD) + "\n");
        sb.append("RSRV_ITM_H                     : " + "\tSize " + RSRV_ITM_H.length + " : " + getData(RSRV_ITM_H) + "\n");
        sb.append("BNK_TTL_REQ_NO                 : " + "\tSize " + BNK_TTL_REQ_NO.length + " : " + getData(BNK_TTL_REQ_NO) + "\n");
        sb.append("LN_APRV_NO                     : " + "\tSize " + LN_APRV_NO.length + " : " + getData(LN_APRV_NO) + "\n");
        sb.append("PROC_DSC                       : " + "\tSize " + PROC_DSC.length + " : " + getData(PROC_DSC) + "\n");
        sb.append("LND_KND_CD                     : " + "\tSize " + LND_KND_CD.length + " : " + getData(LND_KND_CD) + "\n");
        sb.append("FND_USE_CD                     : " + "\tSize " + FND_USE_CD.length + " : " + getData(FND_USE_CD) + "\n");
        sb.append("LND_PMNT_CNFM_SLF_CD           : " + "\tSize " + LND_PMNT_CNFM_SLF_CD.length + " : " + getData(LND_PMNT_CNFM_SLF_CD) + "\n");
        sb.append("RCPT_INFO_CNFM_SLF_CD          : " + "\tSize " + RCPT_INFO_CNFM_SLF_CD.length + " : " + getData(RCPT_INFO_CNFM_SLF_CD) + "\n");
        sb.append("THDY_RGSTR_ACPT_NO_INPT_YN     : " + "\tSize " + THDY_RGSTR_ACPT_NO_INPT_YN.length + " : " + getData(THDY_RGSTR_ACPT_NO_INPT_YN) + "\n");
        sb.append("ESTBS_RGSTR_ACPT_NO_1          : " + "\tSize " + ESTBS_RGSTR_ACPT_NO_1.length + " : " + getData(ESTBS_RGSTR_ACPT_NO_1) + "\n");
        sb.append("ESTBS_RGSTR_ACPT_NO_2          : " + "\tSize " + ESTBS_RGSTR_ACPT_NO_2.length + " : " + getData(ESTBS_RGSTR_ACPT_NO_2) + "\n");
        sb.append("ESTBS_RGSTR_ACPT_NO_3          : " + "\tSize " + ESTBS_RGSTR_ACPT_NO_3.length + " : " + getData(ESTBS_RGSTR_ACPT_NO_3) + "\n");
        sb.append("ERSR_ACPT_NO_1                 : " + "\tSize " + ERSR_ACPT_NO_1.length + " : " + getData(ERSR_ACPT_NO_1) + "\n");
        sb.append("ERSR_ACPT_NO_2                 : " + "\tSize " + ERSR_ACPT_NO_2.length + " : " + getData(ERSR_ACPT_NO_2) + "\n");
        sb.append("ERSR_ACPT_NO_3                 : " + "\tSize " + ERSR_ACPT_NO_3.length + " : " + getData(ERSR_ACPT_NO_3) + "\n");
        sb.append("RMK_B1                         : " + "\tSize " + RMK_B1.length + " : " + getData(RMK_B1) + "\n");
        sb.append("BNK_FXCLT_ESTBS_FN_YN          : " + "\tSize " + BNK_FXCLT_ESTBS_FN_YN.length + " : " + getData(BNK_FXCLT_ESTBS_FN_YN) + "\n");
        sb.append("BNK_FXCLT_RNK_MTH_YN           : " + "\tSize " + BNK_FXCLT_RNK_MTH_YN.length + " : " + getData(BNK_FXCLT_RNK_MTH_YN) + "\n");
        sb.append("BNK_FXCLT_ESTBS_NO_MTH_YN      : " + "\tSize " + BNK_FXCLT_ESTBS_NO_MTH_YN.length + " : " + getData(BNK_FXCLT_ESTBS_NO_MTH_YN) + "\n");
        sb.append("RGST_ATCP_THNG_ADDR            : " + "\tSize " + RGST_ATCP_THNG_ADDR.length + " : " + getData(RGST_ATCP_THNG_ADDR) + "\n");
        sb.append("RGSTR_UNQ_NO_1                 : " + "\tSize " + RGSTR_UNQ_NO_1.length + " : " + getData(RGSTR_UNQ_NO_1) + "\n");
        sb.append("RGSTR_UNQ_NO_2                 : " + "\tSize " + RGSTR_UNQ_NO_2.length + " : " + getData(RGSTR_UNQ_NO_2) + "\n");
        sb.append("RGSTR_UNQ_NO_3                 : " + "\tSize " + RGSTR_UNQ_NO_3.length + " : " + getData(RGSTR_UNQ_NO_3) + "\n");
        sb.append("RGSTR_UNQ_NO_4                 : " + "\tSize " + RGSTR_UNQ_NO_4.length + " : " + getData(RGSTR_UNQ_NO_4) + "\n");
        sb.append("RGSTR_UNQ_NO_5                 : " + "\tSize " + RGSTR_UNQ_NO_5.length + " : " + getData(RGSTR_UNQ_NO_5) + "\n");
        sb.append("BNK_FXCLT_RGSTR_ACPT_DT        : " + "\tSize " + BNK_FXCLT_RGSTR_ACPT_DT.length + " : " + getData(BNK_FXCLT_RGSTR_ACPT_DT) + "\n");
        sb.append("OWN_OWNSH_MV_RGSTR_ACPT_DT     : " + "\tSize " + OWN_OWNSH_MV_RGSTR_ACPT_DT.length + " : " + getData(OWN_OWNSH_MV_RGSTR_ACPT_DT) + "\n");
        sb.append("OWN_NM_1                       : " + "\tSize " + OWN_NM_1.length + " : " + getData(OWN_NM_1) + "\n");
        sb.append("OWN_NM_2                       : " + "\tSize " + OWN_NM_2.length + " : " + getData(OWN_NM_2) + "\n");
        sb.append("OWN_NM_3                       : " + "\tSize " + OWN_NM_3.length + " : " + getData(OWN_NM_3) + "\n");
        sb.append("OWN_BIRTH_DT_1                 : " + "\tSize " + OWN_BIRTH_DT_1.length + " : " + getData(OWN_BIRTH_DT_1) + "\n");
        sb.append("OWN_BIRTH_DT_2                 : " + "\tSize " + OWN_BIRTH_DT_2.length + " : " + getData(OWN_BIRTH_DT_2) + "\n");
        sb.append("OWN_BIRTH_DT_3                 : " + "\tSize " + OWN_BIRTH_DT_3.length + " : " + getData(OWN_BIRTH_DT_3) + "\n");
        sb.append("RMK_B2                         : " + "\tSize " + RMK_B2.length + " : " + getData(RMK_B2) + "\n");
        sb.append("DBTR_RRCP_SBMT_YN              : " + "\tSize " + DBTR_RRCP_SBMT_YN.length + " : " + getData(DBTR_RRCP_SBMT_YN) + "\n");
        sb.append("DBTR_FRC_SBMT_YN               : " + "\tSize " + DBTR_FRC_SBMT_YN.length + " : " + getData(DBTR_FRC_SBMT_YN) + "\n");
        sb.append("RRCP_DBTR_SLF_RGST_YN          : " + "\tSize " + RRCP_DBTR_SLF_RGST_YN.length + " : " + getData(RRCP_DBTR_SLF_RGST_YN) + "\n");
        sb.append("RRCP_SPUS_RGST_YN              : " + "\tSize " + RRCP_SPUS_RGST_YN.length + " : " + getData(RRCP_SPUS_RGST_YN) + "\n");
        sb.append("FRC_SPUS_CNFM_YN               : " + "\tSize " + FRC_SPUS_CNFM_YN.length + " : " + getData(FRC_SPUS_CNFM_YN) + "\n");
        sb.append("RMK_B3                         : " + "\tSize " + RMK_B3.length + " : " + getData(RMK_B3) + "\n");
        sb.append("DBTR_TGRC_SBMT_YN              : " + "\tSize " + DBTR_TGRC_SBMT_YN.length + " : " + getData(DBTR_TGRC_SBMT_YN) + "\n");
        sb.append("TGRC_DBTR_SLF_MVIN_YN          : " + "\tSize " + TGRC_DBTR_SLF_MVIN_YN.length + " : " + getData(TGRC_DBTR_SLF_MVIN_YN) + "\n");
        sb.append("TGRC_DBTR_OTSD_SPRT_HSHLD_EANE : " + "\tSize " + TGRC_DBTR_OTSD_SPRT_HSHLD_EANE.length + " : " + getData(TGRC_DBTR_OTSD_SPRT_HSHLD_EANE) + "\n");
        sb.append("EXEDT_MV_MVIN_EANE             : " + "\tSize " + EXEDT_MV_MVIN_EANE.length + " : " + getData(EXEDT_MV_MVIN_EANE) + "\n");
        sb.append("BNK_DBTR_TGRC_MTH_YN           : " + "\tSize " + BNK_DBTR_TGRC_MTH_YN.length + " : " + getData(BNK_DBTR_TGRC_MTH_YN) + "\n");
        sb.append("NOW_RENTER_EVCT_YN             : " + "\tSize " + NOW_RENTER_EVCT_YN.length + " : " + getData(NOW_RENTER_EVCT_YN) + "\n");
        sb.append("MVIN_HSHLD_RD_DTM              : " + "\tSize " + MVIN_HSHLD_RD_DTM.length + " : " + getData(MVIN_HSHLD_RD_DTM) + "\n");
        sb.append("RMK_B4                         : " + "\tSize " + RMK_B4.length + " : " + getData(RMK_B4) + "\n");
        sb.append("RSCH_AGNC_NM                   : " + "\tSize " + RSCH_AGNC_NM.length + " : " + getData(RSCH_AGNC_NM) + "\n");
        sb.append("SRCHR_NM                       : " + "\tSize " + SRCHR_NM.length + " : " + getData(SRCHR_NM) + "\n");
        sb.append("SRCHR_PHNO                     : " + "\tSize " + SRCHR_PHNO.length + " : " + getData(SRCHR_PHNO) + "\n");
        sb.append("RSCH_DTM                       : " + "\tSize " + RSCH_DTM.length + " : " + getData(RSCH_DTM) + "\n");
        sb.append("SRV_RSCH_DSC                   : " + "\tSize " + SRV_RSCH_DSC.length + " : " + getData(SRV_RSCH_DSC) + "\n");
        sb.append("OJT_ANS                        : " + "\tSize " + OJT_ANS.length + " : " + getData(OJT_ANS) + "\n");
        sb.append("SJT_ANS_1                      : " + "\tSize " + SJT_ANS_1.length + " : " + getData(SJT_ANS_1) + "\n");
        sb.append("SJT_ANS_2                      : " + "\tSize " + SJT_ANS_2.length + " : " + getData(SJT_ANS_2) + "\n");
        sb.append("SJT_ANS_3                      : " + "\tSize " + SJT_ANS_3.length + " : " + getData(SJT_ANS_3) + "\n");
        sb.append("SJT_ANS_4                      : " + "\tSize " + SJT_ANS_4.length + " : " + getData(SJT_ANS_4) + "\n");
        sb.append("SJT_ANS_5                      : " + "\tSize " + SJT_ANS_5.length + " : " + getData(SJT_ANS_5) + "\n");
        sb.append("SLF_CTFC_AGNC                  : " + "\tSize " + SLF_CTFC_AGNC.length + " : " + getData(SLF_CTFC_AGNC) + "\n");
        sb.append("SLF_CTFC_TM                    : " + "\tSize " + SLF_CTFC_TM.length + " : " + getData(SLF_CTFC_TM) + "\n");
        sb.append("RESYN                          : " + "\tSize " + RESYN.length + " : " + getData(RESYN) + "\n");
        sb.append("PSL_CNFM_STRD_OPTM_YN          : " + "\tSize " + PSL_CNFM_STRD_OPTM_YN.length + " : " + getData(PSL_CNFM_STRD_OPTM_YN) + "\n");
        sb.append("PSL_CNFM_RSLT_BNK_TRNS_YN      : " + "\tSize " + PSL_CNFM_RSLT_BNK_TRNS_YN.length + " : " + getData(PSL_CNFM_RSLT_BNK_TRNS_YN) + "\n");
        sb.append("PSL_CNFM_RSLT_BNK_RCV_TM       : " + "\tSize " + PSL_CNFM_RSLT_BNK_RCV_TM.length + " : " + getData(PSL_CNFM_RSLT_BNK_RCV_TM) + "\n");
        sb.append("FST_EXMN_RSLT                  : " + "\tSize " + FST_EXMN_RSLT.length + " : " + getData(FST_EXMN_RSLT) + "\n");
        sb.append("SCD_EXMN_RSLT                  : " + "\tSize " + SCD_EXMN_RSLT.length + " : " + getData(SCD_EXMN_RSLT) + "\n");
        sb.append("RSRV_ITM_B                     : " + "\tSize " + RSRV_ITM_B.length + " : " + getData(RSRV_ITM_B) + "\n");
        //sb.append("RRCP_CNFM_REQ_YN               : " + "\tSize " + RRCP_CNFM_REQ_YN.length + " : " + getData(RRCP_CNFM_REQ_YN) + "\n");

        return sb.toString();
    }

    public void readDataStream(InputStream stream) {
        try {
            stream.read(TG_LEN, 0, TG_LEN.length);
            stream.read(TG_DSC, 0, TG_DSC.length);
            stream.read(BNK_TG_NO, 0, BNK_TG_NO.length);
            stream.read(FA_TG_NO, 0, FA_TG_NO.length);
            stream.read(KOS_TG_SND_NO, 0, KOS_TG_SND_NO.length);
            stream.read(TG_SND_DTM, 0, TG_SND_DTM.length);
            stream.read(TG_RCV_DTM, 0, TG_RCV_DTM.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(RSRV_ITM_H, 0, RSRV_ITM_H.length);
            stream.read(BNK_TTL_REQ_NO, 0, BNK_TTL_REQ_NO.length);
            stream.read(LN_APRV_NO, 0, LN_APRV_NO.length);
            stream.read(PROC_DSC, 0, PROC_DSC.length);
            stream.read(LND_KND_CD, 0, LND_KND_CD.length);
            stream.read(FND_USE_CD, 0, FND_USE_CD.length);
            stream.read(LND_PMNT_CNFM_SLF_CD, 0, LND_PMNT_CNFM_SLF_CD.length);
            stream.read(RCPT_INFO_CNFM_SLF_CD, 0, RCPT_INFO_CNFM_SLF_CD.length);
            stream.read(THDY_RGSTR_ACPT_NO_INPT_YN, 0, THDY_RGSTR_ACPT_NO_INPT_YN.length);
            stream.read(ESTBS_RGSTR_ACPT_NO_1, 0, ESTBS_RGSTR_ACPT_NO_1.length);
            stream.read(ESTBS_RGSTR_ACPT_NO_2, 0, ESTBS_RGSTR_ACPT_NO_2.length);
            stream.read(ESTBS_RGSTR_ACPT_NO_3, 0, ESTBS_RGSTR_ACPT_NO_3.length);
            stream.read(ERSR_ACPT_NO_1, 0, ERSR_ACPT_NO_1.length);
            stream.read(ERSR_ACPT_NO_2, 0, ERSR_ACPT_NO_2.length);
            stream.read(ERSR_ACPT_NO_3, 0, ERSR_ACPT_NO_3.length);
            stream.read(RMK_B1, 0, RMK_B1.length);
            stream.read(BNK_FXCLT_ESTBS_FN_YN, 0, BNK_FXCLT_ESTBS_FN_YN.length);
            stream.read(BNK_FXCLT_RNK_MTH_YN, 0, BNK_FXCLT_RNK_MTH_YN.length);
            stream.read(BNK_FXCLT_ESTBS_NO_MTH_YN, 0, BNK_FXCLT_ESTBS_NO_MTH_YN.length);
            stream.read(RGST_ATCP_THNG_ADDR, 0, RGST_ATCP_THNG_ADDR.length);
            stream.read(RGSTR_UNQ_NO_1, 0, RGSTR_UNQ_NO_1.length);
            stream.read(RGSTR_UNQ_NO_2, 0, RGSTR_UNQ_NO_2.length);
            stream.read(RGSTR_UNQ_NO_3, 0, RGSTR_UNQ_NO_3.length);
            stream.read(RGSTR_UNQ_NO_4, 0, RGSTR_UNQ_NO_4.length);
            stream.read(RGSTR_UNQ_NO_5, 0, RGSTR_UNQ_NO_5.length);
            stream.read(BNK_FXCLT_RGSTR_ACPT_DT, 0, BNK_FXCLT_RGSTR_ACPT_DT.length);
            stream.read(OWN_OWNSH_MV_RGSTR_ACPT_DT, 0, OWN_OWNSH_MV_RGSTR_ACPT_DT.length);
            stream.read(OWN_NM_1, 0, OWN_NM_1.length);
            stream.read(OWN_NM_2, 0, OWN_NM_2.length);
            stream.read(OWN_NM_3, 0, OWN_NM_3.length);
            stream.read(OWN_BIRTH_DT_1, 0, OWN_BIRTH_DT_1.length);
            stream.read(OWN_BIRTH_DT_2, 0, OWN_BIRTH_DT_2.length);
            stream.read(OWN_BIRTH_DT_3, 0, OWN_BIRTH_DT_3.length);
            stream.read(RMK_B2, 0, RMK_B2.length);
            stream.read(DBTR_RRCP_SBMT_YN, 0, DBTR_RRCP_SBMT_YN.length);
            stream.read(DBTR_FRC_SBMT_YN, 0, DBTR_FRC_SBMT_YN.length);
            stream.read(RRCP_DBTR_SLF_RGST_YN, 0, RRCP_DBTR_SLF_RGST_YN.length);
            stream.read(RRCP_SPUS_RGST_YN, 0, RRCP_SPUS_RGST_YN.length);
            stream.read(FRC_SPUS_CNFM_YN, 0, FRC_SPUS_CNFM_YN.length);
            stream.read(RMK_B3, 0, RMK_B3.length);
            stream.read(DBTR_TGRC_SBMT_YN, 0, DBTR_TGRC_SBMT_YN.length);
            stream.read(TGRC_DBTR_SLF_MVIN_YN, 0, TGRC_DBTR_SLF_MVIN_YN.length);
            stream.read(TGRC_DBTR_OTSD_SPRT_HSHLD_EANE, 0, TGRC_DBTR_OTSD_SPRT_HSHLD_EANE.length);
            stream.read(EXEDT_MV_MVIN_EANE, 0, EXEDT_MV_MVIN_EANE.length);
            stream.read(BNK_DBTR_TGRC_MTH_YN, 0, BNK_DBTR_TGRC_MTH_YN.length);
            stream.read(NOW_RENTER_EVCT_YN, 0, NOW_RENTER_EVCT_YN.length);
            stream.read(MVIN_HSHLD_RD_DTM, 0, MVIN_HSHLD_RD_DTM.length);
            stream.read(RMK_B4, 0, RMK_B4.length);
            stream.read(RSCH_AGNC_NM, 0, RSCH_AGNC_NM.length);
            stream.read(SRCHR_NM, 0, SRCHR_NM.length);
            stream.read(SRCHR_PHNO, 0, SRCHR_PHNO.length);
            stream.read(RSCH_DTM, 0, RSCH_DTM.length);
            stream.read(SRV_RSCH_DSC, 0, SRV_RSCH_DSC.length);
            stream.read(OJT_ANS, 0, OJT_ANS.length);
            stream.read(SJT_ANS_1, 0, SJT_ANS_1.length);
            stream.read(SJT_ANS_2, 0, SJT_ANS_2.length);
            stream.read(SJT_ANS_3, 0, SJT_ANS_3.length);
            stream.read(SJT_ANS_4, 0, SJT_ANS_4.length);
            stream.read(SJT_ANS_5, 0, SJT_ANS_5.length);
            stream.read(SLF_CTFC_AGNC, 0, SLF_CTFC_AGNC.length);
            stream.read(SLF_CTFC_TM, 0, SLF_CTFC_TM.length);
            stream.read(RESYN, 0, RESYN.length);
            stream.read(PSL_CNFM_STRD_OPTM_YN, 0, PSL_CNFM_STRD_OPTM_YN.length);
            stream.read(PSL_CNFM_RSLT_BNK_TRNS_YN, 0, PSL_CNFM_RSLT_BNK_TRNS_YN.length);
            stream.read(PSL_CNFM_RSLT_BNK_RCV_TM, 0, PSL_CNFM_RSLT_BNK_RCV_TM.length);
            stream.read(FST_EXMN_RSLT, 0, FST_EXMN_RSLT.length);
            stream.read(SCD_EXMN_RSLT, 0, SCD_EXMN_RSLT.length);
            stream.read(RSRV_ITM_B, 0, RSRV_ITM_B.length);
            //stream.read(RRCP_CNFM_REQ_YN, 0, RRCP_CNFM_REQ_YN.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
