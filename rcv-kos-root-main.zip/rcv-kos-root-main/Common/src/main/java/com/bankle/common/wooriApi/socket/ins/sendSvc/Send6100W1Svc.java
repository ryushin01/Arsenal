package com.bankle.common.wooriApi.socket.ins.sendSvc;

import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.repo.TbWoTrnFa6500F5Repository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.DateUtil;
import com.bankle.common.utils.StringUtil;
import com.bankle.common.wooriApi.socket.ins.commonSvc.GetSetData;
import com.bankle.common.wooriApi.socket.ins.commonSvc.InsCmnSvc;
import com.bankle.common.wooriApi.socket.ins.commonSvc.vo.InsCmnSvo;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6100F1Svo;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6100W1Svo;
import com.bankle.common.wooriApi.socket.ins.socketData.T6100F1;
import com.bankle.common.wooriApi.socket.ins.socketData.T6100W1;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springdoc.core.configuration.SpringDocSecurityConfiguration;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;


@Slf4j
@Component
@RequiredArgsConstructor
public class Send6100W1Svc {

    private final TbWoTrnFa6500F5Repository tbWoTrnFa6500F5Repository;

    private final InsCmnSvc insCmnSvc;

    private final BizUtil bizUtil;

    private final String TG_DSC = "W1000";
    private final String BNK_CD = "020";
    private final String TR_DSC = "100";
    private final String TG_LEN = "2496";
    private final String RES_CD = "000";
    private final String REQ_TG_FN_YN = "Y";
    private final String RES_TG_FN_YN = "N";
    private final SpringDocSecurityConfiguration springDocSecurityConfiguration;


    @Transactional
    public CheckResponseSvo sendAndResponse(@Valid Send6100W1Svo.sendInVo invo) throws Exception{
        log.debug("Send6200F2Svc.sendAndResponse().invo : " + invo);
        log.debug("Send6200F2Svc.sendAndResponse().invo : " + invo.getLoanNo());
        String seq = this.send(invo);
        return insCmnSvc.checkResponse(seq);
    }

    @org.springframework.transaction.annotation.Transactional(propagation = Propagation.REQUIRES_NEW)
    public String send(Send6100W1Svo.sendInVo sendInVo) throws Exception {

        try {
            log.debug("Send6100W1Svc send > sendInVo : " + sendInVo);
            String seq = bizUtil.getSeq(Sequence.TRANS);
            T6100W1 sendData = new T6100W1();
            sendData.setTG_LEN(TG_LEN);                            // 1. 전문 길이
            sendData.setTG_DSC(TG_DSC);             // 2. 전문 구분 코드
            sendData.setRES_CD(RES_CD);                            // 7. 응답 코드
            sendData.setLND_AGNC_CD(sendInVo.getLndAgncCd());
            sendData.setBNK_TG_NO(sendInVo.getBnkTgNo());
            sendData.setDB_TG_NO(seq);
            sendData.setRSRV_ITM_H(sendInVo.getRsrvItmH());
            sendData.setBNK_ASK_NO(sendInVo.getBnkAskNo());
            sendData.setLN_APRV_NO(StringUtil.rpad(sendInVo.getLoanNo(), 14, "0"));
            sendData.setDB_MNG_NO(sendInVo.getDbMngNo());
            sendData.setKOS_TG_TRNS_DTM(DateUtil.getCurrentDateTime());
            sendData.setKOS_TG_NO(seq);
            sendData.setPROC_DVSN_CD(sendInVo.getProcDvsnCd());
            sendData.setRTH_ISRN_ENTR_YN(sendInVo.getRthIsrnEntrYn());
            sendData.setRTH_ISRN_ENTR_CMPY(sendInVo.getRthIsrnEntrCmpy());
            sendData.setRTH_ISRN_SCRT_NO(sendInVo.getRthIsrnScrtNo());
            sendData.setPST_NO(sendInVo.getPstNo());
            sendData.setCRTDN_CD(sendInVo.getCrtdnCd());
            sendData.setTRGT_ADDR(sendInVo.getTrgtAddr());
            sendData.setTRGT_DTL_ADDR(sendInVo.getTrgtDtlAddr());
            sendData.setRGSTR_UNQ_NO_1(sendInVo.getRgstrUnqNo1());
            sendData.setRGSTR_UNQ_NO_2(sendInVo.getRgstrUnqNo2());
            sendData.setRGSTR_UNQ_NO_3(sendInVo.getRgstrUnqNo3());
            sendData.setLND_KND_CD(sendInVo.getLndKndCd());
            sendData.setFND_YN(sendInVo.getFndYn());
            sendData.setPRDT_NM(sendInVo.getPrdtNm());
            sendData.setPRDT_CD(sendInVo.getPrdtCd());
            sendData.setGRNT_AGNC_CD(sendInVo.getGrntAgncCd());
            sendData.setSTND_TRGT_YN(sendInVo.getStndTrgtYn());
            sendData.setSRV_TRGT_YN(sendInVo.getSrvTrgtYn());
            sendData.setRRCP_CHRG_TRGT_YN(sendInVo.getRrcpChrgTrgtYn());
            sendData.setRVSN_CNTRCT_CHRG_TRGT_YN(sendInVo.getRvsnCntrctChrgTrgtYn());
            sendData.setSSCPT_ASK_DT(sendInVo.getSscptAskDt());
            sendData.setLND_PLN_DT(sendInVo.getLndPlnDt());
            sendData.setRNTL_PRD_END_DT(sendInVo.getRntlPrdEndDt());
            sendData.setLND_EXPRD_DT(sendInVo.getLndExprdDt());
            sendData.setLND_PRD(sendInVo.getLndPrd().toString());
            sendData.setLND_AMT(sendInVo.getLndAmt().toString());
            sendData.setISRN_ENTR_AMT(sendInVo.getIsrnEntrAmt().toString());
            sendData.setOBJT_EBNK_RGSTR_RNK(sendInVo.getObjtEbnkRgstrRnk().toString());
            sendData.setOBJT_EBNK_BND_MAX_AMT(sendInVo.getObjtEbnkBndMaxAmt().toString());
            sendData.setMGG_FNL_ODPRT_AMT(sendInVo.getMggFnlOdprtAmt().toString());
            sendData.setTROL_FNL_ODPRT_AMT(sendInVo.getTrolFnlOdprtAmt().toString());
            sendData.setSRVC_END_DT(sendInVo.getSrvcEndDt());
            sendData.setDBTR_RRNO(sendInVo.getDbtrRrno());
            sendData.setDBTR_PST_NO(sendInVo.getDbtrPstNo());
            sendData.setDBTR_ADDR(sendInVo.getDbtrAddr());
            sendData.setDBTR_PHNO(sendInVo.getDbtrPhno());
            sendData.setDBTR_HPNO(sendInVo.getDbtrHpno());
            sendData.setDBTR_NM(sendInVo.getDbtrNm());
            sendData.setWDNG_PLN_YN(sendInVo.getWdngPlnYn());
            sendData.setWDNG_PLN_DT(sendInVo.getWdngPlnDt());
            sendData.setHSHLDR_CNDDT_YN(sendInVo.getHshldrCnddtYn());
            sendData.setUNMRD_HSHLDR_25AG_LSTN_YN(sendInVo.getUnmrdHshldr25agLstnYn());
            sendData.setACPT_DSC(sendInVo.getAcptDsc());
            sendData.setLWFM_NM(sendInVo.getLwfmNm());
            sendData.setLWFM_BIZNO(sendInVo.getLwfmBizno());
            sendData.setASK_BRNCH_CD(sendInVo.getAskBrnchCd());
            sendData.setASK_BRNCH_NM(sendInVo.getAskBrnchNm());
            sendData.setASK_BRNCH_DRCTR_NM(sendInVo.getAskBrnchDrctrNm());
            sendData.setASK_BRNCH_PHNO(sendInVo.getAskBrnchPhno());
            sendData.setBNK_LES_DSC(sendInVo.getBnkLesDsc());
            sendData.setFND_LES_DSC(sendInVo.getFndLesDsc());
            sendData.setCNDTL_CNTS(sendInVo.getCndtlCnts());
            sendData.setISRN_PRMM(sendInVo.getIsrnPrmm());
            sendData.setRSRV_ITM_B(sendInVo.getRsrvItmB());

            log.debug(sendData.print());
            insCmnSvc.insSend(InsCmnSvo.insCmnInVo.builder()
                    .tgSqn(seq)
                    .bnkTgNo(sendData.getBNK_TG_NO())
                    .bnkCd(BNK_CD)
                    .tgDsc(TG_DSC)
                    .trDsc(TR_DSC)
                    .reqTgCnts(sendData.dataToString())
                    .reqTgLog(sendData.print())
                    .reqTgFnYn(REQ_TG_FN_YN)
                    .resTgFnYn(RES_TG_FN_YN)
                    .loanNo(sendInVo.getLoanNo())
                    .membNo("SYSTEM")
                    .build());

            return seq;
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException("전문 전송 테이블 적재시 오류가 발생했습니다! -> " + e.getMessage());
        }
    }
}
