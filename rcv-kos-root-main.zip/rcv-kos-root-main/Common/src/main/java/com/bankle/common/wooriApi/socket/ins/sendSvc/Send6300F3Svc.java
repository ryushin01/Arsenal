package com.bankle.common.wooriApi.socket.ins.sendSvc;

import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.repo.TbWoTrnFa6300F3Repository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.DateUtil;
import com.bankle.common.utils.StringUtil;
import com.bankle.common.wooriApi.socket.ins.commonSvc.GetSetData;
import com.bankle.common.wooriApi.socket.ins.commonSvc.InsCmnSvc;
import com.bankle.common.wooriApi.socket.ins.commonSvc.vo.InsCmnSvo;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6300F3Svo;
import com.bankle.common.wooriApi.socket.ins.socketData.T6300F3;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springdoc.core.configuration.SpringDocSecurityConfiguration;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;


@Slf4j
@Component
@RequiredArgsConstructor
public class Send6300F3Svc {
    private final InsCmnSvc insCmnSvc;
    private final TbWoTrnFa6300F3Repository tbWoTrnFa6300F3Repository;
    private final String BNK_TG_DSC = "6300";
    private final String TG_DSC = "F3000";
    private final String BNK_CD = "020";
    private final String TR_DSC = "100";
    private final String TG_LEN = "1100";
    private final String BNK_TG_NO = "";
    private final String FA_TG_NO = "";
    private final String RES_CD = "";
    private final String RSRV_ITM_H = "";
    private final String REQ_TG_FN_YN = "Y";
    private final String RES_TG_FN_YN = "N";
    private final GetSetData getSetData;
    private final SpringDocSecurityConfiguration springDocSecurityConfiguration;
    private final BizUtil bizUtil;


    @Transactional
    public CheckResponseSvo sendAndResponse(@Valid Send6300F3Svo.sendInVo invo) throws Exception{
        log.debug("Send6300F3Svc.sendAndResponse().invo : " + invo);
        log.debug("Send6300F3Svc.sendAndResponse().invo : " + invo.getLoanNo());
        String seq = this.send(invo);
        return insCmnSvc.checkResponse(seq);
    }

    @org.springframework.transaction.annotation.Transactional(propagation = Propagation.REQUIRES_NEW)
    public String send(Send6300F3Svo.sendInVo sendInVo) throws Exception {

        try {
            log.debug("Send6300F3Svo.send > sendInVo : " + sendInVo);
            //String seq = String.valueOf(sendInVo.getBnkTgNo());
            String seq = bizUtil.getSeq(Sequence.TRANS);
            T6300F3 sendData = new T6300F3();
            sendData.setTG_LEN(TG_LEN);
            sendData.setTG_DSC(BNK_TG_DSC);
            sendData.setBNK_TG_NO(String.valueOf(sendInVo.getBnkTgNo()));
            sendData.setFA_TG_NO(String.valueOf(sendInVo.getFaTgNo()));
            sendData.setKOS_TG_SND_NO(seq);
            sendData.setTG_SND_DTM(DateUtil.getCurrentDateTime());
            sendData.setRES_CD(RES_CD);
            sendData.setRSRV_ITM_H(RSRV_ITM_H);
            sendData.setBNK_TTL_REQ_NO(sendInVo.getBnkTtlReqNo());
            sendData.setLND_PRGS_STC(sendInVo.getLndPrgsStc());
            sendData.setPRGS_DT(sendInVo.getPrgsDt());
            sendData.setSBMT_DOC_LST(sendInVo.getSbmtDocLst());
            sendData.setMVHR_HSHLDR_RNO(String.valueOf(sendInVo.getMvhrHshldrRno()));
            sendData.setMVHR_TRGT_THNG_ADDR(sendInVo.getMvhrTrgtThngAddr());
            sendData.setMVHR_HSHLDR_NM_MVIN_DT(sendInVo.getMvhrHshldrNmMvinDt());
            sendData.setMVHRDTM(String.valueOf(sendInVo.getMvhrdtm()));
            sendData.setRSRV_ITM_B(sendInVo.getRsrvItmB());
            sendData.setLN_APRV_NO(StringUtil.rpad(sendInVo.getLoanNo(), 14, "0"));

            sendData.setRSRV_ITM_B(sendInVo.getRsrvItmB());

            log.debug(sendData.toString());
            insCmnSvc.insSend(InsCmnSvo.insCmnInVo.builder()
                    .tgSqn(seq)
                    .bnkTgNo(sendData.getBNK_TG_NO())
                    .bnkCd(BNK_CD)
                    .tgDsc(TG_DSC)
                    .trDsc(TR_DSC)
                    .reqTgCnts(sendData.dataToString())
                    .reqTgLog(sendData.print())
                    .reqTgFnYn(REQ_TG_FN_YN)
                    .resTgFnYn(RES_TG_FN_YN)
                    .loanNo(sendInVo.getLoanNo())
                    .membNo("SYSTEM")
                    .build());

            return seq;
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException("전문 전송 테이블 적재시 오류가 발생했습니다! -> " + e.getMessage());
        }
    }
}
