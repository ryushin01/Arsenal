package com.bankle.common.wooriApi.socket.woori.sendSvc.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

public class SendA700Cvo {

    @Getter
    @Setter
    @Builder
    public static class SendA700ReqCvo {

        private String loanNo;

        private String newLoaNo;

        private String trLn;

        private String trCd;

        private String trTpCd;

        private String loNo;

        private String trSq;

        private String reqDttm;

        private String resDttm;

        private String resCd;

        private String approvalNum;

        private String exeDtm;

        private String procDvsn;

        private String exeAmt;

        private String categoryCd;

        private String docTax;

        private String debtDcAmt;

        private String etcAmt;

        private String filler;

        private String trnKnd;

        private String trnName;

        private String gubun;
    }
}
