package com.bankle.common.wooriApi.biz.cntr.vo;


import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@ToString
@SuperBuilder
@NoArgsConstructor
public class CustBrnchMngSvo {


    @Setter
    @Getter
    public static class CustBrnchMngInVo  {

        private String bizNo;

        private String brnchCd;

        private String brnchNm;
    }

    @Setter
    @Getter
    public static class CustBrnchMngOutVo  {

        List<CustBrnchInfo> custBrnchInfoList;
    }

    @Setter
    @Getter
    public static class CustBrnchInfo {

        private String bizNo;

        private String brnchCd;

        private String brnchNm;
    }
}
