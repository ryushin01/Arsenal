package com.bankle.common.wooriApi.socket.woori.sendSvc;

import com.bankle.common.utils.DateUtil;
import com.bankle.common.wooriApi.socket.woori.commonSvc.WooriCmnSvc;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.WooriCmnSvo;
import com.bankle.common.wooriApi.socket.woori.sendSvc.vo.SendA400Svo;
import com.bankle.common.wooriApi.socket.woori.socketData.A4X0;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;


@Slf4j
@Service
@RequiredArgsConstructor
public class SendA400Svc {

    private final WooriCmnSvc wooriCmnSvc;

    public CheckResponseSvo sendAndResponse(@Valid SendA400Svo.SendA400InSvo invo) throws Exception{
        log.debug("SendA400Svo.SendA400InSvo : " + invo);
        String seq = this.send(invo);
        log.debug("String seq = this.send(invo) : " + seq);
        return wooriCmnSvc.checkResponse(seq);
    }
    /**
     *
     * @name     : A400Svc.sendA400
     * @author   : rojoon
     * @param    :
     * @return   :
     **/
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public String send(@Valid SendA400Svo.SendA400InSvo invo) throws Exception {
        //------------------------------------------------------------------
        // 1. A400 전문 셋업
        //------------------------------------------------------------------
        String seq = invo.getTrSq();
        A4X0 sendData = new A4X0();
//        sendData.setTR_LN(invo.getTrLn()); // 전문길이
        sendData.setTR_CD(invo.getTrCd()); // 전문종별코드
        sendData.setTR_TP_CD(invo.getTrTpCd()); // 거래구분코드
        sendData.setLO_NO(invo.getLoNo());  // 관리번호
        sendData.setTR_SQ(invo.getTrSq());  // 식별번호
        sendData.setREQ_DTTM(DateUtil.getCurrentDateTime());  // 송신일자
        sendData.setAPPROVAL_NUM(invo.getLoanNo()); // 여신승인신청번호
        sendData.setPAY_TYPE(invo.getPayType());  // 지급구분
        sendData.setPAY_BANK_CD(invo.getPayBankCd()); // 지급요청 은행코드
        sendData.setPAY_AMT(invo.getPayAmt());  // 지급요청 금액
        sendData.setTRANS_RESULT_CD(invo.getTransResultCd()); // 이체 결과 코드
        sendData.setFILLER(invo.getFiller());
        log.debug(sendData.print());

        if (!StringUtils.hasText(sendData.getLO_NO().trim())) {
            sendData.setLO_NO("0000000000000");
        }
        //------------------------------------------------------------------
        // 3.전문 전송
        //------------------------------------------------------------------
        WooriCmnSvo.sendVo sendVo = new WooriCmnSvo.sendVo();
        sendVo.setTrSeq(sendData.getTR_SQ());
        sendVo.setTrnName(invo.getTrnName());
        sendVo.setTrnKnd(sendData.getTR_CD());
        sendVo.setReqData(sendData.dataToString());
        sendVo.setReqDataLog(sendData.print());
        sendVo.setApprovalNum(sendData.getAPPROVAL_NUM());
        sendVo.setMembNo(sendData.getLO_NO());
        sendVo.setLoanNo(invo.getLoanNo());
        sendVo.setReptMembNo(sendData.getLO_NO());
        sendVo.setTgDsc(invo.getInsGbn());
        sendVo.setResendCt(0);
        sendVo.setBankResCode(invo.getTransResultCd());
        log.debug("SendA400Svc.send().sendData : " + sendData.dataToString());
        wooriCmnSvc.wooriSend(sendVo);
        return seq;
    }
}
