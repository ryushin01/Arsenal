package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnDb6100W1}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnDb6100W1Dto implements Serializable {
    TbWoTrnDb6100W1IdDto id;
    BigDecimal tgLen;
    @Size(max = 5)
    String tgDsc;
    @Size(max = 3)
    String resCd;
    @Size(max = 5)
    String lndAgncCd;
    LocalDateTime bnkTgTrnsDtm;
    LocalDateTime dbTgTrnsDtm;
    @Size(max = 8)
    String bnkTgNo;
    @NotNull
    BigDecimal dbTgNo;
    @Size(max = 39)
    String rsrvItmH;
    @Size(max = 20)
    String bnkAskNo;
    @Size(max = 20)
    String dbMngNo;
    @Size(max = 14)
    String kosTgTrnsDtm;
    @Size(max = 14)
    String kosTgNo;
    @Size(max = 1)
    String procDvsnCd;
    @Size(max = 1)
    String rthIsrnEntrYn;
    @Size(max = 1)
    String rthIsrnEntrCmpy;
    @Size(max = 30)
    String rthIsrnScrtNo;
    @Size(max = 6)
    String pstNo;
    @Size(max = 10)
    String crtdnCd;
    @Size(max = 122)
    String trgtAddr;
    @Size(max = 122)
    String trgtDtlAddr;
    @Size(max = 20)
    String rgstrUnqNo1;
    @Size(max = 20)
    String rgstrUnqNo2;
    @Size(max = 20)
    String rgstrUnqNo3;
    @Size(max = 2)
    String lndKndCd;
    @Size(max = 1)
    String fndYn;
    @Size(max = 200)
    String prdtNm;
    @Size(max = 20)
    String prdtCd;
    @Size(max = 2)
    String grntAgncCd;
    @Size(max = 1)
    String srvTrgtYn;
    @Size(max = 1)
    String stndTrgtYn;
    @Size(max = 1)
    String rrcpChrgTrgtYn;
    @Size(max = 1)
    String rvsnCntrctChrgTrgtYn;
    @Size(max = 8)
    String sscptAskDt;
    @Size(max = 8)
    String lndPlnDt;
    @Size(max = 8)
    String rntlPrdEndDt;
    @Size(max = 8)
    String lndExprdDt;
    @NotNull
    BigDecimal lndPrd;
    @NotNull
    BigDecimal lndAmt;
    @NotNull
    BigDecimal isrnEntrAmt;
    @NotNull
    BigDecimal objtEbnkRgstrRnk;
    @NotNull
    BigDecimal objtEbnkBndMaxAmt;
    @NotNull
    BigDecimal mggFnlOdprtAmt;
    @NotNull
    BigDecimal trolFnlOdprtAmt;
    @Size(max = 8)
    String srvcEndDt;
    @Size(max = 52)
    String dbtrNm;
    @Size(max = 13)
    String dbtrRrno;
    @Size(max = 5)
    String dbtrPstNo;
    @Size(max = 244)
    String dbtrAddr;
    @Size(max = 20)
    String dbtrPhno;
    @Size(max = 20)
    String dbtrHpno;
    @Size(max = 1)
    String wdngPlnYn;
    @Size(max = 8)
    String wdngPlnDt;
    @Size(max = 1)
    String hshldrCnddtYn;
    @Size(max = 1)
    String unmrdHshldr25agLstnYn;
    @Size(max = 1)
    String acptDsc;
    @Size(max = 42)
    String lwfmNm;
    @Size(max = 20)
    String lwfmBizno;
    @Size(max = 20)
    String askBrnchCd;
    @Size(max = 42)
    String askBrnchNm;
    @Size(max = 42)
    String askBrnchDrctrNm;
    @Size(max = 20)
    String askBrnchPhno;
    @Size(max = 2)
    String bnkLesDsc;
    @Size(max = 2)
    String fndLesDsc;
    @Size(max = 100)
    String cndtlCnts;
    @Size(max = 15)
    String isrnPrmm;
    @Size(max = 900)
    String rsrvItmB;
    LocalDateTime regDtm;
    @Size(max = 20)
    String loanAprvNo2;
}