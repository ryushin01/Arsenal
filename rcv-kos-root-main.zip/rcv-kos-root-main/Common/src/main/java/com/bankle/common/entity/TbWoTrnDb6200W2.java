package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_TRN_DB_6200_W2")
public class TbWoTrnDb6200W2 {
    @EmbeddedId
    private TbWoTrnDb6200W2Id id;

    @Column(name = "TG_LEN", precision = 8)
    private BigDecimal tgLen;

    @Size(max = 5)
    @Column(name = "TG_DSC", length = 5)
    private String tgDsc;

    @Size(max = 3)
    @Column(name = "RES_CD", length = 3)
    private String resCd;

    @Size(max = 5)
    @Column(name = "LND_AGNC_CD", length = 5)
    private String lndAgncCd;

    @Size(max = 14)
    @Column(name = "BNK_TG_TRNS_DTM", length = 14)
    private String bnkTgTrnsDtm;

    @Size(max = 14)
    @Column(name = "DB_TG_TRNS_DTM", length = 14)
    private String dbTgTrnsDtm;

    @Size(max = 8)
    @Column(name = "BNK_TG_NO", length = 8)
    private String bnkTgNo;

    @Column(name = "DB_TG_NO", precision = 8)
    private BigDecimal dbTgNo;

    @Size(max = 39)
    @Column(name = "RSRV_ITM_H", length = 39)
    private String rsrvItmH;

    @Size(max = 20)
    @Column(name = "BNK_ASK_NO", length = 20)
    private String bnkAskNo;

    @Size(max = 20)
    @Column(name = "DB_MNG_NO", length = 20)
    private String dbMngNo;

    @Size(max = 20)
    @Column(name = "KOS_MNG_NO", length = 20)
    private String kosMngNo;

    @Size(max = 14)
    @Column(name = "KOS_TG_TRNS_DTM", length = 14)
    private String kosTgTrnsDtm;

    @Size(max = 14)
    @Column(name = "KOS_TG_NO", length = 14)
    private String kosTgNo;

    @Size(max = 2)
    @Column(name = "LND_KCD", length = 2)
    private String lndKcd;

    @Size(max = 1)
    @Column(name = "FND_YN", length = 1)
    private String fndYn;

    @Size(max = 1)
    @Column(name = "CNFMTN_DSC", length = 1)
    private String cnfmtnDsc;

    @Size(max = 2)
    @Column(name = "SRV_DSC", length = 2)
    private String srvDsc;

    @Size(max = 30)
    @Column(name = "OJT_ANS", length = 30)
    private String ojtAns;

    @Size(max = 200)
    @Column(name = "SJT_ANS_1", length = 200)
    private String sjtAns1;

    @Size(max = 200)
    @Column(name = "SJT_ANS_2", length = 200)
    private String sjtAns2;

    @Size(max = 200)
    @Column(name = "SJT_ANS_3", length = 200)
    private String sjtAns3;

    @Size(max = 200)
    @Column(name = "SJT_ANS_4", length = 200)
    private String sjtAns4;

    @Size(max = 200)
    @Column(name = "SJT_ANS_5", length = 200)
    private String sjtAns5;

    @Size(max = 14)
    @Column(name = "SLF_CTFC_AGNC", length = 14)
    private String slfCtfcAgnc;

    @Size(max = 14)
    @Column(name = "SLF_CTFC_TM", length = 14)
    private String slfCtfcTm;

    @Size(max = 1)
    @Column(name = "RES_YN", length = 1)
    private String resYn;

    @Size(max = 1)
    @Column(name = "OPTM_YN", length = 1)
    private String optmYn;

    @Size(max = 1)
    @Column(name = "CNFM_RSLT_BNK_TRNS_YN", length = 1)
    private String cnfmRsltBnkTrnsYn;

    @Size(max = 14)
    @Column(name = "BNK_RES_DTM", length = 14)
    private String bnkResDtm;

    @Size(max = 1)
    @Column(name = "LND_AMT_JST_PMNT_YN", length = 1)
    private String lndAmtJstPmntYn;

    @Size(max = 1)
    @Column(name = "RCPT_JST_CHRGYN", length = 1)
    private String rcptJstChrgyn;

    @Size(max = 1)
    @Column(name = "RGSTRACPT_THDY_YN", length = 1)
    private String rgstracptThdyYn;

    @Size(max = 50)
    @Column(name = "RGSTR_ERSR_ACPT_NO", length = 50)
    private String rgstrErsrAcptNo;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "FXCLT_ESTBS_YN", length = 1)
    private String fxcltEstbsYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "FXCLT_ESTBS_RNK_JST_YN", length = 1)
    private String fxcltEstbsRnkJstYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "FXCLT_ESTBS_AMT_JST_YN", length = 1)
    private String fxcltEstbsAmtJstYn;

    @Size(max = 1)
    @ColumnDefault("'N'")
    @Column(name = "ACPTNO_JST_YN", length = 1)
    private String acptnoJstYn;

    @Size(max = 1)
    @Column(name = "ODPRT_JST_YN", length = 1)
    private String odprtJstYn;

    @Size(max = 14)
    @Column(name = "RSCH_DTM", length = 14)
    private String rschDtm;

    @Size(max = 20)
    @Column(name = "SRCHR_NM", length = 20)
    private String srchrNm;

    @Size(max = 15)
    @Column(name = "SRCHR_PHNO", length = 15)
    private String srchrPhno;

    @Size(max = 300)
    @Column(name = "STND_RMK", length = 300)
    private String stndRmk;

    @Size(max = 1)
    @Column(name = "LSSR_MVINHSHLD_YN", length = 1)
    private String lssrMvinhshldYn;

    @Size(max = 1)
    @Column(name = "LSSR_LSSR_HVTTYN", length = 1)
    private String lssrLssrHvttyn;

    @Size(max = 20)
    @Column(name = "LSSR_NM", length = 20)
    private String lssrNm;

    @Size(max = 20)
    @Column(name = "LSSR_RLTSP", length = 20)
    private String lssrRltsp;

    @Size(max = 8)
    @Column(name = "LSSR_MVIN_DT", length = 8)
    private String lssrMvinDt;

    @Size(max = 1)
    @Column(name = "LSHDR_MVIN_HSHLD_EANE", length = 1)
    private String lshdrMvinHshldEane;

    @Size(max = 1)
    @Column(name = "LSHDR_HVTT_YN", length = 1)
    private String lshdrHvttYn;

    @Size(max = 30)
    @Column(name = "LSHDR_NM", length = 30)
    private String lshdrNm;

    @Size(max = 20)
    @Column(name = "LSHDR_RLTSP", length = 20)
    private String lshdrRltsp;

    @Size(max = 8)
    @Column(name = "LSHDR_MVIN_DT", length = 8)
    private String lshdrMvinDt;

    @Size(max = 1)
    @Column(name = "DBTR_SLF_MVIN_YN", length = 1)
    private String dbtrSlfMvinYn;

    @Size(max = 1)
    @Column(name = "MVIN_ADDR_OPTM_YN", length = 1)
    private String mvinAddrOptmYn;

    @Size(max = 1)
    @Column(name = "MVIN_DT_OPTM_YN", length = 1)
    private String mvinDtOptmYn;

    @Size(max = 1)
    @Column(name = "SPUS_MVINYN", length = 1)
    private String spusMvinyn;

    @Size(max = 1)
    @Column(name = "DBTR_OTSD_MVIN_OPTM_YN", length = 1)
    private String dbtrOtsdMvinOptmYn;

    @Size(max = 14)
    @Column(name = "TTL_STRD_DTM", length = 14)
    private String ttlStrdDtm;

    @Size(max = 8)
    @Column(name = "TTL_RSCH_DT", length = 8)
    private String ttlRschDt;

    @Size(max = 40)
    @Column(name = "TTL_SRCHR_NM", length = 40)
    private String ttlSrchrNm;

    @Size(max = 8)
    @Column(name = "TTL_DRWUP_DT", length = 8)
    private String ttlDrwupDt;

    @Size(max = 296)
    @Column(name = "TTL_RMK", length = 296)
    private String ttlRmk;

    @Size(max = 15)
    @Column(name = "ISRN_SCRT_NO", length = 15)
    private String isrnScrtNo;

    @Size(max = 15)
    @Column(name = "ISRN_ENTR_AMT", length = 15)
    private String isrnEntrAmt;

    @Size(max = 15)
    @Column(name = "RTHISRN_PRMM", length = 15)
    private String rthisrnPrmm;

    @Size(max = 1)
    @ColumnDefault("'2'")
    @Column(name = "UNUSL_FCT_EXST_YN", length = 1)
    private String unuslFctExstYn;

    @Size(max = 1)
    @ColumnDefault("'1'")
    @Column(name = "UNUSL_THNG_YN", length = 1)
    private String unuslThngYn;

    @Size(max = 1)
    @Column(name = "CNDTL_EXEC_YN", length = 1)
    private String cndtlExecYn;

    @Size(max = 1)
    @Column(name = "RTH_RSCH_FN_YN", length = 1)
    private String rthRschFnYn;

    @Size(max = 784)
    @Column(name = "RSRV_ITM_B", length = 784)
    private String rsrvItmB;

    @Column(name = "REG_DTM")
    private LocalDateTime regDtm;

    @Size(max = 20)
    @Column(name = "LN_APRV_NO2", length = 20)
    private String lnAprvNo2;

}