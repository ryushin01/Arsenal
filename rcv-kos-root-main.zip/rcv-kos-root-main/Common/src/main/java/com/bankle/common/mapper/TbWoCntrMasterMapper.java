package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoCntrMasterDto;
import com.bankle.common.entity.TbWoCntrMaster;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoCntrMasterMapper extends DefaultMapper<TbWoCntrMasterDto, TbWoCntrMaster> {
    TbWoCntrMasterMapper INSTANCE = Mappers.getMapper(TbWoCntrMasterMapper.class);
}