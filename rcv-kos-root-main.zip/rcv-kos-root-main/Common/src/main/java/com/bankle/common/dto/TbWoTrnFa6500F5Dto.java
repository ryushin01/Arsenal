package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnFa6500F5}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnFa6500F5Dto implements Serializable {
    TbWoTrnFa6500F5IdDto id;
    @NotNull
    BigDecimal tgLen;
    @Size(max = 4)
    String tgDsc;
    @NotNull
    @Size(max = 8)
    String bnkTgNo;
    @NotNull
    @Size(max = 8)
    String faTgNo;
    @NotNull
    @Size(max = 14)
    String kosTgSndNo;
    LocalDateTime tgSndDtm;
    LocalDateTime tgRcvDtm;
    @Size(max = 3)
    String resCd;
    @Size(max = 35)
    String rsrvItmH;
    @Size(max = 2)
    String lndDsc;
    @Size(max = 2)
    String lndKndCd;
    @Size(max = 2)
    String fndUseCd;
    @Size(max = 9)
    String bnkLndPrdtCd;
    @Size(max = 200)
    String bnkLndPrdtNm;
    @Size(max = 1)
    String stndAplYn;
    @Size(max = 1)
    String mvLwyrCnfmYn;
    @Size(max = 14)
    String rgstrUnqNo1;
    @Size(max = 14)
    String rgstrUnqNo2;
    @Size(max = 14)
    String rgstrUnqNo3;
    @Size(max = 14)
    String rgstrUnqNo4;
    @Size(max = 14)
    String rgstrUnqNo5;
    @Size(max = 1)
    String rlesDsc;
    @Size(max = 2)
    String trgtRlesDsc;
    @Size(max = 300)
    String trgtRlesAddr;
    @Size(max = 8)
    String bfAskDt;
    @Size(max = 8)
    String lndPlnDt;
    @NotNull
    BigDecimal slPrc;
    @Size(max = 15)
    String scrtEvlAmt;
    @Size(max = 15)
    String isrnEntrAmt;
    @NotNull
    BigDecimal lndAmt;
    @NotNull
    BigDecimal bnkFxcltRgstrRnk;
    @Size(max = 50)
    String dbtrNm;
    @Size(max = 13)
    String dbtrBirthDt;
    @Size(max = 300)
    String dbtrAddr;
    @Size(max = 14)
    String dbtrPhno;
    @Size(max = 14)
    String dbtrHpno;
    @Size(max = 50)
    String pwpsNm;
    @Size(max = 13)
    String pwpsBirthDt;
    @Size(max = 300)
    String pwpsAddr;
    @Size(max = 14)
    String pwpsPhno;
    @Size(max = 14)
    String pwpsHpno;
    String rmkFct;
    @Size(max = 1)
    String lndHndgSlfDsc;
    @Size(max = 50)
    String bnkBrnchNm;
    @Size(max = 50)
    String bnkDrctrNm;
    @Size(max = 14)
    String bnkBrnchPhno;
    @Size(max = 14)
    String bnkDrctrHp;
    @Size(max = 14)
    String bnkBrnchFax;
    @Size(max = 100)
    String bnkBrnchAddr;
    @Size(max = 50)
    String slmnCmpyNm;
    @Size(max = 50)
    String slmnNm;
    @Size(max = 14)
    String slmnPhno;
    @Size(max = 20)
    String rfrLnAprvNo;
    @Size(max = 1)
    String rgstrMtdDsc;
    @Size(max = 1)
    String odprtRpyEane;
    @Size(max = 50)
    String eltnEstbsLwyrNm;
    @Size(max = 12)
    String eltnEstbsLwyrBizno;
    @Size(max = 1)
    String slCntrctEane;
    @Size(max = 50)
    String slCntrctFlnm;
    @Size(max = 1)
    String afrgstrScrtYn;
    @Size(max = 6)
    String bnkBrnchCd;
    String rsrvItmB;
    LocalDateTime regDtm;
    @Size(max = 300)
    String trgtRlesAddr2;
    @Size(max = 1)
    String addrSrchYn;
    @Size(max = 1)
    String cnvntLwyrYn;
    @Size(max = 20)
    String lnAprvNo2;
}