package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoResearchMasterDto;
import com.bankle.common.entity.TbWoResearchMaster;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoResearchMasterMapper extends DefaultMapper<TbWoResearchMasterDto, TbWoResearchMaster> {
    TbWoResearchMasterMapper INSTANCE = Mappers.getMapper(TbWoResearchMasterMapper.class);
}