package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Entity;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class TbWoTrnDb6200W2Id implements java.io.Serializable {
    private static final long serialVersionUID = 1059104614331212189L;
    @Size(max = 20)
    @NotNull
    @Column(name = "LOAN_NO", nullable = false, length = 20)
    private String loanNo;

    @NotNull
    @Column(name = "CHG_DTM", nullable = false)
    private LocalDateTime chgDtm;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        TbWoTrnDb6200W2Id entity = (TbWoTrnDb6200W2Id) o;
        return Objects.equals(this.chgDtm, entity.chgDtm) &&
                Objects.equals(this.loanNo, entity.loanNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(chgDtm, loanNo);
    }

}