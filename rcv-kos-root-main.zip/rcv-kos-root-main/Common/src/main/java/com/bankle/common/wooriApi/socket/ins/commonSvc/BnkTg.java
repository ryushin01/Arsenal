package com.bankle.common.wooriApi.socket.ins.commonSvc;

import java.util.List;
import java.util.Map;

public class BnkTg extends GetSetData {

    public BnkTg(List<Map<String, Object>> listBnkTgC) throws Exception {

        setVariable(listBnkTgC.size());  // Layout Column Count Setting

        String[] arrNm  = getArrName  ();
        int   [] arrLen = getArrLength();
        String[] arrTp  = getArrType  ();

        /*================================================================================================*/
        int i = 0;
        TgCommData tgCommData = new TgCommData();

        for(i = 0; i < listBnkTgC.size(); i++) {

            tgCommData.putAll(listBnkTgC.get(i));

            arrNm [i] = tgCommData.getString("TG_COL_NM");  // 전문 Layout 컬럼 명
            arrLen[i] = tgCommData.getInt   ("TG_LEN"   );  // 전문 Layout 컬럼 길이
            arrTp [i] = tgCommData.getString("TG_TPC"   );  // 전문 Layout 컬럼 타입 (N : 숫자, S : String 영문/숫자, K : 한글포함)
        }
        /*================================================================================================*/
        /*                      Total Length  1204                                                        */
        /*================================================================================================*/
        setMap();
    }
}
