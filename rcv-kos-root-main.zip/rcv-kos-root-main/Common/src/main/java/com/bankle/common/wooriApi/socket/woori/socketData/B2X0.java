/**
 * 수신부(BPR) 법무사 업무 할당 내역 요청
 */
package com.bankle.common.wooriApi.socket.woori.socketData;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class B2X0 extends GetSetData {

    byte[] TR_LN = new byte[4];    //전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정
    byte[] TR_CD = new byte[4];        //전문종별코드
    byte[] TR_TP_CD = new byte[3];    //거래구분코드
    byte[] LO_NO = new byte[13];    //관리번호
    byte[] TR_SQ = new byte[14];    //식별번호
    byte[] REQ_DTTM = new byte[14];        //송신일자
    byte[] RES_DTTM = new byte[14];        //수신일자
    byte[] RES_CD = new byte[3];        //응답코드
    byte[] REQ_DT = new byte[8];        //요청일자
    byte[] APPROVAL_NUM = new byte[11];    //여신승인신청번호
    byte[] KIND_CD = new byte[6];    //매매,전세 구분 1:매매 2:전세
    byte[] BSTR_REG_NO = new byte[10];    //사업자등록번호
    byte[] PRODUCT_STAT_CD = new byte[3];        //상태코드
    byte[] PRODUCT_NAME = new byte[200];        //상품명
    byte[] BUYER_NAME = new byte[50];        //차주명
    byte[] SCHEDULED_AMOUNT = new byte[15];        //실행예정금액
    byte[] SCHEDULED_DATE = new byte[8];        //실행예정일자
    byte[] EXECUTION_AMOUNT = new byte[15];        //실행금액
    byte[] EXECUTION_DATE = new byte[8];        //실행일자
    byte[] IMG_KEY = new byte[27];        //이미지키
    byte[] LEG_BANK_CODE_1 = new byte[3];        //법무사등록 타은행코드1
    byte[] LEG_BANK_CODE_2 = new byte[3];        //법무사등록 타은행코드2
    byte[] LEG_BANK_CODE_3 = new byte[3];        //법무사등록 타은행코드3
    byte[] LEG_BANK_CODE_4 = new byte[3];        //법무사등록 타은행코드4
    byte[] LEG_BANK_CODE_5 = new byte[3];        //법무사등록 타은행코드5
    byte[] LEG_BANK_CODE_6 = new byte[3];        //법무사등록 타은행코드6
    byte[] LEG_BANK_CODE_7 = new byte[3];        //법무사등록 타은행코드7 // SR대상여부
    byte[] LEG_BANK_CODE_8 = new byte[3];        //법무사등록 타은행코드8 // 대출이동서비스 구분코드 // MO : 전자등기 MF : 일반등기
    byte[] LEG_BANK_CODE_9 = new byte[3];        //법무사등록 타은행코드9 // 100 :자격구분 200 : 등록요청 300: 철회요청 500: 이전법무사 계좌로 요청, 900: SR 상환영수증 마감
    byte[] LEG_BANK_CODE_10 = new byte[3];        //법무사등록 타은행코드10

    byte[] FILLER = new byte[44];    //공란

    public B2X0() {

        //default 값 셋팅
        setData(this.TR_LN, "");
        setData(this.TR_CD, "");
        setData(this.TR_TP_CD, "");
        setData(this.LO_NO, "");
        setData(this.TR_SQ, "");
        setData(this.REQ_DTTM, "");
        setData(this.RES_DTTM, "");
        setData(this.RES_CD, "");
        setData(this.REQ_DT, "");
        setData(this.APPROVAL_NUM, "");
        setData(this.KIND_CD, "");
        setData(this.BSTR_REG_NO, "");
        setData(this.PRODUCT_STAT_CD, "");
        setData(this.PRODUCT_NAME, "");
        setData(this.BUYER_NAME, "");
        setData(this.SCHEDULED_AMOUNT, "");
        setData(this.SCHEDULED_DATE, "");
        setData(this.EXECUTION_AMOUNT, "");
        setData(this.EXECUTION_DATE, "");
        setData(this.IMG_KEY, "");
        setData(this.LEG_BANK_CODE_1, "");
        setData(this.LEG_BANK_CODE_2, "");
        setData(this.LEG_BANK_CODE_3, "");
        setData(this.LEG_BANK_CODE_4, "");
        setData(this.LEG_BANK_CODE_5, "");
        setData(this.LEG_BANK_CODE_6, "");
        setData(this.LEG_BANK_CODE_7, "");
        setData(this.LEG_BANK_CODE_8, "");
        setData(this.LEG_BANK_CODE_9, "");
        setData(this.LEG_BANK_CODE_10, "");
        setData(this.FILLER, "");
    }

    public String print() {

        StringBuffer sb = new StringBuffer();

        sb.append("TR_LN : " + getData(TR_LN) + "\tSize : " + TR_LN.length + "\n");
        sb.append("TR_CD : " + getData(TR_CD) + "\tSize : " + TR_CD.length + "\n");
        sb.append("TR_TP_CD : " + getData(TR_TP_CD) + "\tSize : " + TR_TP_CD.length + "\n");
        sb.append("LO_NO : " + getData(LO_NO) + "\tSize : " + LO_NO.length + "\n");
        sb.append("TR_SQ : " + getData(TR_SQ) + "\tSize : " + TR_SQ.length + "\n");
        sb.append("REQ_DTTM : " + getData(REQ_DTTM) + "\tSize : " + REQ_DTTM.length + "\n");
        sb.append("RES_DTTM : " + getData(RES_DTTM) + "\tSize : " + RES_DTTM.length + "\n");
        sb.append("RES_CD : " + getData(RES_CD) + "\tSize : " + RES_CD.length + "\n");
        sb.append("REQ_DT : " + getData(REQ_DT) + "\tSize : " + REQ_DT.length + "\n");
        sb.append("APPROVAL_NUM : " + getData(APPROVAL_NUM) + "\tSize : " + APPROVAL_NUM.length + "\n");
        sb.append("KIND_CD : " + getData(KIND_CD) + "\tSize : " + KIND_CD.length + "\n");
        sb.append("BSTR_REG_NO : " + getData(BSTR_REG_NO) + "\tSize : " + BSTR_REG_NO.length + "\n");
        sb.append("PRODUCT_STAT_CD : " + getData(PRODUCT_STAT_CD) + "\tSize : " + PRODUCT_STAT_CD.length + "\n");
        sb.append("PRODUCT_NAME : " + getData(PRODUCT_NAME) + "\tSize : " + PRODUCT_NAME.length + "\n");
        sb.append("BUYER_NAME : " + getData(BUYER_NAME) + "\tSize : " + BUYER_NAME.length + "\n");
        sb.append("SCHEDULED_AMOUNT : " + getData(SCHEDULED_AMOUNT) + "\tSize : " + SCHEDULED_AMOUNT.length + "\n");
        sb.append("SCHEDULED_DATE : " + getData(SCHEDULED_DATE) + "\tSize : " + SCHEDULED_DATE.length + "\n");
        sb.append("EXECUTION_AMOUNT : " + getData(EXECUTION_AMOUNT) + "\tSize : " + EXECUTION_AMOUNT.length + "\n");
        sb.append("EXECUTION_DATE : " + getData(EXECUTION_DATE) + "\tSize : " + EXECUTION_DATE.length + "\n");
        sb.append("IMG_KEY : " + getData(IMG_KEY) + "\tSize : " + IMG_KEY.length + "\n");
        sb.append("LEG_BANK_CODE_1 : " + getData(LEG_BANK_CODE_1) + "\tSize : " + LEG_BANK_CODE_1.length + "\n");
        sb.append("LEG_BANK_CODE_2 : " + getData(LEG_BANK_CODE_2) + "\tSize : " + LEG_BANK_CODE_2.length + "\n");
        sb.append("LEG_BANK_CODE_3 : " + getData(LEG_BANK_CODE_3) + "\tSize : " + LEG_BANK_CODE_3.length + "\n");
        sb.append("LEG_BANK_CODE_4 : " + getData(LEG_BANK_CODE_4) + "\tSize : " + LEG_BANK_CODE_4.length + "\n");
        sb.append("LEG_BANK_CODE_5 : " + getData(LEG_BANK_CODE_5) + "\tSize : " + LEG_BANK_CODE_5.length + "\n");
        sb.append("LEG_BANK_CODE_6 : " + getData(LEG_BANK_CODE_6) + "\tSize : " + LEG_BANK_CODE_6.length + "\n");
        sb.append("LEG_BANK_CODE_7 : " + getData(LEG_BANK_CODE_7) + "\tSize : " + LEG_BANK_CODE_7.length + "\n");
        sb.append("LEG_BANK_CODE_8 : " + getData(LEG_BANK_CODE_8) + "\tSize : " + LEG_BANK_CODE_8.length + "\n");
        sb.append("LEG_BANK_CODE_9 : " + getData(LEG_BANK_CODE_9) + "\tSize : " + LEG_BANK_CODE_9.length + "\n");
        sb.append("LEG_BANK_CODE_10 : " + getData(LEG_BANK_CODE_10) + "\tSize : " + LEG_BANK_CODE_10.length + "\n");
        sb.append("FILLER : " + getData(FILLER) + "\tSize : " + FILLER.length + "\n");

        // System.out.println(sb.toString());

        return sb.toString();
    }

    public String dataToString() {
        return getData(TR_LN) + getData(TR_CD) + getData(TR_TP_CD) + getData(LO_NO) + getData(TR_SQ) + getData(REQ_DTTM) + getData(RES_DTTM) + getData(RES_CD)
                + getData(REQ_DT) + getData(APPROVAL_NUM) + getData(KIND_CD) + getData(BSTR_REG_NO) + getData(PRODUCT_STAT_CD) + getData(PRODUCT_NAME) + getData(BUYER_NAME)
                + getData(SCHEDULED_AMOUNT) + getData(SCHEDULED_DATE) + getData(EXECUTION_AMOUNT) + getData(EXECUTION_DATE) + getData(IMG_KEY) + getData(LEG_BANK_CODE_1)
                + getData(LEG_BANK_CODE_2) + getData(LEG_BANK_CODE_3) + getData(LEG_BANK_CODE_4) + getData(LEG_BANK_CODE_5)
                + getData(LEG_BANK_CODE_6) + getData(LEG_BANK_CODE_7) + getData(LEG_BANK_CODE_8) + getData(LEG_BANK_CODE_9) + getData(LEG_BANK_CODE_10)
                + getData(FILLER);
    }

    public Map<String, Object> dataToMap() {
        Map<String, Object> tempMap = new HashMap<String, Object>();

        tempMap.put("TR_LN", getData(TR_LN));
        tempMap.put("TR_CD", getData(TR_CD));
        tempMap.put("TR_TP_CD", getData(TR_TP_CD));
        tempMap.put("LO_NO", getData(LO_NO));
        tempMap.put("TR_SQ", getData(TR_SQ));
        tempMap.put("REQ_DTTM", getData(REQ_DTTM));
        tempMap.put("RES_DTTM", getData(RES_DTTM));
        tempMap.put("RES_CD", getData(RES_CD));
        tempMap.put("REQ_DT", getData(REQ_DT));
        tempMap.put("APPROVAL_NUM", getData(APPROVAL_NUM));
        tempMap.put("KIND_CD", getData(KIND_CD));
        tempMap.put("BSTR_REG_NO", getData(BSTR_REG_NO));
        tempMap.put("PRODUCT_STAT_CD", getData(PRODUCT_STAT_CD));
        tempMap.put("PRODUCT_NAME", getData(PRODUCT_NAME));
        tempMap.put("BUYER_NAME", getData(BUYER_NAME));
        tempMap.put("SCHEDULED_AMOUNT", getData(SCHEDULED_AMOUNT));
        tempMap.put("SCHEDULED_DATE", getData(SCHEDULED_DATE));
        tempMap.put("EXECUTION_AMOUNT", getData(EXECUTION_AMOUNT));
        tempMap.put("EXECUTION_DATE", getData(EXECUTION_DATE));
        tempMap.put("IMG_KEY", getData(IMG_KEY));
        tempMap.put("LEG_BANK_CODE_1", getData(LEG_BANK_CODE_1));
        tempMap.put("LEG_BANK_CODE_2", getData(LEG_BANK_CODE_2));
        tempMap.put("LEG_BANK_CODE_3", getData(LEG_BANK_CODE_3));
        tempMap.put("LEG_BANK_CODE_4", getData(LEG_BANK_CODE_4));
        tempMap.put("LEG_BANK_CODE_5", getData(LEG_BANK_CODE_5));
        tempMap.put("LEG_BANK_CODE_6", getData(LEG_BANK_CODE_6));
        tempMap.put("LEG_BANK_CODE_7", getData(LEG_BANK_CODE_7));
        tempMap.put("LEG_BANK_CODE_8", getData(LEG_BANK_CODE_8));
        tempMap.put("LEG_BANK_CODE_9", getData(LEG_BANK_CODE_9));
        tempMap.put("LEG_BANK_CODE_10", getData(LEG_BANK_CODE_10));

        tempMap.put("FILLER", getData(FILLER));

        return tempMap;
    }

    public void readDataExternal(InputStream stream) {
        try {
            stream.read(TR_LN, 0, TR_LN.length);
            stream.read(TR_CD, 0, TR_CD.length);
            stream.read(TR_TP_CD, 0, TR_TP_CD.length);
            stream.read(LO_NO, 0, LO_NO.length);
            stream.read(TR_SQ, 0, TR_SQ.length);
            stream.read(REQ_DTTM, 0, REQ_DTTM.length);
            stream.read(RES_DTTM, 0, RES_DTTM.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(REQ_DT, 0, REQ_DT.length);
            stream.read(APPROVAL_NUM, 0, APPROVAL_NUM.length);
            stream.read(KIND_CD, 0, KIND_CD.length);
            stream.read(BSTR_REG_NO, 0, BSTR_REG_NO.length);
            stream.read(PRODUCT_STAT_CD, 0, PRODUCT_STAT_CD.length);
            stream.read(PRODUCT_NAME, 0, PRODUCT_NAME.length);
            stream.read(BUYER_NAME, 0, BUYER_NAME.length);
            stream.read(SCHEDULED_AMOUNT, 0, SCHEDULED_AMOUNT.length);
            stream.read(SCHEDULED_DATE, 0, SCHEDULED_DATE.length);
            stream.read(EXECUTION_AMOUNT, 0, EXECUTION_AMOUNT.length);
            stream.read(EXECUTION_DATE, 0, EXECUTION_DATE.length);
            stream.read(IMG_KEY, 0, IMG_KEY.length);
            stream.read(LEG_BANK_CODE_1, 0, LEG_BANK_CODE_1.length);
            stream.read(LEG_BANK_CODE_2, 0, LEG_BANK_CODE_2.length);
            stream.read(LEG_BANK_CODE_3, 0, LEG_BANK_CODE_3.length);
            stream.read(LEG_BANK_CODE_4, 0, LEG_BANK_CODE_4.length);
            stream.read(LEG_BANK_CODE_5, 0, LEG_BANK_CODE_5.length);
            stream.read(LEG_BANK_CODE_6, 0, LEG_BANK_CODE_6.length);
            stream.read(LEG_BANK_CODE_7, 0, LEG_BANK_CODE_7.length);
            stream.read(LEG_BANK_CODE_8, 0, LEG_BANK_CODE_8.length);
            stream.read(LEG_BANK_CODE_9, 0, LEG_BANK_CODE_9.length);
            stream.read(LEG_BANK_CODE_10, 0, LEG_BANK_CODE_10.length);

            stream.read(FILLER, 0, FILLER.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //------------------------------------------------------------------
    // Get Data
    //------------------------------------------------------------------

    /**
     * 전문길이
     *
     * @return
     */
    public String getTR_LN() {
        return getData(TR_LN);
    }
    /**
     * 전문종별코드
     *
     * @return
     */
    public String getTR_CD() {
        return getData(TR_CD);
    }
    /**
     * 거래구분코드
     *
     * @return
     */
    public String getTR_TP_CD() {
        return getData(TR_TP_CD);
    }
    /**
     * 관리번호
     *
     * @return
     */
    public String getLO_NO() {
        return getData(LO_NO);
    }
    /**
     * 식별번호
     *
     * @return
     */
    public String getTR_SQ() {
        return getData(TR_SQ);
    }
    /**
     * 송신일자
     *
     * @return
     */
    public String getREQ_DTTM() {
        return getData(REQ_DTTM);
    }
    /**
     * 수신일자
     *
     * @return
     */
    public String getRES_DTTM() {
        return getData(RES_DTTM);
    }
    /**
     * 응답코드
     *
     * @return
     */
    public String getRES_CD() {
        return getData(RES_CD);
    }
    /**
     * 요청일자
     *
     * @return
     */
    public String getREQ_DT() {
        return getData(REQ_DT);
    }
    /**
     * 여신승인신청번호
     *
     * @return
     */
    public String getAPPROVAL_NUM() {
        return getData(APPROVAL_NUM);
    }
    /**
     * 매매,전세 구분
     *
     * @return
     */
    public String getKIND_CD() {
        return getData(KIND_CD);
    }
    /**
     * 사업자등록번호
     *
     * @return
     */
    public String getBSTR_REG_NO() {
        return getData(BSTR_REG_NO);
    }
    /**
     * 상태코드
     *
     * @return
     */
    public String getPRODUCT_STAT_CD() {
        return getData(PRODUCT_STAT_CD);
    }
    /**
     * 상품명
     *
     * @return
     */
    public String getPRODUCT_NAME() {
        return getData(PRODUCT_NAME);
    }
    /**
     * 상품명
     *
     * @return
     */
    public byte[] getByte_PRODUCT_NAME() {
        return PRODUCT_NAME;
    }
    /**
     * 차주명
     *
     * @return
     */
    public String getBUYER_NAME() {
        return getData(BUYER_NAME);
    }
    /**
     * 차주명
     *
     * @return
     */
    public byte[] getByte_BUYER_NAME() {
        return BUYER_NAME;
    }
    /**
     * 실행예정금액
     *
     * @return
     */
    public String getSCHEDULED_AMOUNT() {
        return getData(SCHEDULED_AMOUNT);
    }
    /**
     * 실행예정일자
     *
     * @return
     */
    public String getSCHEDULED_DATE() {
        return getData(SCHEDULED_DATE);
    }
    /**
     * 실행금액
     *
     * @return
     */
    public String getEXECUTION_AMOUNT() {
        return getData(EXECUTION_AMOUNT);
    }
    /**
     * 실행일자
     *
     * @return
     */
    public String getEXECUTION_DATE() {
        return getData(EXECUTION_DATE);
    }
    /**
     * 이미지키
     *
     * @return
     */
    public String getIMG_KEY() {
        return getData(IMG_KEY);
    }
    /**
     * 법무사등록 타은행코드1
     *
     * @return
     */
    public String getLEG_BANK_CODE_1() {
        return getData(LEG_BANK_CODE_1);
    }
    /**
     * 법무사등록 타은행코드2
     *
     * @return
     */
    public String getLEG_BANK_CODE_2() {
        return getData(LEG_BANK_CODE_2);
    }
    /**
     * 법무사등록 타은행코드3
     *
     * @return
     */
    public String getLEG_BANK_CODE_3() {
        return getData(LEG_BANK_CODE_3);
    }
    /**
     * 법무사등록 타은행코드4
     *
     * @return
     */
    public String getLEG_BANK_CODE_4() {
        return getData(LEG_BANK_CODE_4);
    }
    /**
     * 법무사등록 타은행코드5
     *
     * @return
     */
    public String getLEG_BANK_CODE_5() {
        return getData(LEG_BANK_CODE_5);
    }
    /**
     * 법무사등록 타은행코드6
     *
     * @return
     */
    public String getLEG_BANK_CODE_6() {
        return getData(LEG_BANK_CODE_6);
    }
    /**
     * 법무사등록 타은행코드7
     *
     * @return
     */
    public String getLEG_BANK_CODE_7() {
        return getData(LEG_BANK_CODE_7);
    }
    /**
     * 법무사등록 타은행코드8
     *
     * @return
     */
    public String getLEG_BANK_CODE_8() {
        return getData(LEG_BANK_CODE_8);
    }
    /**
     * 법무사등록 타은행코드9
     *
     * @return
     */
    public String getLEG_BANK_CODE_9() {
        return getData(LEG_BANK_CODE_9);
    }
    /**
     * 법무사등록 타은행코드10
     *
     * @return
     */
    public String getLEG_BANK_CODE_10() {
        return getData(LEG_BANK_CODE_10);
    }
    /**
     * 예비
     *
     * @return
     */
    public String getFILLER() {
        return getData(FILLER);
    }
    //------------------------------------------------------------------
    // Set Data
    //------------------------------------------------------------------

    /**
     * 전문길이
     *
     * @param TR_LN
     */
    public void setTR_LN(String TR_LN) {
        setData(this.TR_LN, TR_LN,"S");
    }



    /**
     * 전문종별코드
     *
     * @param TR_CD
     */
    public void setTR_CD(String TR_CD) {
        setData(this.TR_CD, TR_CD,"S");
    }



    /**
     * 거래구분코드
     *
     * @param TR_TP_CD
     */
    public void setTR_TP_CD(String TR_TP_CD) {
        setData(this.TR_TP_CD, TR_TP_CD,"S");
    }



    /**
     * 관리번호
     *
     * @param LO_NO
     */
    public void setLO_NO(String LO_NO) {
        setData(this.LO_NO, LO_NO,"N");
    }



    /**
     * 식별번호
     *
     * @param TR_SQ
     */
    public void setTR_SQ(String TR_SQ) {
        setData(this.TR_SQ, TR_SQ,"S");
    }



    /**
     * 송신일자
     *
     * @param REQ_DTTM
     */
    public void setREQ_DTTM(String REQ_DTTM) {
        setData(this.REQ_DTTM, REQ_DTTM,"S");
    }



    /**
     * 수신일자
     *
     * @param RES_DTTM
     */
    public void setRES_DTTM(String RES_DTTM) {
        setData(this.RES_DTTM, RES_DTTM,"S");
    }



    /**
     * 응답코드
     *
     * @param RES_CD
     */
    public void setRES_CD(String RES_CD) {
        setData(this.RES_CD, RES_CD,"S");
    }



    /**
     * 요청일자
     *
     * @param REQ_DT
     */
    public void setREQ_DT(String REQ_DT) {
        setData(this.REQ_DT, REQ_DT,"S");
    }



    /**
     * 여신승인신청번호
     *
     * @param APPROVAL_NUM
     */
    public void setAPPROVAL_NUM(String APPROVAL_NUM) {
        setData(this.APPROVAL_NUM, APPROVAL_NUM,"S");
    }



    /**
     * 매매,전세 구분
     *
     * @param KIND_CD
     */
    public void setKIND_CD(String KIND_CD) {
        setData(this.KIND_CD, KIND_CD,"S");
    }



    /**
     * 사업자등록번호
     *
     * @param BSTR_REG_NO
     */
    public void setBSTR_REG_NO(String BSTR_REG_NO) {
        setData(this.BSTR_REG_NO, BSTR_REG_NO,"S");
    }




    /**
     * 상태코드
     *
     * @param PRODUCT_STAT_CD
     */
    public void setPRODUCT_STAT_CD(String PRODUCT_STAT_CD) {
        setData(this.PRODUCT_STAT_CD, PRODUCT_STAT_CD,"S");
    }





    /**
     * 상품명
     *
     * @param PRODUCT_NAME
     */
    public void setPRODUCT_NAME(String PRODUCT_NAME) {
        setData(this.PRODUCT_NAME, PRODUCT_NAME,"K");
    }





    /**
     * 차주명
     *
     * @param BUYER_NAME
     */
    public void setBUYER_NAME(String BUYER_NAME) {
        setData(this.BUYER_NAME, BUYER_NAME,"K");
    }



    /**
     * 실행예정금액
     *
     * @param SCHEDULED_AMOUNT
     */
    public void setSCHEDULED_AMOUNT(String SCHEDULED_AMOUNT) {
        setData(this.SCHEDULED_AMOUNT, SCHEDULED_AMOUNT,"N");
    }



    /**
     * 실행예정일자
     *
     * @param SCHEDULED_DATE
     */
    public void setSCHEDULED_DATE(String SCHEDULED_DATE) {
        setData(this.SCHEDULED_DATE, SCHEDULED_DATE,"S");
    }



    /**
     * 실행금액
     *
     * @param EXECUTION_AMOUNT
     */
    public void setEXECUTION_AMOUNT(String EXECUTION_AMOUNT) {
        setData(this.EXECUTION_AMOUNT, EXECUTION_AMOUNT,"N");
    }



    /**
     * 실행일자
     *
     * @param EXECUTION_DATE
     */
    public void setEXECUTION_DATE(String EXECUTION_DATE) {
        setData(this.EXECUTION_DATE, EXECUTION_DATE,"S");
    }



    /**
     * 이미지키
     *
     * @param IMG_KEY
     */
    public void setIMG_KEY(String IMG_KEY) {
        setData(this.IMG_KEY, IMG_KEY,"S");
    }



    /**
     * 법무사등록 타은행코드1
     *
     * @param LEG_BANK_CODE_1
     */
    public void setLEG_BANK_CODE_1(String LEG_BANK_CODE_1) {
        setData(this.LEG_BANK_CODE_1, LEG_BANK_CODE_1,"S");
    }



    /**
     * 법무사등록 타은행코드2
     *
     * @param LEG_BANK_CODE_2
     */
    public void setLEG_BANK_CODE_2(String LEG_BANK_CODE_2) {
        setData(this.LEG_BANK_CODE_2, LEG_BANK_CODE_2,"S");
    }



    /**
     * 법무사등록 타은행코드3
     *
     * @param LEG_BANK_CODE_3
     */
    public void setLEG_BANK_CODE_3(String LEG_BANK_CODE_3) {
        setData(this.LEG_BANK_CODE_3, LEG_BANK_CODE_3,"S");
    }



    /**
     * 법무사등록 타은행코드4
     *
     * @param LEG_BANK_CODE_4
     */
    public void setLEG_BANK_CODE_4(String LEG_BANK_CODE_4) {
        setData(this.LEG_BANK_CODE_4, LEG_BANK_CODE_4,"S");
    }



    /**
     * 법무사등록 타은행코드5
     *
     * @param LEG_BANK_CODE_5
     */
    public void setLEG_BANK_CODE_5(String LEG_BANK_CODE_5) {
        setData(this.LEG_BANK_CODE_5, LEG_BANK_CODE_5,"S");
    }



    /**
     * 법무사등록 타은행코드6
     *
     * @param LEG_BANK_CODE_6
     */
    public void setLEG_BANK_CODE_6(String LEG_BANK_CODE_6) {
        setData(this.LEG_BANK_CODE_6, LEG_BANK_CODE_6,"S");
    }



    /**
     * 법무사등록 타은행코드7
     *
     * @param LEG_BANK_CODE_7
     */
    public void setLEG_BANK_CODE_7(String LEG_BANK_CODE_7) {
        setData(this.LEG_BANK_CODE_7, LEG_BANK_CODE_7,"S");
    }



    /**
     * 법무사등록 타은행코드8
     *
     * @param LEG_BANK_CODE_8
     */
    public void setLEG_BANK_CODE_8(String LEG_BANK_CODE_8) {
        setData(this.LEG_BANK_CODE_8, LEG_BANK_CODE_8,"S");
    }



    /**
     * 법무사등록 타은행코드9
     *
     * @param LEG_BANK_CODE_9
     */
    public void setLEG_BANK_CODE_9(String LEG_BANK_CODE_9) {
        setData(this.LEG_BANK_CODE_9, LEG_BANK_CODE_9,"S");
    }



    /**
     * 법무사등록 타은행코드10
     *
     * @param LEG_BANK_CODE_10
     */
    public void setLEG_BANK_CODE_10(String LEG_BANK_CODE_10) {
        setData(this.LEG_BANK_CODE_10, LEG_BANK_CODE_10,"S");
    }




    /**
     * 예비
     *
     * @param FILLER
     */
    public void setFILLER(String FILLER) {
        setData(this.FILLER, FILLER,"S");
    }

}
