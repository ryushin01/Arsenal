package com.bankle.common.vo;

import lombok.*;

public class HandlerVo {

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HandlerOutVo{
        String userGb;
        String membNo;
    }
}
