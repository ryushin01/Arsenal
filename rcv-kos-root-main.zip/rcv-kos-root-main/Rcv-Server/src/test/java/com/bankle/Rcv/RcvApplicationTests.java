package com.bankle.Rcv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RcvApplicationTests {

	@Test
	void contextLoads() {
	}

}
